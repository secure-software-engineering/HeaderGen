# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.14.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# # Index of ML Operations<a id='top_phases'></a>
# <ul>
# <ul><li><details><summary><h2>Imported Libraries</h2></summary>
# <ul>
#
# <li><b>keras</b></li>
# <li><b>matplotlib</b></li>
# <li><b>numpy</b></li>
# <li><b>os</b></li>
# <li><b>pandas</b></li>
# <li><b>random</b></li>
# <li><b>sklearn</b></li>
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h2>Visualization</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Visualization" Calls</u></b></summary>
# <ul>
#
# <li> <b>matplotlib</b>
# <ul>
# <li>
# <details><summary><u>matplotlib.pyplot.figure</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Create a new figure, or activate an existing figure.
#
# Parameters
# ----------
# num : int or str or `.Figure`, optional
#     A unique identifier for the figure.
#
#     If a figure with that identifier already exists, this figure is made
#     active and returned. An integer refers to the ``Figure.number``
#     attribute, a string refers to the figure label.
#
#     If there is no figure with the identifier or *num* is not given, a new
#     figure is created, made active and returned.  If *num* is an int, it
#     will be used for the ``Figure.number`` attribute, otherwise, an
#     auto-generated integer value is used (starting at 1 and incremented
#     for each new figure). If *num* is a string, the figure label and the
#     window title is set to this value.
#
# figsize : (float, float), default: :rc:`figure.figsize`
#     Width, height in inches.
#
# dpi : float, default: :rc:`figure.dpi`
#     The resolution of the figure in dots-per-inch.
#
# facecolor : color, default: :rc:`figure.facecolor`
#     The background color.
#
# edgecolor : color, default: :rc:`figure.edgecolor`
#     The border color.
#
# frameon : bool, default: True
#     If False, suppress drawing the figure frame.
#
# FigureClass : subclass of `~matplotlib.figure.Figure`
#     Optionally use a custom `.Figure` instance.
#
# clear : bool, default: False
#     If True and the figure already exists, then it is cleared.
#
# tight_layout : bool or dict, default: :rc:`figure.autolayout`
#     If ``False`` use *subplotpars*. If ``True`` adjust subplot
#     parameters using `.tight_layout` with default padding.
#     When providing a dict containing the keys ``pad``, ``w_pad``,
#     ``h_pad``, and ``rect``, the default `.tight_layout` paddings
#     will be overridden.
#
# constrained_layout : bool, default: :rc:`figure.constrained_layout.use`
#     If ``True`` use constrained layout to adjust positioning of plot
#     elements.  Like ``tight_layout``, but designed to be more
#     flexible.  See
#     :doc:`/tutorials/intermediate/constrainedlayout_guide`
#     for examples.  (Note: does not work with `add_subplot` or
#     `~.pyplot.subplot2grid`.)
#
#
# **kwargs : optional
#     See `~.matplotlib.figure.Figure` for other possible arguments.
#
# Returns
# -------
# `~matplotlib.figure.Figure`
#     The `.Figure` instance returned will also be passed to
#     new_figure_manager in the backends, which allows to hook custom
#     `.Figure` classes into the pyplot interface. Additional kwargs will be
#     passed to the `.Figure` init function.
#
# Notes
# -----
# If you are creating many figures, make sure you explicitly call
# `.pyplot.close` on the figures you are not using, because this will
# enable pyplot to properly clean up the memory.
#
# `~matplotlib.rcParams` defines the default values, which can be modified
# in the matplotlibrc file.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>matplotlib.pyplot.scatter</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'alpha': 0.9}</li></ul>
# <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'alpha': 0.3}</li></ul>
# <blockquote>
# <code>
# A scatter plot of *y* vs. *x* with varying marker size and/or color.
#
# Parameters
# ----------
# x, y : float or array-like, shape (n, )
#     The data positions.
#
# s : float or array-like, shape (n, ), optional
#     The marker size in points**2.
#     Default is ``rcParams['lines.markersize'] ** 2``.
#
# c : array-like or list of colors or color, optional
#     The marker colors. Possible values:
#
#     - A scalar or sequence of n numbers to be mapped to colors using
#       *cmap* and *norm*.
#     - A 2D array in which the rows are RGB or RGBA.
#     - A sequence of colors of length n.
#     - A single color format string.
#
#     Note that *c* should not be a single numeric RGB or RGBA sequence
#     because that is indistinguishable from an array of values to be
#     colormapped. If you want to specify the same RGB or RGBA value for
#     all points, use a 2D array with a single row.  Otherwise, value-
#     matching will have precedence in case of a size matching with *x*
#     and *y*.
#
#     If you wish to specify a single color for all points
#     prefer the *color* keyword argument.
#
#     Defaults to `None`. In that case the marker color is determined
#     by the value of *color*, *facecolor* or *facecolors*. In case
#     those are not specified or `None`, the marker color is determined
#     by the next color of the ``Axes``' current "shape and fill" color
#     cycle. This cycle defaults to :rc:`axes.prop_cycle`.
#
# marker : `~.markers.MarkerStyle`, default: :rc:`scatter.marker`
#     The marker style. *marker* can be either an instance of the class
#     or the text shorthand for a particular marker.
#     See :mod:`matplotlib.markers` for more information about marker
#     styles.
#
# cmap : str or `~matplotlib.colors.Colormap`, default: :rc:`image.cmap`
#     A `.Colormap` instance or registered colormap name. *cmap* is only
#     used if *c* is an array of floats.
#
# norm : `~matplotlib.colors.Normalize`, default: None
#     If *c* is an array of floats, *norm* is used to scale the color
#     data, *c*, in the range 0 to 1, in order to map into the colormap
#     *cmap*.
#     If *None*, use the default `.colors.Normalize`.
#
# vmin, vmax : float, default: None
#     *vmin* and *vmax* are used in conjunction with the default norm to
#     map the color array *c* to the colormap *cmap*. If None, the
#     respective min and max of the color array is used.
#     It is an error to use *vmin*/*vmax* when *norm* is given.
#
# alpha : float, default: None
#     The alpha blending value, between 0 (transparent) and 1 (opaque).
#
# linewidths : float or array-like, default: :rc:`lines.linewidth`
#     The linewidth of the marker edges. Note: The default *edgecolors*
#     is 'face'. You may want to change this as well.
#
# edgecolors : {'face', 'none', *None*} or color or sequence of color, default: :rc:`scatter.edgecolors`
#     The edge color of the marker. Possible values:
#
#     - 'face': The edge color will always be the same as the face color.
#     - 'none': No patch boundary will be drawn.
#     - A color or sequence of colors.
#
#     For non-filled markers, *edgecolors* is ignored. Instead, the color
#     is determined like with 'face', i.e. from *c*, *colors*, or
#     *facecolors*.
#
# plotnonfinite : bool, default: False
#     Whether to plot points with nonfinite *c* (i.e. ``inf``, ``-inf``
#     or ``nan``). If ``True`` the points are drawn with the *bad*
#     colormap color (see `.Colormap.set_bad`).
#
# Returns
# -------
# `~matplotlib.collections.PathCollection`
#
# Other Parameters
# ----------------
# data : indexable object, optional
#     If given, the following parameters also accept a string ``s``, which is
#     interpreted as ``data[s]`` (unless this raises an exception):
#
#     *x*, *y*, *s*, *linewidths*, *edgecolors*, *c*, *facecolor*, *facecolors*, *color*
# **kwargs : `~matplotlib.collections.Collection` properties
#
# See Also
# --------
# plot : To plot scatter plots when markers are identical in size and
#     color.
#
# Notes
# -----
# * The `.plot` function will be faster for scatterplots where markers
#   don't vary in size or color.
#
# * Any or all of *x*, *y*, *s*, and *c* may be masked arrays, in which
#   case all masks will be combined and only unmasked points will be
#   plotted.
#
# * Fundamentally, scatter works with 1D arrays; *x*, *y*, *s*, and *c*
#   may be input as N-D arrays, but within scatter they will be
#   flattened. The exception is *c*, which will be flattened only if its
#   size matches the size of *x* and *y*.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 23</u></h3></summary><small><a href=#23>goto cell # 23</a></small>
# <ul>
#
# <li> <b>matplotlib</b>
# <ul>
# <li>
# <details><summary><u>matplotlib.pyplot.figure</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Create a new figure, or activate an existing figure.
#
# Parameters
# ----------
# num : int or str or `.Figure`, optional
#     A unique identifier for the figure.
#
#     If a figure with that identifier already exists, this figure is made
#     active and returned. An integer refers to the ``Figure.number``
#     attribute, a string refers to the figure label.
#
#     If there is no figure with the identifier or *num* is not given, a new
#     figure is created, made active and returned.  If *num* is an int, it
#     will be used for the ``Figure.number`` attribute, otherwise, an
#     auto-generated integer value is used (starting at 1 and incremented
#     for each new figure). If *num* is a string, the figure label and the
#     window title is set to this value.
#
# figsize : (float, float), default: :rc:`figure.figsize`
#     Width, height in inches.
#
# dpi : float, default: :rc:`figure.dpi`
#     The resolution of the figure in dots-per-inch.
#
# facecolor : color, default: :rc:`figure.facecolor`
#     The background color.
#
# edgecolor : color, default: :rc:`figure.edgecolor`
#     The border color.
#
# frameon : bool, default: True
#     If False, suppress drawing the figure frame.
#
# FigureClass : subclass of `~matplotlib.figure.Figure`
#     Optionally use a custom `.Figure` instance.
#
# clear : bool, default: False
#     If True and the figure already exists, then it is cleared.
#
# tight_layout : bool or dict, default: :rc:`figure.autolayout`
#     If ``False`` use *subplotpars*. If ``True`` adjust subplot
#     parameters using `.tight_layout` with default padding.
#     When providing a dict containing the keys ``pad``, ``w_pad``,
#     ``h_pad``, and ``rect``, the default `.tight_layout` paddings
#     will be overridden.
#
# constrained_layout : bool, default: :rc:`figure.constrained_layout.use`
#     If ``True`` use constrained layout to adjust positioning of plot
#     elements.  Like ``tight_layout``, but designed to be more
#     flexible.  See
#     :doc:`/tutorials/intermediate/constrainedlayout_guide`
#     for examples.  (Note: does not work with `add_subplot` or
#     `~.pyplot.subplot2grid`.)
#
#
# **kwargs : optional
#     See `~.matplotlib.figure.Figure` for other possible arguments.
#
# Returns
# -------
# `~matplotlib.figure.Figure`
#     The `.Figure` instance returned will also be passed to
#     new_figure_manager in the backends, which allows to hook custom
#     `.Figure` classes into the pyplot interface. Additional kwargs will be
#     passed to the `.Figure` init function.
#
# Notes
# -----
# If you are creating many figures, make sure you explicitly call
# `.pyplot.close` on the figures you are not using, because this will
# enable pyplot to properly clean up the memory.
#
# `~matplotlib.rcParams` defines the default values, which can be modified
# in the matplotlibrc file.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>matplotlib.pyplot.scatter</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'alpha': 0.9}</li></ul>
# <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'alpha': 0.3}</li></ul>
# <blockquote>
# <code>
# A scatter plot of *y* vs. *x* with varying marker size and/or color.
#
# Parameters
# ----------
# x, y : float or array-like, shape (n, )
#     The data positions.
#
# s : float or array-like, shape (n, ), optional
#     The marker size in points**2.
#     Default is ``rcParams['lines.markersize'] ** 2``.
#
# c : array-like or list of colors or color, optional
#     The marker colors. Possible values:
#
#     - A scalar or sequence of n numbers to be mapped to colors using
#       *cmap* and *norm*.
#     - A 2D array in which the rows are RGB or RGBA.
#     - A sequence of colors of length n.
#     - A single color format string.
#
#     Note that *c* should not be a single numeric RGB or RGBA sequence
#     because that is indistinguishable from an array of values to be
#     colormapped. If you want to specify the same RGB or RGBA value for
#     all points, use a 2D array with a single row.  Otherwise, value-
#     matching will have precedence in case of a size matching with *x*
#     and *y*.
#
#     If you wish to specify a single color for all points
#     prefer the *color* keyword argument.
#
#     Defaults to `None`. In that case the marker color is determined
#     by the value of *color*, *facecolor* or *facecolors*. In case
#     those are not specified or `None`, the marker color is determined
#     by the next color of the ``Axes``' current "shape and fill" color
#     cycle. This cycle defaults to :rc:`axes.prop_cycle`.
#
# marker : `~.markers.MarkerStyle`, default: :rc:`scatter.marker`
#     The marker style. *marker* can be either an instance of the class
#     or the text shorthand for a particular marker.
#     See :mod:`matplotlib.markers` for more information about marker
#     styles.
#
# cmap : str or `~matplotlib.colors.Colormap`, default: :rc:`image.cmap`
#     A `.Colormap` instance or registered colormap name. *cmap* is only
#     used if *c* is an array of floats.
#
# norm : `~matplotlib.colors.Normalize`, default: None
#     If *c* is an array of floats, *norm* is used to scale the color
#     data, *c*, in the range 0 to 1, in order to map into the colormap
#     *cmap*.
#     If *None*, use the default `.colors.Normalize`.
#
# vmin, vmax : float, default: None
#     *vmin* and *vmax* are used in conjunction with the default norm to
#     map the color array *c* to the colormap *cmap*. If None, the
#     respective min and max of the color array is used.
#     It is an error to use *vmin*/*vmax* when *norm* is given.
#
# alpha : float, default: None
#     The alpha blending value, between 0 (transparent) and 1 (opaque).
#
# linewidths : float or array-like, default: :rc:`lines.linewidth`
#     The linewidth of the marker edges. Note: The default *edgecolors*
#     is 'face'. You may want to change this as well.
#
# edgecolors : {'face', 'none', *None*} or color or sequence of color, default: :rc:`scatter.edgecolors`
#     The edge color of the marker. Possible values:
#
#     - 'face': The edge color will always be the same as the face color.
#     - 'none': No patch boundary will be drawn.
#     - A color or sequence of colors.
#
#     For non-filled markers, *edgecolors* is ignored. Instead, the color
#     is determined like with 'face', i.e. from *c*, *colors*, or
#     *facecolors*.
#
# plotnonfinite : bool, default: False
#     Whether to plot points with nonfinite *c* (i.e. ``inf``, ``-inf``
#     or ``nan``). If ``True`` the points are drawn with the *bad*
#     colormap color (see `.Colormap.set_bad`).
#
# Returns
# -------
# `~matplotlib.collections.PathCollection`
#
# Other Parameters
# ----------------
# data : indexable object, optional
#     If given, the following parameters also accept a string ``s``, which is
#     interpreted as ``data[s]`` (unless this raises an exception):
#
#     *x*, *y*, *s*, *linewidths*, *edgecolors*, *c*, *facecolor*, *facecolors*, *color*
# **kwargs : `~matplotlib.collections.Collection` properties
#
# See Also
# --------
# plot : To plot scatter plots when markers are identical in size and
#     color.
#
# Notes
# -----
# * The `.plot` function will be faster for scatterplots where markers
#   don't vary in size or color.
#
# * Any or all of *x*, *y*, *s*, and *c* may be masked arrays, in which
#   case all masks will be combined and only unmasked points will be
#   plotted.
#
# * Fundamentally, scatter works with 1D arrays; *x*, *y*, *s*, and *c*
#   may be input as N-D arrays, but within scatter they will be
#   flattened. The exception is *c*, which will be flattened only if its
#   size matches the size of *x* and *y*.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# <li><details><summary><h2><span style='color:#42a5f5'>Data Preparation</span></h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Data Preparation" Calls</u></b></summary>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.core.fromnumeric.mean</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Compute the arithmetic mean along the specified axis.
#
# Returns the average of the array elements.  The average is taken over
# the flattened array by default, otherwise over the specified axis.
# `float64` intermediate and return values are used for integer inputs.
#
# Parameters
# ----------
# a : array_like
#     Array containing numbers whose mean is desired. If `a` is not an
#     array, a conversion is attempted.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the means are computed. The default is to
#     compute the mean of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a mean is performed over multiple axes,
#     instead of a single axis or all the axes as before.
# dtype : data-type, optional
#     Type to use in computing the mean.  For integer inputs, the default
#     is `float64`; for floating point inputs, it is the same as the
#     input dtype.
# out : ndarray, optional
#     Alternate output array in which to place the result.  The default
#     is ``None``; if provided, it must have the same shape as the
#     expected output, but the type will be cast if necessary.
#     See :ref:`ufuncs-output-type` for more details.
#
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `mean` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the mean. See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# m : ndarray, see dtype parameter above
#     If `out=None`, returns a new array containing the mean values,
#     otherwise a reference to the output array is returned.
#
# See Also
# --------
# average : Weighted average
# std, var, nanmean, nanstd, nanvar
#
# Notes
# -----
# The arithmetic mean is the sum of the elements along the axis divided
# by the number of elements.
#
# Note that for floating-point input, the mean is computed using the
# same precision the input has.  Depending on the input data, this can
# cause the results to be inaccurate, especially for `float32` (see
# example below).  Specifying a higher-precision accumulator using the
# `dtype` keyword can alleviate this issue.
#
# By default, `float16` results are computed using `float32` intermediates
# for extra precision.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.mean(a)
# 2.5
# >>> np.mean(a, axis=0)
# array([2., 3.])
# >>> np.mean(a, axis=1)
# array([1.5, 3.5])
#
# In single precision, `mean` can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.mean(a)
# 0.54999924
#
# Computing the mean in float64 is more accurate:
#
# >>> np.mean(a, dtype=np.float64)
# 0.55000000074505806 # may vary
#
# Specifying a where argument:
# >>> a = np.array([[5, 9, 13], [14, 10, 12], [11, 15, 19]])
# >>> np.mean(a)
# 12.0
# >>> np.mean(a, where=[[True], [False], [False]])
# 9.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.core.fromnumeric.std</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Compute the standard deviation along the specified axis.
#
# Returns the standard deviation, a measure of the spread of a distribution,
# of the array elements. The standard deviation is computed for the
# flattened array by default, otherwise over the specified axis.
#
# Parameters
# ----------
# a : array_like
#     Calculate the standard deviation of these values.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the standard deviation is computed. The
#     default is to compute the standard deviation of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a standard deviation is performed over
#     multiple axes, instead of a single axis or all the axes as before.
# dtype : dtype, optional
#     Type to use in computing the standard deviation. For arrays of
#     integer type the default is float64, for arrays of float types it is
#     the same as the array type.
# out : ndarray, optional
#     Alternative output array in which to place the result. It must have
#     the same shape as the expected output but the type (of the calculated
#     values) will be cast if necessary.
# ddof : int, optional
#     Means Delta Degrees of Freedom.  The divisor used in calculations
#     is ``N - ddof``, where ``N`` represents the number of elements.
#     By default `ddof` is zero.
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `std` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the standard deviation.
#     See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# standard_deviation : ndarray, see dtype parameter above.
#     If `out` is None, return a new array containing the standard deviation,
#     otherwise return a reference to the output array.
#
# See Also
# --------
# var, mean, nanmean, nanstd, nanvar
# :ref:`ufuncs-output-type`
#
# Notes
# -----
# The standard deviation is the square root of the average of the squared
# deviations from the mean, i.e., ``std = sqrt(mean(x))``, where
# ``x = abs(a - a.mean())**2``.
#
# The average squared deviation is typically calculated as ``x.sum() / N``,
# where ``N = len(x)``. If, however, `ddof` is specified, the divisor
# ``N - ddof`` is used instead. In standard statistical practice, ``ddof=1``
# provides an unbiased estimator of the variance of the infinite population.
# ``ddof=0`` provides a maximum likelihood estimate of the variance for
# normally distributed variables. The standard deviation computed in this
# function is the square root of the estimated variance, so even with
# ``ddof=1``, it will not be an unbiased estimate of the standard deviation
# per se.
#
# Note that, for complex numbers, `std` takes the absolute
# value before squaring, so that the result is always real and nonnegative.
#
# For floating-point input, the *std* is computed using the same
# precision the input has. Depending on the input data, this can cause
# the results to be inaccurate, especially for float32 (see example below).
# Specifying a higher-accuracy accumulator using the `dtype` keyword can
# alleviate this issue.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.std(a)
# 1.1180339887498949 # may vary
# >>> np.std(a, axis=0)
# array([1.,  1.])
# >>> np.std(a, axis=1)
# array([0.5,  0.5])
#
# In single precision, std() can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.std(a)
# 0.45000005
#
# Computing the standard deviation in float64 is more accurate:
#
# >>> np.std(a, dtype=np.float64)
# 0.44999999925494177 # may vary
#
# Specifying a where argument:
#
# >>> a = np.array([[14, 8, 11, 10], [7, 9, 10, 11], [10, 15, 5, 10]])
# >>> np.std(a)
# 2.614064523559687 # may vary
# >>> np.std(a, where=[[True], [True], [False]])
# 2.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.arange</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# arange([start,] stop[, step,], dtype=None, *, like=None)
#
# Return evenly spaced values within a given interval.
#
# Values are generated within the half-open interval ``[start, stop)``
# (in other words, the interval including `start` but excluding `stop`).
# For integer arguments the function is equivalent to the Python built-in
# `range` function, but returns an ndarray rather than a list.
#
# When using a non-integer step, such as 0.1, it is often better to use
# `numpy.linspace`. See the warnings section below for more information.
#
# Parameters
# ----------
# start : integer or real, optional
#     Start of interval.  The interval includes this value.  The default
#     start value is 0.
# stop : integer or real
#     End of interval.  The interval does not include this value, except
#     in some cases where `step` is not an integer and floating point
#     round-off affects the length of `out`.
# step : integer or real, optional
#     Spacing between values.  For any output `out`, this is the distance
#     between two adjacent values, ``out[i+1] - out[i]``.  The default
#     step size is 1.  If `step` is specified as a position argument,
#     `start` must also be given.
# dtype : dtype
#     The type of the output array.  If `dtype` is not given, infer the data
#     type from the other input arguments.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# arange : ndarray
#     Array of evenly spaced values.
#
#     For floating point arguments, the length of the result is
#     ``ceil((stop - start)/step)``.  Because of floating point overflow,
#     this rule may result in the last element of `out` being greater
#     than `stop`.
#
# Warnings
# --------
# The length of the output might not be numerically stable.
#
# Another stability issue is due to the internal implementation of
# `numpy.arange`.
# The actual step value used to populate the array is
# ``dtype(start + step) - dtype(start)`` and not `step`. Precision loss
# can occur here, due to casting or due to using floating points when
# `start` is much larger than `step`. This can lead to unexpected
# behaviour. For example::
#
#   >>> np.arange(0, 5, 0.5, dtype=int)
#   array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
#   >>> np.arange(-3, 3, 0.5, dtype=int)
#   array([-3, -2, -1,  0,  1,  2,  3,  4,  5,  6,  7,  8])
#
# In such cases, the use of `numpy.linspace` should be preferred.
#
# See Also
# --------
# numpy.linspace : Evenly spaced numbers with careful handling of endpoints.
# numpy.ogrid: Arrays of evenly spaced numbers in N-dimensions.
# numpy.mgrid: Grid-shaped arrays of evenly spaced numbers in N-dimensions.
#
# Examples
# --------
# >>> np.arange(3)
# array([0, 1, 2])
# >>> np.arange(3.0)
# array([ 0.,  1.,  2.])
# >>> np.arange(3,7)
# array([3, 4, 5, 6])
# >>> np.arange(3,7,2)
# array([3, 5])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.array</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# array(object, dtype=None, *, copy=True, order='K', subok=False, ndmin=0,
#       like=None)
#
# Create an array.
#
# Parameters
# ----------
# object : array_like
#     An array, any object exposing the array interface, an object whose
#     __array__ method returns an array, or any (nested) sequence.
#     If object is a scalar, a 0-dimensional array containing object is
#     returned.
# dtype : data-type, optional
#     The desired data-type for the array.  If not given, then the type will
#     be determined as the minimum type required to hold the objects in the
#     sequence.
# copy : bool, optional
#     If true (default), then the object is copied.  Otherwise, a copy will
#     only be made if __array__ returns a copy, if obj is a nested sequence,
#     or if a copy is needed to satisfy any of the other requirements
#     (`dtype`, `order`, etc.).
# order : {'K', 'A', 'C', 'F'}, optional
#     Specify the memory layout of the array. If object is not an array, the
#     newly created array will be in C order (row major) unless 'F' is
#     specified, in which case it will be in Fortran order (column major).
#     If object is an array the following holds.
#
#     ===== ========= ===================================================
#     order  no copy                     copy=True
#     ===== ========= ===================================================
#     'K'   unchanged F & C order preserved, otherwise most similar order
#     'A'   unchanged F order if input is F and not C, otherwise C order
#     'C'   C order   C order
#     'F'   F order   F order
#     ===== ========= ===================================================
#
#     When ``copy=False`` and a copy is made for other reasons, the result is
#     the same as if ``copy=True``, with some exceptions for 'A', see the
#     Notes section. The default order is 'K'.
# subok : bool, optional
#     If True, then sub-classes will be passed-through, otherwise
#     the returned array will be forced to be a base-class array (default).
# ndmin : int, optional
#     Specifies the minimum number of dimensions that the resulting
#     array should have.  Ones will be pre-pended to the shape as
#     needed to meet this requirement.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     An array object satisfying the specified requirements.
#
# See Also
# --------
# empty_like : Return an empty array with shape and type of input.
# ones_like : Return an array of ones with shape and type of input.
# zeros_like : Return an array of zeros with shape and type of input.
# full_like : Return a new array with shape of input filled with value.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# zeros : Return a new array setting values to zero.
# full : Return a new array of given shape filled with value.
#
#
# Notes
# -----
# When order is 'A' and `object` is an array in neither 'C' nor 'F' order,
# and a copy is forced by a change in dtype, then the order of the result is
# not necessarily 'C' as expected. This is likely a bug.
#
# Examples
# --------
# >>> np.array([1, 2, 3])
# array([1, 2, 3])
#
# Upcasting:
#
# >>> np.array([1, 2, 3.0])
# array([ 1.,  2.,  3.])
#
# More than one dimension:
#
# >>> np.array([[1, 2], [3, 4]])
# array([[1, 2],
#        [3, 4]])
#
# Minimum dimensions 2:
#
# >>> np.array([1, 2, 3], ndmin=2)
# array([[1, 2, 3]])
#
# Type provided:
#
# >>> np.array([1, 2, 3], dtype=complex)
# array([ 1.+0.j,  2.+0.j,  3.+0.j])
#
# Data-type consisting of more than one element:
#
# >>> x = np.array([(1,2),(3,4)],dtype=[('a','<i4'),('b','<i4')])
# >>> x['a']
# array([1, 3])
#
# Creating an array from sub-classes:
#
# >>> np.array(np.mat('1 2; 3 4'))
# array([[1, 2],
#        [3, 4]])
#
# >>> np.array(np.mat('1 2; 3 4'), subok=True)
# matrix([[1, 2],
#         [3, 4]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.zeros</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# zeros(shape, dtype=float, order='C', *, like=None)
#
# Return a new array of given shape and type, filled with zeros.
#
# Parameters
# ----------
# shape : int or tuple of ints
#     Shape of the new array, e.g., ``(2, 3)`` or ``2``.
# dtype : data-type, optional
#     The desired data-type for the array, e.g., `numpy.int8`.  Default is
#     `numpy.float64`.
# order : {'C', 'F'}, optional, default: 'C'
#     Whether to store multi-dimensional data in row-major
#     (C-style) or column-major (Fortran-style) order in
#     memory.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     Array of zeros with the given shape, dtype, and order.
#
# See Also
# --------
# zeros_like : Return an array of zeros with shape and type of input.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# full : Return a new array of given shape filled with value.
#
# Examples
# --------
# >>> np.zeros(5)
# array([ 0.,  0.,  0.,  0.,  0.])
#
# >>> np.zeros((5,), dtype=int)
# array([0, 0, 0, 0, 0])
#
# >>> np.zeros((2, 1))
# array([[ 0.],
#        [ 0.]])
#
# >>> s = (2,2)
# >>> np.zeros(s)
# array([[ 0.,  0.],
#        [ 0.,  0.]])
#
# >>> np.zeros((2,), dtype=[('x', 'i4'), ('y', 'i4')]) # custom dtype
# array([(0, 0), (0, 0)],
#       dtype=[('x', '<i4'), ('y', '<i4')])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>sklearn</b>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Principal component analysis (PCA).
#
# Linear dimensionality reduction using Singular Value Decomposition of the
# data to project it to a lower dimensional space. The input data is centered
# but not scaled for each feature before applying the SVD.
#
# It uses the LAPACK implementation of the full SVD or a randomized truncated
# SVD by the method of Halko et al. 2009, depending on the shape of the input
# data and the number of components to extract.
#
# It can also use the scipy.sparse.linalg ARPACK implementation of the
# truncated SVD.
#
# Notice that this class does not support sparse input. See
# :class:`TruncatedSVD` for an alternative with sparse data.
#
# Read more in the :ref:`User Guide <PCA>`.
#
# Parameters
# ----------
# n_components : int, float or 'mle', default=None
#     Number of components to keep.
#     if n_components is not set all components are kept::
#
#         n_components == min(n_samples, n_features)
#
#     If ``n_components == 'mle'`` and ``svd_solver == 'full'``, Minka's
#     MLE is used to guess the dimension. Use of ``n_components == 'mle'``
#     will interpret ``svd_solver == 'auto'`` as ``svd_solver == 'full'``.
#
#     If ``0 < n_components < 1`` and ``svd_solver == 'full'``, select the
#     number of components such that the amount of variance that needs to be
#     explained is greater than the percentage specified by n_components.
#
#     If ``svd_solver == 'arpack'``, the number of components must be
#     strictly less than the minimum of n_features and n_samples.
#
#     Hence, the None case results in::
#
#         n_components == min(n_samples, n_features) - 1
#
# copy : bool, default=True
#     If False, data passed to fit are overwritten and running
#     fit(X).transform(X) will not yield the expected results,
#     use fit_transform(X) instead.
#
# whiten : bool, default=False
#     When True (False by default) the `components_` vectors are multiplied
#     by the square root of n_samples and then divided by the singular values
#     to ensure uncorrelated outputs with unit component-wise variances.
#
#     Whitening will remove some information from the transformed signal
#     (the relative variance scales of the components) but can sometime
#     improve the predictive accuracy of the downstream estimators by
#     making their data respect some hard-wired assumptions.
#
# svd_solver : {'auto', 'full', 'arpack', 'randomized'}, default='auto'
#     If auto :
#         The solver is selected by a default policy based on `X.shape` and
#         `n_components`: if the input data is larger than 500x500 and the
#         number of components to extract is lower than 80% of the smallest
#         dimension of the data, then the more efficient 'randomized'
#         method is enabled. Otherwise the exact full SVD is computed and
#         optionally truncated afterwards.
#     If full :
#         run exact full SVD calling the standard LAPACK solver via
#         `scipy.linalg.svd` and select the components by postprocessing
#     If arpack :
#         run SVD truncated to n_components calling ARPACK solver via
#         `scipy.sparse.linalg.svds`. It requires strictly
#         0 < n_components < min(X.shape)
#     If randomized :
#         run randomized SVD by the method of Halko et al.
#
#     .. versionadded:: 0.18.0
#
# tol : float, default=0.0
#     Tolerance for singular values computed by svd_solver == 'arpack'.
#     Must be of range [0.0, infinity).
#
#     .. versionadded:: 0.18.0
#
# iterated_power : int or 'auto', default='auto'
#     Number of iterations for the power method computed by
#     svd_solver == 'randomized'.
#     Must be of range [0, infinity).
#
#     .. versionadded:: 0.18.0
#
# random_state : int, RandomState instance or None, default=None
#     Used when the 'arpack' or 'randomized' solvers are used. Pass an int
#     for reproducible results across multiple function calls.
#     See :term:`Glossary <random_state>`.
#
#     .. versionadded:: 0.18.0
#
# Attributes
# ----------
# components_ : ndarray of shape (n_components, n_features)
#     Principal axes in feature space, representing the directions of
#     maximum variance in the data. Equivalently, the right singular
#     vectors of the centered input data, parallel to its eigenvectors.
#     The components are sorted by ``explained_variance_``.
#
# explained_variance_ : ndarray of shape (n_components,)
#     The amount of variance explained by each of the selected components.
#     The variance estimation uses `n_samples - 1` degrees of freedom.
#
#     Equal to n_components largest eigenvalues
#     of the covariance matrix of X.
#
#     .. versionadded:: 0.18
#
# explained_variance_ratio_ : ndarray of shape (n_components,)
#     Percentage of variance explained by each of the selected components.
#
#     If ``n_components`` is not set then all components are stored and the
#     sum of the ratios is equal to 1.0.
#
# singular_values_ : ndarray of shape (n_components,)
#     The singular values corresponding to each of the selected components.
#     The singular values are equal to the 2-norms of the ``n_components``
#     variables in the lower-dimensional space.
#
#     .. versionadded:: 0.19
#
# mean_ : ndarray of shape (n_features,)
#     Per-feature empirical mean, estimated from the training set.
#
#     Equal to `X.mean(axis=0)`.
#
# n_components_ : int
#     The estimated number of components. When n_components is set
#     to 'mle' or a number between 0 and 1 (with svd_solver == 'full') this
#     number is estimated from input data. Otherwise it equals the parameter
#     n_components, or the lesser value of n_features and n_samples
#     if n_components is None.
#
# n_features_ : int
#     Number of features in the training data.
#
# n_samples_ : int
#     Number of samples in the training data.
#
# noise_variance_ : float
#     The estimated noise covariance following the Probabilistic PCA model
#     from Tipping and Bishop 1999. See "Pattern Recognition and
#     Machine Learning" by C. Bishop, 12.2.1 p. 574 or
#     http://www.miketipping.com/papers/met-mppca.pdf. It is required to
#     compute the estimated data covariance and score samples.
#
#     Equal to the average of (min(n_features, n_samples) - n_components)
#     smallest eigenvalues of the covariance matrix of X.
#
# n_features_in_ : int
#     Number of features seen during :term:`fit`.
#
#     .. versionadded:: 0.24
#
# feature_names_in_ : ndarray of shape (`n_features_in_`,)
#     Names of features seen during :term:`fit`. Defined only when `X`
#     has feature names that are all strings.
#
#     .. versionadded:: 1.0
#
# See Also
# --------
# KernelPCA : Kernel Principal Component Analysis.
# SparsePCA : Sparse Principal Component Analysis.
# TruncatedSVD : Dimensionality reduction using truncated SVD.
# IncrementalPCA : Incremental Principal Component Analysis.
#
# References
# ----------
# For n_components == 'mle', this class uses the method from:
# `Minka, T. P.. "Automatic choice of dimensionality for PCA".
# In NIPS, pp. 598-604 <https://tminka.github.io/papers/pca/minka-pca.pdf>`_
#
# Implements the probabilistic PCA model from:
# `Tipping, M. E., and Bishop, C. M. (1999). "Probabilistic principal
# component analysis". Journal of the Royal Statistical Society:
# Series B (Statistical Methodology), 61(3), 611-622.
# <http://www.miketipping.com/papers/met-mppca.pdf>`_
# via the score and score_samples methods.
#
# For svd_solver == 'arpack', refer to `scipy.sparse.linalg.svds`.
#
# For svd_solver == 'randomized', see:
# `Halko, N., Martinsson, P. G., and Tropp, J. A. (2011).
# "Finding structure with randomness: Probabilistic algorithms for
# constructing approximate matrix decompositions".
# SIAM review, 53(2), 217-288.
# <https://doi.org/10.1137/090771806>`_
# and also
# `Martinsson, P. G., Rokhlin, V., and Tygert, M. (2011).
# "A randomized algorithm for the decomposition of matrices".
# Applied and Computational Harmonic Analysis, 30(1), 47-68
# <https://doi.org/10.1016/j.acha.2010.02.003>`_.
#
# Examples
# --------
# >>> import numpy as np
# >>> from sklearn.decomposition import PCA
# >>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
# >>> pca = PCA(n_components=2)
# >>> pca.fit(X)
# PCA(n_components=2)
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.0075...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=2, svd_solver='full')
# >>> pca.fit(X)
# PCA(n_components=2, svd_solver='full')
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.00755...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=1, svd_solver='arpack')
# >>> pca.fit(X)
# PCA(n_components=1, svd_solver='arpack')
# >>> print(pca.explained_variance_ratio_)
# [0.99244...]
# >>> print(pca.singular_values_)
# [6.30061...]
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 5</u></h3></summary><small><a href=#5>goto cell # 5</a></small>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.core.fromnumeric.mean</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Compute the arithmetic mean along the specified axis.
#
# Returns the average of the array elements.  The average is taken over
# the flattened array by default, otherwise over the specified axis.
# `float64` intermediate and return values are used for integer inputs.
#
# Parameters
# ----------
# a : array_like
#     Array containing numbers whose mean is desired. If `a` is not an
#     array, a conversion is attempted.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the means are computed. The default is to
#     compute the mean of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a mean is performed over multiple axes,
#     instead of a single axis or all the axes as before.
# dtype : data-type, optional
#     Type to use in computing the mean.  For integer inputs, the default
#     is `float64`; for floating point inputs, it is the same as the
#     input dtype.
# out : ndarray, optional
#     Alternate output array in which to place the result.  The default
#     is ``None``; if provided, it must have the same shape as the
#     expected output, but the type will be cast if necessary.
#     See :ref:`ufuncs-output-type` for more details.
#
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `mean` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the mean. See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# m : ndarray, see dtype parameter above
#     If `out=None`, returns a new array containing the mean values,
#     otherwise a reference to the output array is returned.
#
# See Also
# --------
# average : Weighted average
# std, var, nanmean, nanstd, nanvar
#
# Notes
# -----
# The arithmetic mean is the sum of the elements along the axis divided
# by the number of elements.
#
# Note that for floating-point input, the mean is computed using the
# same precision the input has.  Depending on the input data, this can
# cause the results to be inaccurate, especially for `float32` (see
# example below).  Specifying a higher-precision accumulator using the
# `dtype` keyword can alleviate this issue.
#
# By default, `float16` results are computed using `float32` intermediates
# for extra precision.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.mean(a)
# 2.5
# >>> np.mean(a, axis=0)
# array([2., 3.])
# >>> np.mean(a, axis=1)
# array([1.5, 3.5])
#
# In single precision, `mean` can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.mean(a)
# 0.54999924
#
# Computing the mean in float64 is more accurate:
#
# >>> np.mean(a, dtype=np.float64)
# 0.55000000074505806 # may vary
#
# Specifying a where argument:
# >>> a = np.array([[5, 9, 13], [14, 10, 12], [11, 15, 19]])
# >>> np.mean(a)
# 12.0
# >>> np.mean(a, where=[[True], [False], [False]])
# 9.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.core.fromnumeric.std</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Compute the standard deviation along the specified axis.
#
# Returns the standard deviation, a measure of the spread of a distribution,
# of the array elements. The standard deviation is computed for the
# flattened array by default, otherwise over the specified axis.
#
# Parameters
# ----------
# a : array_like
#     Calculate the standard deviation of these values.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the standard deviation is computed. The
#     default is to compute the standard deviation of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a standard deviation is performed over
#     multiple axes, instead of a single axis or all the axes as before.
# dtype : dtype, optional
#     Type to use in computing the standard deviation. For arrays of
#     integer type the default is float64, for arrays of float types it is
#     the same as the array type.
# out : ndarray, optional
#     Alternative output array in which to place the result. It must have
#     the same shape as the expected output but the type (of the calculated
#     values) will be cast if necessary.
# ddof : int, optional
#     Means Delta Degrees of Freedom.  The divisor used in calculations
#     is ``N - ddof``, where ``N`` represents the number of elements.
#     By default `ddof` is zero.
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `std` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the standard deviation.
#     See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# standard_deviation : ndarray, see dtype parameter above.
#     If `out` is None, return a new array containing the standard deviation,
#     otherwise return a reference to the output array.
#
# See Also
# --------
# var, mean, nanmean, nanstd, nanvar
# :ref:`ufuncs-output-type`
#
# Notes
# -----
# The standard deviation is the square root of the average of the squared
# deviations from the mean, i.e., ``std = sqrt(mean(x))``, where
# ``x = abs(a - a.mean())**2``.
#
# The average squared deviation is typically calculated as ``x.sum() / N``,
# where ``N = len(x)``. If, however, `ddof` is specified, the divisor
# ``N - ddof`` is used instead. In standard statistical practice, ``ddof=1``
# provides an unbiased estimator of the variance of the infinite population.
# ``ddof=0`` provides a maximum likelihood estimate of the variance for
# normally distributed variables. The standard deviation computed in this
# function is the square root of the estimated variance, so even with
# ``ddof=1``, it will not be an unbiased estimate of the standard deviation
# per se.
#
# Note that, for complex numbers, `std` takes the absolute
# value before squaring, so that the result is always real and nonnegative.
#
# For floating-point input, the *std* is computed using the same
# precision the input has. Depending on the input data, this can cause
# the results to be inaccurate, especially for float32 (see example below).
# Specifying a higher-accuracy accumulator using the `dtype` keyword can
# alleviate this issue.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.std(a)
# 1.1180339887498949 # may vary
# >>> np.std(a, axis=0)
# array([1.,  1.])
# >>> np.std(a, axis=1)
# array([0.5,  0.5])
#
# In single precision, std() can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.std(a)
# 0.45000005
#
# Computing the standard deviation in float64 is more accurate:
#
# >>> np.std(a, dtype=np.float64)
# 0.44999999925494177 # may vary
#
# Specifying a where argument:
#
# >>> a = np.array([[14, 8, 11, 10], [7, 9, 10, 11], [10, 15, 5, 10]])
# >>> np.std(a)
# 2.614064523559687 # may vary
# >>> np.std(a, where=[[True], [True], [False]])
# 2.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.arange</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# arange([start,] stop[, step,], dtype=None, *, like=None)
#
# Return evenly spaced values within a given interval.
#
# Values are generated within the half-open interval ``[start, stop)``
# (in other words, the interval including `start` but excluding `stop`).
# For integer arguments the function is equivalent to the Python built-in
# `range` function, but returns an ndarray rather than a list.
#
# When using a non-integer step, such as 0.1, it is often better to use
# `numpy.linspace`. See the warnings section below for more information.
#
# Parameters
# ----------
# start : integer or real, optional
#     Start of interval.  The interval includes this value.  The default
#     start value is 0.
# stop : integer or real
#     End of interval.  The interval does not include this value, except
#     in some cases where `step` is not an integer and floating point
#     round-off affects the length of `out`.
# step : integer or real, optional
#     Spacing between values.  For any output `out`, this is the distance
#     between two adjacent values, ``out[i+1] - out[i]``.  The default
#     step size is 1.  If `step` is specified as a position argument,
#     `start` must also be given.
# dtype : dtype
#     The type of the output array.  If `dtype` is not given, infer the data
#     type from the other input arguments.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# arange : ndarray
#     Array of evenly spaced values.
#
#     For floating point arguments, the length of the result is
#     ``ceil((stop - start)/step)``.  Because of floating point overflow,
#     this rule may result in the last element of `out` being greater
#     than `stop`.
#
# Warnings
# --------
# The length of the output might not be numerically stable.
#
# Another stability issue is due to the internal implementation of
# `numpy.arange`.
# The actual step value used to populate the array is
# ``dtype(start + step) - dtype(start)`` and not `step`. Precision loss
# can occur here, due to casting or due to using floating points when
# `start` is much larger than `step`. This can lead to unexpected
# behaviour. For example::
#
#   >>> np.arange(0, 5, 0.5, dtype=int)
#   array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
#   >>> np.arange(-3, 3, 0.5, dtype=int)
#   array([-3, -2, -1,  0,  1,  2,  3,  4,  5,  6,  7,  8])
#
# In such cases, the use of `numpy.linspace` should be preferred.
#
# See Also
# --------
# numpy.linspace : Evenly spaced numbers with careful handling of endpoints.
# numpy.ogrid: Arrays of evenly spaced numbers in N-dimensions.
# numpy.mgrid: Grid-shaped arrays of evenly spaced numbers in N-dimensions.
#
# Examples
# --------
# >>> np.arange(3)
# array([0, 1, 2])
# >>> np.arange(3.0)
# array([ 0.,  1.,  2.])
# >>> np.arange(3,7)
# array([3, 4, 5, 6])
# >>> np.arange(3,7,2)
# array([3, 5])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [0] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 7</u></h3></summary><small><a href=#7>goto cell # 7</a></small>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.array</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [[]] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> [[]] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# array(object, dtype=None, *, copy=True, order='K', subok=False, ndmin=0,
#       like=None)
#
# Create an array.
#
# Parameters
# ----------
# object : array_like
#     An array, any object exposing the array interface, an object whose
#     __array__ method returns an array, or any (nested) sequence.
#     If object is a scalar, a 0-dimensional array containing object is
#     returned.
# dtype : data-type, optional
#     The desired data-type for the array.  If not given, then the type will
#     be determined as the minimum type required to hold the objects in the
#     sequence.
# copy : bool, optional
#     If true (default), then the object is copied.  Otherwise, a copy will
#     only be made if __array__ returns a copy, if obj is a nested sequence,
#     or if a copy is needed to satisfy any of the other requirements
#     (`dtype`, `order`, etc.).
# order : {'K', 'A', 'C', 'F'}, optional
#     Specify the memory layout of the array. If object is not an array, the
#     newly created array will be in C order (row major) unless 'F' is
#     specified, in which case it will be in Fortran order (column major).
#     If object is an array the following holds.
#
#     ===== ========= ===================================================
#     order  no copy                     copy=True
#     ===== ========= ===================================================
#     'K'   unchanged F & C order preserved, otherwise most similar order
#     'A'   unchanged F order if input is F and not C, otherwise C order
#     'C'   C order   C order
#     'F'   F order   F order
#     ===== ========= ===================================================
#
#     When ``copy=False`` and a copy is made for other reasons, the result is
#     the same as if ``copy=True``, with some exceptions for 'A', see the
#     Notes section. The default order is 'K'.
# subok : bool, optional
#     If True, then sub-classes will be passed-through, otherwise
#     the returned array will be forced to be a base-class array (default).
# ndmin : int, optional
#     Specifies the minimum number of dimensions that the resulting
#     array should have.  Ones will be pre-pended to the shape as
#     needed to meet this requirement.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     An array object satisfying the specified requirements.
#
# See Also
# --------
# empty_like : Return an empty array with shape and type of input.
# ones_like : Return an array of ones with shape and type of input.
# zeros_like : Return an array of zeros with shape and type of input.
# full_like : Return a new array with shape of input filled with value.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# zeros : Return a new array setting values to zero.
# full : Return a new array of given shape filled with value.
#
#
# Notes
# -----
# When order is 'A' and `object` is an array in neither 'C' nor 'F' order,
# and a copy is forced by a change in dtype, then the order of the result is
# not necessarily 'C' as expected. This is likely a bug.
#
# Examples
# --------
# >>> np.array([1, 2, 3])
# array([1, 2, 3])
#
# Upcasting:
#
# >>> np.array([1, 2, 3.0])
# array([ 1.,  2.,  3.])
#
# More than one dimension:
#
# >>> np.array([[1, 2], [3, 4]])
# array([[1, 2],
#        [3, 4]])
#
# Minimum dimensions 2:
#
# >>> np.array([1, 2, 3], ndmin=2)
# array([[1, 2, 3]])
#
# Type provided:
#
# >>> np.array([1, 2, 3], dtype=complex)
# array([ 1.+0.j,  2.+0.j,  3.+0.j])
#
# Data-type consisting of more than one element:
#
# >>> x = np.array([(1,2),(3,4)],dtype=[('a','<i4'),('b','<i4')])
# >>> x['a']
# array([1, 3])
#
# Creating an array from sub-classes:
#
# >>> np.array(np.mat('1 2; 3 4'))
# array([[1, 2],
#        [3, 4]])
#
# >>> np.array(np.mat('1 2; 3 4'), subok=True)
# matrix([[1, 2],
#         [3, 4]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.zeros</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# zeros(shape, dtype=float, order='C', *, like=None)
#
# Return a new array of given shape and type, filled with zeros.
#
# Parameters
# ----------
# shape : int or tuple of ints
#     Shape of the new array, e.g., ``(2, 3)`` or ``2``.
# dtype : data-type, optional
#     The desired data-type for the array, e.g., `numpy.int8`.  Default is
#     `numpy.float64`.
# order : {'C', 'F'}, optional, default: 'C'
#     Whether to store multi-dimensional data in row-major
#     (C-style) or column-major (Fortran-style) order in
#     memory.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     Array of zeros with the given shape, dtype, and order.
#
# See Also
# --------
# zeros_like : Return an array of zeros with shape and type of input.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# full : Return a new array of given shape filled with value.
#
# Examples
# --------
# >>> np.zeros(5)
# array([ 0.,  0.,  0.,  0.,  0.])
#
# >>> np.zeros((5,), dtype=int)
# array([0, 0, 0, 0, 0])
#
# >>> np.zeros((2, 1))
# array([[ 0.],
#        [ 0.]])
#
# >>> s = (2,2)
# >>> np.zeros(s)
# array([[ 0.,  0.],
#        [ 0.,  0.]])
#
# >>> np.zeros((2,), dtype=[('x', 'i4'), ('y', 'i4')]) # custom dtype
# array([(0, 0), (0, 0)],
#       dtype=[('x', '<i4'), ('y', '<i4')])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 20</u></h3></summary><small><a href=#20>goto cell # 20</a></small>
# <ul>
#
# <li> <b>sklearn</b>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'n_components': 2}</li></ul>
# <blockquote>
# <code>
# Principal component analysis (PCA).
#
# Linear dimensionality reduction using Singular Value Decomposition of the
# data to project it to a lower dimensional space. The input data is centered
# but not scaled for each feature before applying the SVD.
#
# It uses the LAPACK implementation of the full SVD or a randomized truncated
# SVD by the method of Halko et al. 2009, depending on the shape of the input
# data and the number of components to extract.
#
# It can also use the scipy.sparse.linalg ARPACK implementation of the
# truncated SVD.
#
# Notice that this class does not support sparse input. See
# :class:`TruncatedSVD` for an alternative with sparse data.
#
# Read more in the :ref:`User Guide <PCA>`.
#
# Parameters
# ----------
# n_components : int, float or 'mle', default=None
#     Number of components to keep.
#     if n_components is not set all components are kept::
#
#         n_components == min(n_samples, n_features)
#
#     If ``n_components == 'mle'`` and ``svd_solver == 'full'``, Minka's
#     MLE is used to guess the dimension. Use of ``n_components == 'mle'``
#     will interpret ``svd_solver == 'auto'`` as ``svd_solver == 'full'``.
#
#     If ``0 < n_components < 1`` and ``svd_solver == 'full'``, select the
#     number of components such that the amount of variance that needs to be
#     explained is greater than the percentage specified by n_components.
#
#     If ``svd_solver == 'arpack'``, the number of components must be
#     strictly less than the minimum of n_features and n_samples.
#
#     Hence, the None case results in::
#
#         n_components == min(n_samples, n_features) - 1
#
# copy : bool, default=True
#     If False, data passed to fit are overwritten and running
#     fit(X).transform(X) will not yield the expected results,
#     use fit_transform(X) instead.
#
# whiten : bool, default=False
#     When True (False by default) the `components_` vectors are multiplied
#     by the square root of n_samples and then divided by the singular values
#     to ensure uncorrelated outputs with unit component-wise variances.
#
#     Whitening will remove some information from the transformed signal
#     (the relative variance scales of the components) but can sometime
#     improve the predictive accuracy of the downstream estimators by
#     making their data respect some hard-wired assumptions.
#
# svd_solver : {'auto', 'full', 'arpack', 'randomized'}, default='auto'
#     If auto :
#         The solver is selected by a default policy based on `X.shape` and
#         `n_components`: if the input data is larger than 500x500 and the
#         number of components to extract is lower than 80% of the smallest
#         dimension of the data, then the more efficient 'randomized'
#         method is enabled. Otherwise the exact full SVD is computed and
#         optionally truncated afterwards.
#     If full :
#         run exact full SVD calling the standard LAPACK solver via
#         `scipy.linalg.svd` and select the components by postprocessing
#     If arpack :
#         run SVD truncated to n_components calling ARPACK solver via
#         `scipy.sparse.linalg.svds`. It requires strictly
#         0 < n_components < min(X.shape)
#     If randomized :
#         run randomized SVD by the method of Halko et al.
#
#     .. versionadded:: 0.18.0
#
# tol : float, default=0.0
#     Tolerance for singular values computed by svd_solver == 'arpack'.
#     Must be of range [0.0, infinity).
#
#     .. versionadded:: 0.18.0
#
# iterated_power : int or 'auto', default='auto'
#     Number of iterations for the power method computed by
#     svd_solver == 'randomized'.
#     Must be of range [0, infinity).
#
#     .. versionadded:: 0.18.0
#
# random_state : int, RandomState instance or None, default=None
#     Used when the 'arpack' or 'randomized' solvers are used. Pass an int
#     for reproducible results across multiple function calls.
#     See :term:`Glossary <random_state>`.
#
#     .. versionadded:: 0.18.0
#
# Attributes
# ----------
# components_ : ndarray of shape (n_components, n_features)
#     Principal axes in feature space, representing the directions of
#     maximum variance in the data. Equivalently, the right singular
#     vectors of the centered input data, parallel to its eigenvectors.
#     The components are sorted by ``explained_variance_``.
#
# explained_variance_ : ndarray of shape (n_components,)
#     The amount of variance explained by each of the selected components.
#     The variance estimation uses `n_samples - 1` degrees of freedom.
#
#     Equal to n_components largest eigenvalues
#     of the covariance matrix of X.
#
#     .. versionadded:: 0.18
#
# explained_variance_ratio_ : ndarray of shape (n_components,)
#     Percentage of variance explained by each of the selected components.
#
#     If ``n_components`` is not set then all components are stored and the
#     sum of the ratios is equal to 1.0.
#
# singular_values_ : ndarray of shape (n_components,)
#     The singular values corresponding to each of the selected components.
#     The singular values are equal to the 2-norms of the ``n_components``
#     variables in the lower-dimensional space.
#
#     .. versionadded:: 0.19
#
# mean_ : ndarray of shape (n_features,)
#     Per-feature empirical mean, estimated from the training set.
#
#     Equal to `X.mean(axis=0)`.
#
# n_components_ : int
#     The estimated number of components. When n_components is set
#     to 'mle' or a number between 0 and 1 (with svd_solver == 'full') this
#     number is estimated from input data. Otherwise it equals the parameter
#     n_components, or the lesser value of n_features and n_samples
#     if n_components is None.
#
# n_features_ : int
#     Number of features in the training data.
#
# n_samples_ : int
#     Number of samples in the training data.
#
# noise_variance_ : float
#     The estimated noise covariance following the Probabilistic PCA model
#     from Tipping and Bishop 1999. See "Pattern Recognition and
#     Machine Learning" by C. Bishop, 12.2.1 p. 574 or
#     http://www.miketipping.com/papers/met-mppca.pdf. It is required to
#     compute the estimated data covariance and score samples.
#
#     Equal to the average of (min(n_features, n_samples) - n_components)
#     smallest eigenvalues of the covariance matrix of X.
#
# n_features_in_ : int
#     Number of features seen during :term:`fit`.
#
#     .. versionadded:: 0.24
#
# feature_names_in_ : ndarray of shape (`n_features_in_`,)
#     Names of features seen during :term:`fit`. Defined only when `X`
#     has feature names that are all strings.
#
#     .. versionadded:: 1.0
#
# See Also
# --------
# KernelPCA : Kernel Principal Component Analysis.
# SparsePCA : Sparse Principal Component Analysis.
# TruncatedSVD : Dimensionality reduction using truncated SVD.
# IncrementalPCA : Incremental Principal Component Analysis.
#
# References
# ----------
# For n_components == 'mle', this class uses the method from:
# `Minka, T. P.. "Automatic choice of dimensionality for PCA".
# In NIPS, pp. 598-604 <https://tminka.github.io/papers/pca/minka-pca.pdf>`_
#
# Implements the probabilistic PCA model from:
# `Tipping, M. E., and Bishop, C. M. (1999). "Probabilistic principal
# component analysis". Journal of the Royal Statistical Society:
# Series B (Statistical Methodology), 61(3), 611-622.
# <http://www.miketipping.com/papers/met-mppca.pdf>`_
# via the score and score_samples methods.
#
# For svd_solver == 'arpack', refer to `scipy.sparse.linalg.svds`.
#
# For svd_solver == 'randomized', see:
# `Halko, N., Martinsson, P. G., and Tropp, J. A. (2011).
# "Finding structure with randomness: Probabilistic algorithms for
# constructing approximate matrix decompositions".
# SIAM review, 53(2), 217-288.
# <https://doi.org/10.1137/090771806>`_
# and also
# `Martinsson, P. G., Rokhlin, V., and Tygert, M. (2011).
# "A randomized algorithm for the decomposition of matrices".
# Applied and Computational Harmonic Analysis, 30(1), 47-68
# <https://doi.org/10.1016/j.acha.2010.02.003>`_.
#
# Examples
# --------
# >>> import numpy as np
# >>> from sklearn.decomposition import PCA
# >>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
# >>> pca = PCA(n_components=2)
# >>> pca.fit(X)
# PCA(n_components=2)
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.0075...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=2, svd_solver='full')
# >>> pca.fit(X)
# PCA(n_components=2, svd_solver='full')
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.00755...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=1, svd_solver='arpack')
# >>> pca.fit(X)
# PCA(n_components=1, svd_solver='arpack')
# >>> print(pca.explained_variance_ratio_)
# [0.99244...]
# >>> print(pca.singular_values_)
# [6.30061...]
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li>
# <ul><li><details><summary><h2>Data Profiling and Exploratory Data Analysis</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Data Profiling and Exploratory Data Analysis" Calls</u></b></summary>
# <ul>
#
#
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h4><s>Data Cleaning Filtering</s> (no calls found)</h4></summary>
# <ul>
#
# None
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h4><s>Data Sub-sampling and Train-test Splitting</s> (no calls found)</h4></summary>
# <ul>
#
# None
#
# </ul>
# </details></li></ul>
# <li><details><summary><h2><span style='color:#42a5f5'>Feature Engineering</span></h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Feature Engineering" Calls</u></b></summary>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>sklearn</b>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 16</u></h3></summary><small><a href=#16>goto cell # 16</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 20</u></h3></summary><small><a href=#20>goto cell # 20</a></small>
# <ul>
#
# <li> <b>sklearn</b>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li>
# <ul><li><details><summary><h2>Feature Transformation</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Feature Transformation" Calls</u></b></summary>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 5</u></h3></summary><small><a href=#5>goto cell # 5</a></small>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [0] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 7</u></h3></summary><small><a href=#7>goto cell # 7</a></small>
# <ul>
#
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h2>Feature Selection</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Feature Selection" Calls</u></b></summary>
# <ul>
#
#
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# <li><details><summary><h2><span style='color:#42a5f5'>Model Building and Training</span></h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Model Building and Training" Calls</u></b></summary>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.backend.set_value</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Sets the value of a variable, from a Numpy array.
#
# `backend.set_value` is the complement of `backend.get_value`, and provides
# a generic interface for assigning to variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: Variable to set to a new value.
#     value: Value to set the tensor to, as a Numpy array
#         (of the same shape).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.get_value</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Returns the value of a variable.
#
# `backend.get_value` is the complement of `backend.set_value`, and provides
# a generic interface for reading from variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: input variable.
#
# Returns:
#     A Numpy array.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 8</u></h3></summary><small><a href=#8>goto cell # 8</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.backend.set_value</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Sets the value of a variable, from a Numpy array.
#
# `backend.set_value` is the complement of `backend.get_value`, and provides
# a generic interface for assigning to variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: Variable to set to a new value.
#     value: Value to set the tensor to, as a Numpy array
#         (of the same shape).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.get_value</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Returns the value of a variable.
#
# `backend.get_value` is the complement of `backend.set_value`, and provides
# a generic interface for reading from variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: input variable.
#
# Returns:
#     A Numpy array.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li>
# <ul><li><details><summary><h2>Model Training</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Model Training" Calls</u></b></summary>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.backend.sigmoid</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Element-wise sigmoid.
#
# Args:
#     x: A tensor or variable.
#
# Returns:
#     A tensor.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.merge.Concatenate</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Layer that concatenates a list of inputs.
#
# It takes as input a list of tensors, all of the same shape except
# for the concatenation axis, and returns a single tensor that is the
# concatenation of all inputs.
#
# >>> x = np.arange(20).reshape(2, 2, 5)
# >>> print(x)
# [[[ 0  1  2  3  4]
#   [ 5  6  7  8  9]]
#  [[10 11 12 13 14]
#   [15 16 17 18 19]]]
# >>> y = np.arange(20, 30).reshape(2, 1, 5)
# >>> print(y)
# [[[20 21 22 23 24]]
#  [[25 26 27 28 29]]]
# >>> tf.keras.layers.Concatenate(axis=1)([x, y])
# <tf.Tensor: shape=(2, 3, 5), dtype=int64, numpy=
# array([[[ 0,  1,  2,  3,  4],
#         [ 5,  6,  7,  8,  9],
#         [20, 21, 22, 23, 24]],
#        [[10, 11, 12, 13, 14],
#         [15, 16, 17, 18, 19],
#         [25, 26, 27, 28, 29]]])>
#
# >>> x1 = tf.keras.layers.Dense(8)(np.arange(10).reshape(5, 2))
# >>> x2 = tf.keras.layers.Dense(8)(np.arange(10, 20).reshape(5, 2))
# >>> concatted = tf.keras.layers.Concatenate()([x1, x2])
# >>> concatted.shape
# TensorShape([5, 16])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.optimizer_v2.nadam.Nadam</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Optimizer that implements the NAdam algorithm.
# Much like Adam is essentially RMSprop with momentum, Nadam is Adam with
# Nesterov momentum.
#
# Args:
#   learning_rate: A Tensor or a floating point value.  The learning rate.
#   beta_1: A float value or a constant float tensor. The exponential decay
#     rate for the 1st moment estimates.
#   beta_2: A float value or a constant float tensor. The exponential decay
#     rate for the exponentially weighted infinity norm.
#   epsilon: A small constant for numerical stability.
#   name: Optional name for the operations created when applying gradients.
#     Defaults to `"Nadam"`.
#   **kwargs: Keyword arguments. Allowed to be one of
#     `"clipnorm"` or `"clipvalue"`.
#     `"clipnorm"` (float) clips gradients by norm; `"clipvalue"` (float) clips
#     gradients by value.
#
# Usage Example:
#   >>> opt = tf.keras.optimizers.Nadam(learning_rate=0.2)
#   >>> var1 = tf.Variable(10.0)
#   >>> loss = lambda: (var1 ** 2) / 2.0
#   >>> step_count = opt.minimize(loss, [var1]).numpy()
#   >>> "{:.1f}".format(var1.numpy())
#   9.8
#
# Reference:
#   - [Dozat, 2015](http://cs229.stanford.edu/proj2015/054_report.pdf).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.compile</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Configures the model for training.
#
# Example:
#
# ```python
# model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
#               loss=tf.keras.losses.BinaryCrossentropy(),
#               metrics=[tf.keras.metrics.BinaryAccuracy(),
#                        tf.keras.metrics.FalseNegatives()])
# ```
#
# Args:
#     optimizer: String (name of optimizer) or optimizer instance. See
#       `tf.keras.optimizers`.
#     loss: Loss function. Maybe be a string (name of loss function), or
#       a `tf.keras.losses.Loss` instance. See `tf.keras.losses`. A loss
#       function is any callable with the signature `loss = fn(y_true,
#       y_pred)`, where `y_true` are the ground truth values, and
#       `y_pred` are the model's predictions.
#       `y_true` should have shape
#       `(batch_size, d0, .. dN)` (except in the case of
#       sparse loss functions such as
#       sparse categorical crossentropy which expects integer arrays of shape
#       `(batch_size, d0, .. dN-1)`).
#       `y_pred` should have shape `(batch_size, d0, .. dN)`.
#       The loss function should return a float tensor.
#       If a custom `Loss` instance is
#       used and reduction is set to `None`, return value has shape
#       `(batch_size, d0, .. dN-1)` i.e. per-sample or per-timestep loss
#       values; otherwise, it is a scalar. If the model has multiple outputs,
#       you can use a different loss on each output by passing a dictionary
#       or a list of losses. The loss value that will be minimized by the
#       model will then be the sum of all individual losses, unless
#       `loss_weights` is specified.
#     metrics: List of metrics to be evaluated by the model during training
#       and testing. Each of this can be a string (name of a built-in
#       function), function or a `tf.keras.metrics.Metric` instance. See
#       `tf.keras.metrics`. Typically you will use `metrics=['accuracy']`. A
#       function is any callable with the signature `result = fn(y_true,
#       y_pred)`. To specify different metrics for different outputs of a
#       multi-output model, you could also pass a dictionary, such as
#       `metrics={'output_a': 'accuracy', 'output_b': ['accuracy', 'mse']}`.
#       You can also pass a list to specify a metric or a list of metrics
#       for each output, such as `metrics=[['accuracy'], ['accuracy', 'mse']]`
#       or `metrics=['accuracy', ['accuracy', 'mse']]`. When you pass the
#       strings 'accuracy' or 'acc', we convert this to one of
#       `tf.keras.metrics.BinaryAccuracy`,
#       `tf.keras.metrics.CategoricalAccuracy`,
#       `tf.keras.metrics.SparseCategoricalAccuracy` based on the loss
#       function used and the model output shape. We do a similar
#       conversion for the strings 'crossentropy' and 'ce' as well.
#     loss_weights: Optional list or dictionary specifying scalar coefficients
#       (Python floats) to weight the loss contributions of different model
#       outputs. The loss value that will be minimized by the model will then
#       be the *weighted sum* of all individual losses, weighted by the
#       `loss_weights` coefficients.
#         If a list, it is expected to have a 1:1 mapping to the model's
#           outputs. If a dict, it is expected to map output names (strings)
#           to scalar coefficients.
#     weighted_metrics: List of metrics to be evaluated and weighted by
#       `sample_weight` or `class_weight` during training and testing.
#     run_eagerly: Bool. Defaults to `False`. If `True`, this `Model`'s
#       logic will not be wrapped in a `tf.function`. Recommended to leave
#       this as `None` unless your `Model` cannot be run inside a
#       `tf.function`. `run_eagerly=True` is not supported when using
#       `tf.distribute.experimental.ParameterServerStrategy`.
#     steps_per_execution: Int. Defaults to 1. The number of batches to run
#       during each `tf.function` call. Running multiple batches inside a
#       single `tf.function` call can greatly improve performance on TPUs or
#       small models with a large Python overhead. At most, one full epoch
#       will be run each execution. If a number larger than the size of the
#       epoch is passed, the execution will be truncated to the size of the
#       epoch. Note that if `steps_per_execution` is set to `N`,
#       `Callback.on_batch_begin` and `Callback.on_batch_end` methods will
#       only be called every `N` batches (i.e. before/after each `tf.function`
#       execution).
#     jit_compile: If `True`, compile the model training step with XLA.
#       [XLA](https://www.tensorflow.org/xla) is an optimizing compiler for
#       machine learning.
#       `jit_compile` is not enabled for by default.
#       This option cannot be enabled with `run_eagerly=True`.
#       Note that `jit_compile=True` is
#       may not necessarily work for all models.
#       For more information on supported operations please refer to the
#       [XLA documentation](https://www.tensorflow.org/xla).
#       Also refer to
#       [known XLA issues](https://www.tensorflow.org/xla/known_issues) for
#       more details.
#     **kwargs: Arguments supported for backwards compatibility only.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 11</u></h3></summary><small><a href=#11>goto cell # 11</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.backend.sigmoid</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Element-wise sigmoid.
#
# Args:
#     x: A tensor or variable.
#
# Returns:
#     A tensor.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 12</u></h3></summary><small><a href=#12>goto cell # 12</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [0.01] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [128] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [128] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [64] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [64] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [32] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 13</u></h3></summary><small><a href=#13>goto cell # 13</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [128] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [128] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [64] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [64] | <b>Kwargs:</b> {'kernel_initializer': 'glorot_normal'}</li></ul>
# <ul><li><b>Args:</b> [32] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <ul><li><b>Args:</b> ['relu'] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [0.01] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 14</u></h3></summary><small><a href=#14>goto cell # 14</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'inputs': []}</li></ul>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.merge.Concatenate</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Layer that concatenates a list of inputs.
#
# It takes as input a list of tensors, all of the same shape except
# for the concatenation axis, and returns a single tensor that is the
# concatenation of all inputs.
#
# >>> x = np.arange(20).reshape(2, 2, 5)
# >>> print(x)
# [[[ 0  1  2  3  4]
#   [ 5  6  7  8  9]]
#  [[10 11 12 13 14]
#   [15 16 17 18 19]]]
# >>> y = np.arange(20, 30).reshape(2, 1, 5)
# >>> print(y)
# [[[20 21 22 23 24]]
#  [[25 26 27 28 29]]]
# >>> tf.keras.layers.Concatenate(axis=1)([x, y])
# <tf.Tensor: shape=(2, 3, 5), dtype=int64, numpy=
# array([[[ 0,  1,  2,  3,  4],
#         [ 5,  6,  7,  8,  9],
#         [20, 21, 22, 23, 24]],
#        [[10, 11, 12, 13, 14],
#         [15, 16, 17, 18, 19],
#         [25, 26, 27, 28, 29]]])>
#
# >>> x1 = tf.keras.layers.Dense(8)(np.arange(10).reshape(5, 2))
# >>> x2 = tf.keras.layers.Dense(8)(np.arange(10, 20).reshape(5, 2))
# >>> concatted = tf.keras.layers.Concatenate()([x1, x2])
# >>> concatted.shape
# TensorShape([5, 16])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.optimizer_v2.nadam.Nadam</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [0.001] | <b>Kwargs:</b> {}</li></ul>
# <blockquote>
# <code>
# Optimizer that implements the NAdam algorithm.
# Much like Adam is essentially RMSprop with momentum, Nadam is Adam with
# Nesterov momentum.
#
# Args:
#   learning_rate: A Tensor or a floating point value.  The learning rate.
#   beta_1: A float value or a constant float tensor. The exponential decay
#     rate for the 1st moment estimates.
#   beta_2: A float value or a constant float tensor. The exponential decay
#     rate for the exponentially weighted infinity norm.
#   epsilon: A small constant for numerical stability.
#   name: Optional name for the operations created when applying gradients.
#     Defaults to `"Nadam"`.
#   **kwargs: Keyword arguments. Allowed to be one of
#     `"clipnorm"` or `"clipvalue"`.
#     `"clipnorm"` (float) clips gradients by norm; `"clipvalue"` (float) clips
#     gradients by value.
#
# Usage Example:
#   >>> opt = tf.keras.optimizers.Nadam(learning_rate=0.2)
#   >>> var1 = tf.Variable(10.0)
#   >>> loss = lambda: (var1 ** 2) / 2.0
#   >>> step_count = opt.minimize(loss, [var1]).numpy()
#   >>> "{:.1f}".format(var1.numpy())
#   9.8
#
# Reference:
#   - [Dozat, 2015](http://cs229.stanford.edu/proj2015/054_report.pdf).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.compile</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Configures the model for training.
#
# Example:
#
# ```python
# model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
#               loss=tf.keras.losses.BinaryCrossentropy(),
#               metrics=[tf.keras.metrics.BinaryAccuracy(),
#                        tf.keras.metrics.FalseNegatives()])
# ```
#
# Args:
#     optimizer: String (name of optimizer) or optimizer instance. See
#       `tf.keras.optimizers`.
#     loss: Loss function. Maybe be a string (name of loss function), or
#       a `tf.keras.losses.Loss` instance. See `tf.keras.losses`. A loss
#       function is any callable with the signature `loss = fn(y_true,
#       y_pred)`, where `y_true` are the ground truth values, and
#       `y_pred` are the model's predictions.
#       `y_true` should have shape
#       `(batch_size, d0, .. dN)` (except in the case of
#       sparse loss functions such as
#       sparse categorical crossentropy which expects integer arrays of shape
#       `(batch_size, d0, .. dN-1)`).
#       `y_pred` should have shape `(batch_size, d0, .. dN)`.
#       The loss function should return a float tensor.
#       If a custom `Loss` instance is
#       used and reduction is set to `None`, return value has shape
#       `(batch_size, d0, .. dN-1)` i.e. per-sample or per-timestep loss
#       values; otherwise, it is a scalar. If the model has multiple outputs,
#       you can use a different loss on each output by passing a dictionary
#       or a list of losses. The loss value that will be minimized by the
#       model will then be the sum of all individual losses, unless
#       `loss_weights` is specified.
#     metrics: List of metrics to be evaluated by the model during training
#       and testing. Each of this can be a string (name of a built-in
#       function), function or a `tf.keras.metrics.Metric` instance. See
#       `tf.keras.metrics`. Typically you will use `metrics=['accuracy']`. A
#       function is any callable with the signature `result = fn(y_true,
#       y_pred)`. To specify different metrics for different outputs of a
#       multi-output model, you could also pass a dictionary, such as
#       `metrics={'output_a': 'accuracy', 'output_b': ['accuracy', 'mse']}`.
#       You can also pass a list to specify a metric or a list of metrics
#       for each output, such as `metrics=[['accuracy'], ['accuracy', 'mse']]`
#       or `metrics=['accuracy', ['accuracy', 'mse']]`. When you pass the
#       strings 'accuracy' or 'acc', we convert this to one of
#       `tf.keras.metrics.BinaryAccuracy`,
#       `tf.keras.metrics.CategoricalAccuracy`,
#       `tf.keras.metrics.SparseCategoricalAccuracy` based on the loss
#       function used and the model output shape. We do a similar
#       conversion for the strings 'crossentropy' and 'ce' as well.
#     loss_weights: Optional list or dictionary specifying scalar coefficients
#       (Python floats) to weight the loss contributions of different model
#       outputs. The loss value that will be minimized by the model will then
#       be the *weighted sum* of all individual losses, weighted by the
#       `loss_weights` coefficients.
#         If a list, it is expected to have a 1:1 mapping to the model's
#           outputs. If a dict, it is expected to map output names (strings)
#           to scalar coefficients.
#     weighted_metrics: List of metrics to be evaluated and weighted by
#       `sample_weight` or `class_weight` during training and testing.
#     run_eagerly: Bool. Defaults to `False`. If `True`, this `Model`'s
#       logic will not be wrapped in a `tf.function`. Recommended to leave
#       this as `None` unless your `Model` cannot be run inside a
#       `tf.function`. `run_eagerly=True` is not supported when using
#       `tf.distribute.experimental.ParameterServerStrategy`.
#     steps_per_execution: Int. Defaults to 1. The number of batches to run
#       during each `tf.function` call. Running multiple batches inside a
#       single `tf.function` call can greatly improve performance on TPUs or
#       small models with a large Python overhead. At most, one full epoch
#       will be run each execution. If a number larger than the size of the
#       epoch is passed, the execution will be truncated to the size of the
#       epoch. Note that if `steps_per_execution` is set to `N`,
#       `Callback.on_batch_begin` and `Callback.on_batch_end` methods will
#       only be called every `N` batches (i.e. before/after each `tf.function`
#       execution).
#     jit_compile: If `True`, compile the model training step with XLA.
#       [XLA](https://www.tensorflow.org/xla) is an optimizing compiler for
#       machine learning.
#       `jit_compile` is not enabled for by default.
#       This option cannot be enabled with `run_eagerly=True`.
#       Note that `jit_compile=True` is
#       may not necessarily work for all models.
#       For more information on supported operations please refer to the
#       [XLA documentation](https://www.tensorflow.org/xla).
#       Also refer to
#       [known XLA issues](https://www.tensorflow.org/xla/known_issues) for
#       more details.
#     **kwargs: Arguments supported for backwards compatibility only.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 16</u></h3></summary><small><a href=#16>goto cell # 16</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u> | (No Args Found) </summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h4><s>Model Parameter Tuning</s> (no calls found)</h4></summary>
# <ul>
#
# None
#
# </ul>
# </details></li></ul>
# <ul><li><details><summary><h2>Model Validation and Assembling</h2></summary>
# <ul>
#
# <li><details><summary><b><u>View All "Model Validation and Assembling" Calls</u></b></summary>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.predict</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'verbose': 1}</li></ul>
# <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'verbose': 1}</li></ul>
# <blockquote>
# <code>
# Generates output predictions for the input samples.
#
# Computation is done in batches. This method is designed for batch processing
# of large numbers of inputs. It is not intended for use inside of loops
# that iterate over your data and process small numbers of inputs at a time.
#
# For small numbers of inputs that fit in one batch,
# directly use `__call__()` for faster execution, e.g.,
# `model(x)`, or `model(x, training=False)` if you have layers such as
# `tf.keras.layers.BatchNormalization` that behave differently during
# inference. You may pair the individual model call with a `tf.function`
# for additional performance inside your inner loop.
# If you need access to numpy array values instead of tensors after your
# model call, you can use `tensor.numpy()` to get the numpy array value of
# an eager tensor.
#
# Also, note the fact that test loss is not affected by
# regularization layers like noise and dropout.
#
# Note: See [this FAQ entry](
# https://keras.io/getting_started/faq/#whats-the-difference-between-model-methods-predict-and-call)
# for more details about the difference between `Model` methods `predict()`
# and `__call__()`.
#
# Args:
#     x: Input samples. It could be:
#       - A Numpy array (or array-like), or a list of arrays
#         (in case the model has multiple inputs).
#       - A TensorFlow tensor, or a list of tensors
#         (in case the model has multiple inputs).
#       - A `tf.data` dataset.
#       - A generator or `keras.utils.Sequence` instance.
#       A more detailed description of unpacking behavior for iterator types
#       (Dataset, generator, Sequence) is given in the `Unpacking behavior
#       for iterator-like inputs` section of `Model.fit`.
#     batch_size: Integer or `None`.
#         Number of samples per batch.
#         If unspecified, `batch_size` will default to 32.
#         Do not specify the `batch_size` if your data is in the
#         form of dataset, generators, or `keras.utils.Sequence` instances
#         (since they generate batches).
#     verbose: Verbosity mode, 0 or 1.
#     steps: Total number of steps (batches of samples)
#         before declaring the prediction round finished.
#         Ignored with the default value of `None`. If x is a `tf.data`
#         dataset and `steps` is None, `predict()` will
#         run until the input dataset is exhausted.
#     callbacks: List of `keras.callbacks.Callback` instances.
#         List of callbacks to apply during prediction.
#         See [callbacks](/api_docs/python/tf/keras/callbacks).
#     max_queue_size: Integer. Used for generator or `keras.utils.Sequence`
#         input only. Maximum size for the generator queue.
#         If unspecified, `max_queue_size` will default to 10.
#     workers: Integer. Used for generator or `keras.utils.Sequence` input
#         only. Maximum number of processes to spin up when using
#         process-based threading. If unspecified, `workers` will default
#         to 1.
#     use_multiprocessing: Boolean. Used for generator or
#         `keras.utils.Sequence` input only. If `True`, use process-based
#         threading. If unspecified, `use_multiprocessing` will default to
#         `False`. Note that because this implementation relies on
#         multiprocessing, you should not pass non-picklable arguments to
#         the generator as they can't be passed easily to children processes.
#
# See the discussion of `Unpacking behavior for iterator-like inputs` for
# `Model.fit`. Note that Model.predict uses the same interpretation rules as
# `Model.fit` and `Model.evaluate`, so inputs must be unambiguous for all
# three methods.
#
# Returns:
#     Numpy array(s) of predictions.
#
# Raises:
#     RuntimeError: If `model.predict` is wrapped in a `tf.function`.
#     ValueError: In case of mismatch between the provided
#         input data and the model's expectations,
#         or in case a stateful model receives a number of samples
#         that is not a multiple of the batch size.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
# <li><details open><summary><h3><u>Cell # 17</u></h3></summary><small><a href=#17>goto cell # 17</a></small>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.predict</u> | <b>(See Args)</b> </summary> <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'verbose': 1}</li></ul>
# <ul><li><b>Args:</b> [] | <b>Kwargs:</b> {'verbose': 1}</li></ul>
# <blockquote>
# <code>
# Generates output predictions for the input samples.
#
# Computation is done in batches. This method is designed for batch processing
# of large numbers of inputs. It is not intended for use inside of loops
# that iterate over your data and process small numbers of inputs at a time.
#
# For small numbers of inputs that fit in one batch,
# directly use `__call__()` for faster execution, e.g.,
# `model(x)`, or `model(x, training=False)` if you have layers such as
# `tf.keras.layers.BatchNormalization` that behave differently during
# inference. You may pair the individual model call with a `tf.function`
# for additional performance inside your inner loop.
# If you need access to numpy array values instead of tensors after your
# model call, you can use `tensor.numpy()` to get the numpy array value of
# an eager tensor.
#
# Also, note the fact that test loss is not affected by
# regularization layers like noise and dropout.
#
# Note: See [this FAQ entry](
# https://keras.io/getting_started/faq/#whats-the-difference-between-model-methods-predict-and-call)
# for more details about the difference between `Model` methods `predict()`
# and `__call__()`.
#
# Args:
#     x: Input samples. It could be:
#       - A Numpy array (or array-like), or a list of arrays
#         (in case the model has multiple inputs).
#       - A TensorFlow tensor, or a list of tensors
#         (in case the model has multiple inputs).
#       - A `tf.data` dataset.
#       - A generator or `keras.utils.Sequence` instance.
#       A more detailed description of unpacking behavior for iterator types
#       (Dataset, generator, Sequence) is given in the `Unpacking behavior
#       for iterator-like inputs` section of `Model.fit`.
#     batch_size: Integer or `None`.
#         Number of samples per batch.
#         If unspecified, `batch_size` will default to 32.
#         Do not specify the `batch_size` if your data is in the
#         form of dataset, generators, or `keras.utils.Sequence` instances
#         (since they generate batches).
#     verbose: Verbosity mode, 0 or 1.
#     steps: Total number of steps (batches of samples)
#         before declaring the prediction round finished.
#         Ignored with the default value of `None`. If x is a `tf.data`
#         dataset and `steps` is None, `predict()` will
#         run until the input dataset is exhausted.
#     callbacks: List of `keras.callbacks.Callback` instances.
#         List of callbacks to apply during prediction.
#         See [callbacks](/api_docs/python/tf/keras/callbacks).
#     max_queue_size: Integer. Used for generator or `keras.utils.Sequence`
#         input only. Maximum size for the generator queue.
#         If unspecified, `max_queue_size` will default to 10.
#     workers: Integer. Used for generator or `keras.utils.Sequence` input
#         only. Maximum number of processes to spin up when using
#         process-based threading. If unspecified, `workers` will default
#         to 1.
#     use_multiprocessing: Boolean. Used for generator or
#         `keras.utils.Sequence` input only. If `True`, use process-based
#         threading. If unspecified, `use_multiprocessing` will default to
#         `False`. Note that because this implementation relies on
#         multiprocessing, you should not pass non-picklable arguments to
#         the generator as they can't be passed easily to children processes.
#
# See the discussion of `Unpacking behavior for iterator-like inputs` for
# `Model.fit`. Note that Model.predict uses the same interpretation rules as
# `Model.fit` and `Model.evaluate`, so inputs must be unambiguous for all
# three methods.
#
# Returns:
#     Numpy array(s) of predictions.
#
# Raises:
#     RuntimeError: If `model.predict` is wrapped in a `tf.function`.
#     ValueError: In case of mismatch between the provided
#         input data and the model's expectations,
#         or in case a stateful model receives a number of samples
#         that is not a multiple of the batch size.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details></li>
#
# </ul>
# </details></li></ul>
# </ul>
# <hr>
#
# <details><summary><h2>View All ML API Calls in Notebook</h2></summary>
# <ul>
#
# <li> <b>keras</b>
# <ul>
# <li>
# <details><summary><u>keras.backend</u></summary>
# <blockquote>
# <code>
# Keras backend API.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.get_value</u></summary>
# <blockquote>
# <code>
# Returns the value of a variable.
#
# `backend.get_value` is the complement of `backend.set_value`, and provides
# a generic interface for reading from variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: input variable.
#
# Returns:
#     A Numpy array.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.set_value</u></summary>
# <blockquote>
# <code>
# Sets the value of a variable, from a Numpy array.
#
# `backend.set_value` is the complement of `backend.get_value`, and provides
# a generic interface for assigning to variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: Variable to set to a new value.
#     value: Value to set the tensor to, as a Numpy array
#         (of the same shape).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.sigmoid</u></summary>
# <blockquote>
# <code>
# Element-wise sigmoid.
#
# Args:
#     x: A tensor or variable.
#
# Returns:
#     A tensor.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.callbacks.Callback</u></summary>
# <blockquote>
# <code>
# Abstract base class used to build new callbacks.
#
# Callbacks can be passed to keras methods such as `fit`, `evaluate`, and
# `predict` in order to hook into the various stages of the model training and
# inference lifecycle.
#
# To create a custom callback, subclass `keras.callbacks.Callback` and override
# the method associated with the stage of interest. See
# https://www.tensorflow.org/guide/keras/custom_callback for more information.
#
# Example:
#
# >>> training_finished = False
# >>> class MyCallback(tf.keras.callbacks.Callback):
# ...   def on_train_end(self, logs=None):
# ...     global training_finished
# ...     training_finished = True
# >>> model = tf.keras.Sequential([tf.keras.layers.Dense(1, input_shape=(1,))])
# >>> model.compile(loss='mean_squared_error')
# >>> model.fit(tf.constant([[1.0]]), tf.constant([[1.0]]),
# ...           callbacks=[MyCallback()])
# >>> assert training_finished == True
#
# If you want to use `Callback` objects in a custom training loop:
#
# 1. You should pack all your callbacks into a single `callbacks.CallbackList`
#    so they can all be called together.
# 2. You will need to manually call all the `on_*` methods at the appropriate
#    locations in your loop. Like this:
#
#    ```
#    callbacks =  tf.keras.callbacks.CallbackList([...])
#    callbacks.append(...)
#
#    callbacks.on_train_begin(...)
#    for epoch in range(EPOCHS):
#      callbacks.on_epoch_begin(epoch)
#      for i, data in dataset.enumerate():
#        callbacks.on_train_batch_begin(i)
#        batch_logs = model.train_step(data)
#        callbacks.on_train_batch_end(i, batch_logs)
#      epoch_logs = ...
#      callbacks.on_epoch_end(epoch, epoch_logs)
#    final_logs=...
#    callbacks.on_train_end(final_logs)
#    ```
#
# Attributes:
#     params: Dict. Training parameters
#         (eg. verbosity, batch size, number of epochs...).
#     model: Instance of `keras.models.Model`.
#         Reference of the model being trained.
#
# The `logs` dictionary that callback methods
# take as argument will contain keys for quantities relevant to
# the current batch or epoch (see method-specific docstrings).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u></summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u></summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.compile</u></summary>
# <blockquote>
# <code>
# Configures the model for training.
#
# Example:
#
# ```python
# model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
#               loss=tf.keras.losses.BinaryCrossentropy(),
#               metrics=[tf.keras.metrics.BinaryAccuracy(),
#                        tf.keras.metrics.FalseNegatives()])
# ```
#
# Args:
#     optimizer: String (name of optimizer) or optimizer instance. See
#       `tf.keras.optimizers`.
#     loss: Loss function. Maybe be a string (name of loss function), or
#       a `tf.keras.losses.Loss` instance. See `tf.keras.losses`. A loss
#       function is any callable with the signature `loss = fn(y_true,
#       y_pred)`, where `y_true` are the ground truth values, and
#       `y_pred` are the model's predictions.
#       `y_true` should have shape
#       `(batch_size, d0, .. dN)` (except in the case of
#       sparse loss functions such as
#       sparse categorical crossentropy which expects integer arrays of shape
#       `(batch_size, d0, .. dN-1)`).
#       `y_pred` should have shape `(batch_size, d0, .. dN)`.
#       The loss function should return a float tensor.
#       If a custom `Loss` instance is
#       used and reduction is set to `None`, return value has shape
#       `(batch_size, d0, .. dN-1)` i.e. per-sample or per-timestep loss
#       values; otherwise, it is a scalar. If the model has multiple outputs,
#       you can use a different loss on each output by passing a dictionary
#       or a list of losses. The loss value that will be minimized by the
#       model will then be the sum of all individual losses, unless
#       `loss_weights` is specified.
#     metrics: List of metrics to be evaluated by the model during training
#       and testing. Each of this can be a string (name of a built-in
#       function), function or a `tf.keras.metrics.Metric` instance. See
#       `tf.keras.metrics`. Typically you will use `metrics=['accuracy']`. A
#       function is any callable with the signature `result = fn(y_true,
#       y_pred)`. To specify different metrics for different outputs of a
#       multi-output model, you could also pass a dictionary, such as
#       `metrics={'output_a': 'accuracy', 'output_b': ['accuracy', 'mse']}`.
#       You can also pass a list to specify a metric or a list of metrics
#       for each output, such as `metrics=[['accuracy'], ['accuracy', 'mse']]`
#       or `metrics=['accuracy', ['accuracy', 'mse']]`. When you pass the
#       strings 'accuracy' or 'acc', we convert this to one of
#       `tf.keras.metrics.BinaryAccuracy`,
#       `tf.keras.metrics.CategoricalAccuracy`,
#       `tf.keras.metrics.SparseCategoricalAccuracy` based on the loss
#       function used and the model output shape. We do a similar
#       conversion for the strings 'crossentropy' and 'ce' as well.
#     loss_weights: Optional list or dictionary specifying scalar coefficients
#       (Python floats) to weight the loss contributions of different model
#       outputs. The loss value that will be minimized by the model will then
#       be the *weighted sum* of all individual losses, weighted by the
#       `loss_weights` coefficients.
#         If a list, it is expected to have a 1:1 mapping to the model's
#           outputs. If a dict, it is expected to map output names (strings)
#           to scalar coefficients.
#     weighted_metrics: List of metrics to be evaluated and weighted by
#       `sample_weight` or `class_weight` during training and testing.
#     run_eagerly: Bool. Defaults to `False`. If `True`, this `Model`'s
#       logic will not be wrapped in a `tf.function`. Recommended to leave
#       this as `None` unless your `Model` cannot be run inside a
#       `tf.function`. `run_eagerly=True` is not supported when using
#       `tf.distribute.experimental.ParameterServerStrategy`.
#     steps_per_execution: Int. Defaults to 1. The number of batches to run
#       during each `tf.function` call. Running multiple batches inside a
#       single `tf.function` call can greatly improve performance on TPUs or
#       small models with a large Python overhead. At most, one full epoch
#       will be run each execution. If a number larger than the size of the
#       epoch is passed, the execution will be truncated to the size of the
#       epoch. Note that if `steps_per_execution` is set to `N`,
#       `Callback.on_batch_begin` and `Callback.on_batch_end` methods will
#       only be called every `N` batches (i.e. before/after each `tf.function`
#       execution).
#     jit_compile: If `True`, compile the model training step with XLA.
#       [XLA](https://www.tensorflow.org/xla) is an optimizing compiler for
#       machine learning.
#       `jit_compile` is not enabled for by default.
#       This option cannot be enabled with `run_eagerly=True`.
#       Note that `jit_compile=True` is
#       may not necessarily work for all models.
#       For more information on supported operations please refer to the
#       [XLA documentation](https://www.tensorflow.org/xla).
#       Also refer to
#       [known XLA issues](https://www.tensorflow.org/xla/known_issues) for
#       more details.
#     **kwargs: Arguments supported for backwards compatibility only.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u></summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.predict</u></summary>
# <blockquote>
# <code>
# Generates output predictions for the input samples.
#
# Computation is done in batches. This method is designed for batch processing
# of large numbers of inputs. It is not intended for use inside of loops
# that iterate over your data and process small numbers of inputs at a time.
#
# For small numbers of inputs that fit in one batch,
# directly use `__call__()` for faster execution, e.g.,
# `model(x)`, or `model(x, training=False)` if you have layers such as
# `tf.keras.layers.BatchNormalization` that behave differently during
# inference. You may pair the individual model call with a `tf.function`
# for additional performance inside your inner loop.
# If you need access to numpy array values instead of tensors after your
# model call, you can use `tensor.numpy()` to get the numpy array value of
# an eager tensor.
#
# Also, note the fact that test loss is not affected by
# regularization layers like noise and dropout.
#
# Note: See [this FAQ entry](
# https://keras.io/getting_started/faq/#whats-the-difference-between-model-methods-predict-and-call)
# for more details about the difference between `Model` methods `predict()`
# and `__call__()`.
#
# Args:
#     x: Input samples. It could be:
#       - A Numpy array (or array-like), or a list of arrays
#         (in case the model has multiple inputs).
#       - A TensorFlow tensor, or a list of tensors
#         (in case the model has multiple inputs).
#       - A `tf.data` dataset.
#       - A generator or `keras.utils.Sequence` instance.
#       A more detailed description of unpacking behavior for iterator types
#       (Dataset, generator, Sequence) is given in the `Unpacking behavior
#       for iterator-like inputs` section of `Model.fit`.
#     batch_size: Integer or `None`.
#         Number of samples per batch.
#         If unspecified, `batch_size` will default to 32.
#         Do not specify the `batch_size` if your data is in the
#         form of dataset, generators, or `keras.utils.Sequence` instances
#         (since they generate batches).
#     verbose: Verbosity mode, 0 or 1.
#     steps: Total number of steps (batches of samples)
#         before declaring the prediction round finished.
#         Ignored with the default value of `None`. If x is a `tf.data`
#         dataset and `steps` is None, `predict()` will
#         run until the input dataset is exhausted.
#     callbacks: List of `keras.callbacks.Callback` instances.
#         List of callbacks to apply during prediction.
#         See [callbacks](/api_docs/python/tf/keras/callbacks).
#     max_queue_size: Integer. Used for generator or `keras.utils.Sequence`
#         input only. Maximum size for the generator queue.
#         If unspecified, `max_queue_size` will default to 10.
#     workers: Integer. Used for generator or `keras.utils.Sequence` input
#         only. Maximum number of processes to spin up when using
#         process-based threading. If unspecified, `workers` will default
#         to 1.
#     use_multiprocessing: Boolean. Used for generator or
#         `keras.utils.Sequence` input only. If `True`, use process-based
#         threading. If unspecified, `use_multiprocessing` will default to
#         `False`. Note that because this implementation relies on
#         multiprocessing, you should not pass non-picklable arguments to
#         the generator as they can't be passed easily to children processes.
#
# See the discussion of `Unpacking behavior for iterator-like inputs` for
# `Model.fit`. Note that Model.predict uses the same interpretation rules as
# `Model.fit` and `Model.evaluate`, so inputs must be unambiguous for all
# three methods.
#
# Returns:
#     Numpy array(s) of predictions.
#
# Raises:
#     RuntimeError: If `model.predict` is wrapped in a `tf.function`.
#     ValueError: In case of mismatch between the provided
#         input data and the model's expectations,
#         or in case a stateful model receives a number of samples
#         that is not a multiple of the batch size.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.advanced_activations.LeakyReLU</u></summary>
# <blockquote>
# <code>
# Leaky version of a Rectified Linear Unit.
#
# It allows a small gradient when the unit is not active:
#
# ```
#   f(x) = alpha * x if x < 0
#   f(x) = x if x >= 0
# ```
#
# Usage:
#
# >>> layer = tf.keras.layers.LeakyReLU()
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [-0.9, -0.3, 0.0, 2.0]
# >>> layer = tf.keras.layers.LeakyReLU(alpha=0.1)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [-0.3, -0.1, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as the input.
#
# Args:
#   alpha: Float >= 0. Negative slope coefficient. Default to 0.3.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.convolutional.Conv1D</u></summary>
# <blockquote>
# <code>
# 1D convolution layer (e.g. temporal convolution).
#
# This layer creates a convolution kernel that is convolved
# with the layer input over a single spatial (or temporal) dimension
# to produce a tensor of outputs.
# If `use_bias` is True, a bias vector is created and added to the outputs.
# Finally, if `activation` is not `None`,
# it is applied to the outputs as well.
#
# When using this layer as the first layer in a model,
# provide an `input_shape` argument
# (tuple of integers or `None`, e.g.
# `(10, 128)` for sequences of 10 vectors of 128-dimensional vectors,
# or `(None, 128)` for variable-length sequences of 128-dimensional vectors.
#
# Examples:
#
# >>> # The inputs are 128-length vectors with 10 timesteps, and the batch size
# >>> # is 4.
# >>> input_shape = (4, 10, 128)
# >>> x = tf.random.normal(input_shape)
# >>> y = tf.keras.layers.Conv1D(
# ... 32, 3, activation='relu',input_shape=input_shape[1:])(x)
# >>> print(y.shape)
# (4, 8, 32)
#
# >>> # With extended batch shape [4, 7] (e.g. weather data where batch
# >>> # dimensions correspond to spatial location and the third dimension
# >>> # corresponds to time.)
# >>> input_shape = (4, 7, 10, 128)
# >>> x = tf.random.normal(input_shape)
# >>> y = tf.keras.layers.Conv1D(
# ... 32, 3, activation='relu', input_shape=input_shape[2:])(x)
# >>> print(y.shape)
# (4, 7, 8, 32)
#
# Args:
#   filters: Integer, the dimensionality of the output space
#     (i.e. the number of output filters in the convolution).
#   kernel_size: An integer or tuple/list of a single integer,
#     specifying the length of the 1D convolution window.
#   strides: An integer or tuple/list of a single integer,
#     specifying the stride length of the convolution.
#     Specifying any stride value != 1 is incompatible with specifying
#     any `dilation_rate` value != 1.
#   padding: One of `"valid"`, `"same"` or `"causal"` (case-insensitive).
#     `"valid"` means no padding. `"same"` results in padding with zeros evenly
#     to the left/right or up/down of the input such that output has the same
#     height/width dimension as the input.
#     `"causal"` results in causal (dilated) convolutions, e.g. `output[t]`
#     does not depend on `input[t+1:]`. Useful when modeling temporal data
#     where the model should not violate the temporal order.
#     See [WaveNet: A Generative Model for Raw Audio, section
#       2.1](https://arxiv.org/abs/1609.03499).
#   data_format: A string,
#     one of `channels_last` (default) or `channels_first`.
#   dilation_rate: an integer or tuple/list of a single integer, specifying
#     the dilation rate to use for dilated convolution.
#     Currently, specifying any `dilation_rate` value != 1 is
#     incompatible with specifying any `strides` value != 1.
#   groups: A positive integer specifying the number of groups in which the
#     input is split along the channel axis. Each group is convolved
#     separately with `filters / groups` filters. The output is the
#     concatenation of all the `groups` results along the channel axis.
#     Input channels and `filters` must both be divisible by `groups`.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (see `keras.activations`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix
#     (see `keras.initializers`). Defaults to 'glorot_uniform'.
#   bias_initializer: Initializer for the bias vector
#     (see `keras.initializers`). Defaults to 'zeros'.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix (see `keras.regularizers`).
#   bias_regularizer: Regularizer function applied to the bias vector
#     (see `keras.regularizers`).
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation")
#     (see `keras.regularizers`).
#   kernel_constraint: Constraint function applied to the kernel matrix
#     (see `keras.constraints`).
#   bias_constraint: Constraint function applied to the bias vector
#     (see `keras.constraints`).
#
# Input shape:
#   3+D tensor with shape: `batch_shape + (steps, input_dim)`
#
# Output shape:
#   3+D tensor with shape: `batch_shape + (new_steps, filters)`
#     `steps` value might have changed due to padding or strides.
#
# Returns:
#   A tensor of rank 3 representing
#   `activation(conv1d(inputs, kernel) + bias)`.
#
# Raises:
#   ValueError: when both `strides > 1` and `dilation_rate > 1`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u></summary>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u></summary>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.dropout.Dropout</u></summary>
# <blockquote>
# <code>
# Applies Dropout to the input.
#
# The Dropout layer randomly sets input units to 0 with a frequency of `rate`
# at each step during training time, which helps prevent overfitting.
# Inputs not set to 0 are scaled up by 1/(1 - rate) such that the sum over
# all inputs is unchanged.
#
# Note that the Dropout layer only applies when `training` is set to True
# such that no values are dropped during inference. When using `model.fit`,
# `training` will be appropriately set to True automatically, and in other
# contexts, you can set the kwarg explicitly to True when calling the layer.
#
# (This is in contrast to setting `trainable=False` for a Dropout layer.
# `trainable` does not affect the layer's behavior, as Dropout does
# not have any variables/weights that can be frozen during training.)
#
# >>> tf.random.set_seed(0)
# >>> layer = tf.keras.layers.Dropout(.2, input_shape=(2,))
# >>> data = np.arange(10).reshape(5, 2).astype(np.float32)
# >>> print(data)
# [[0. 1.]
#  [2. 3.]
#  [4. 5.]
#  [6. 7.]
#  [8. 9.]]
# >>> outputs = layer(data, training=True)
# >>> print(outputs)
# tf.Tensor(
# [[ 0.    1.25]
#  [ 2.5   3.75]
#  [ 5.    6.25]
#  [ 7.5   8.75]
#  [10.    0.  ]], shape=(5, 2), dtype=float32)
#
# Args:
#   rate: Float between 0 and 1. Fraction of the input units to drop.
#   noise_shape: 1D integer tensor representing the shape of the
#     binary dropout mask that will be multiplied with the input.
#     For instance, if your inputs have shape
#     `(batch_size, timesteps, features)` and
#     you want the dropout mask to be the same for all timesteps,
#     you can use `noise_shape=(batch_size, 1, features)`.
#   seed: A Python integer to use as random seed.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding dropout) or in inference mode (doing nothing).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.merge.Add</u></summary>
# <blockquote>
# <code>
# Layer that adds a list of inputs.
#
# It takes as input a list of tensors,
# all of the same shape, and returns
# a single tensor (also of the same shape).
#
# Examples:
#
# >>> input_shape = (2, 3, 4)
# >>> x1 = tf.random.normal(input_shape)
# >>> x2 = tf.random.normal(input_shape)
# >>> y = tf.keras.layers.Add()([x1, x2])
# >>> print(y.shape)
# (2, 3, 4)
#
# Used in a functional model:
#
# >>> input1 = tf.keras.layers.Input(shape=(16,))
# >>> x1 = tf.keras.layers.Dense(8, activation='relu')(input1)
# >>> input2 = tf.keras.layers.Input(shape=(32,))
# >>> x2 = tf.keras.layers.Dense(8, activation='relu')(input2)
# >>> # equivalent to `added = tf.keras.layers.add([x1, x2])`
# >>> added = tf.keras.layers.Add()([x1, x2])
# >>> out = tf.keras.layers.Dense(4)(added)
# >>> model = tf.keras.models.Model(inputs=[input1, input2], outputs=out)
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.merge.Concatenate</u></summary>
# <blockquote>
# <code>
# Layer that concatenates a list of inputs.
#
# It takes as input a list of tensors, all of the same shape except
# for the concatenation axis, and returns a single tensor that is the
# concatenation of all inputs.
#
# >>> x = np.arange(20).reshape(2, 2, 5)
# >>> print(x)
# [[[ 0  1  2  3  4]
#   [ 5  6  7  8  9]]
#  [[10 11 12 13 14]
#   [15 16 17 18 19]]]
# >>> y = np.arange(20, 30).reshape(2, 1, 5)
# >>> print(y)
# [[[20 21 22 23 24]]
#  [[25 26 27 28 29]]]
# >>> tf.keras.layers.Concatenate(axis=1)([x, y])
# <tf.Tensor: shape=(2, 3, 5), dtype=int64, numpy=
# array([[[ 0,  1,  2,  3,  4],
#         [ 5,  6,  7,  8,  9],
#         [20, 21, 22, 23, 24]],
#        [[10, 11, 12, 13, 14],
#         [15, 16, 17, 18, 19],
#         [25, 26, 27, 28, 29]]])>
#
# >>> x1 = tf.keras.layers.Dense(8)(np.arange(10).reshape(5, 2))
# >>> x2 = tf.keras.layers.Dense(8)(np.arange(10, 20).reshape(5, 2))
# >>> concatted = tf.keras.layers.Concatenate()([x1, x2])
# >>> concatted.shape
# TensorShape([5, 16])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.AlphaDropout</u></summary>
# <blockquote>
# <code>
# Applies Alpha Dropout to the input.
#
# Alpha Dropout is a `Dropout` that keeps mean and variance of inputs
# to their original values, in order to ensure the self-normalizing property
# even after this dropout.
# Alpha Dropout fits well to Scaled Exponential Linear Units
# by randomly setting activations to the negative saturation value.
#
# Args:
#   rate: float, drop probability (as with `Dropout`).
#     The multiplicative noise will have
#     standard deviation `sqrt(rate / (1 - rate))`.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding dropout) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianDropout</u></summary>
# <blockquote>
# <code>
# Apply multiplicative 1-centered Gaussian noise.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   rate: Float, drop probability (as with `Dropout`).
#     The multiplicative noise will have
#     standard deviation `sqrt(rate / (1 - rate))`.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding dropout) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u></summary>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u></summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.pooling.GlobalMaxPooling1D</u></summary>
# <blockquote>
# <code>
# Global max pooling operation for 1D temporal data.
#
# Downsamples the input representation by taking the maximum value over
# the time dimension.
#
# For example:
#
# >>> x = tf.constant([[1., 2., 3.], [4., 5., 6.], [7., 8., 9.]])
# >>> x = tf.reshape(x, [3, 3, 1])
# >>> x
# <tf.Tensor: shape=(3, 3, 1), dtype=float32, numpy=
# array([[[1.], [2.], [3.]],
#        [[4.], [5.], [6.]],
#        [[7.], [8.], [9.]]], dtype=float32)>
# >>> max_pool_1d = tf.keras.layers.GlobalMaxPooling1D()
# >>> max_pool_1d(x)
# <tf.Tensor: shape=(3, 1), dtype=float32, numpy=
# array([[3.],
#        [6.],
#        [9.], dtype=float32)>
#
# Args:
#   data_format: A string,
#     one of `channels_last` (default) or `channels_first`.
#     The ordering of the dimensions in the inputs.
#     `channels_last` corresponds to inputs with shape
#     `(batch, steps, features)` while `channels_first`
#     corresponds to inputs with shape
#     `(batch, features, steps)`.
#   keepdims: A boolean, whether to keep the temporal dimension or not.
#     If `keepdims` is `False` (default), the rank of the tensor is reduced
#     for spatial dimensions.
#     If `keepdims` is `True`, the temporal dimension are retained with
#     length 1.
#     The behavior is the same as for `tf.reduce_max` or `np.max`.
#
# Input shape:
#   - If `data_format='channels_last'`:
#     3D tensor with shape:
#     `(batch_size, steps, features)`
#   - If `data_format='channels_first'`:
#     3D tensor with shape:
#     `(batch_size, features, steps)`
#
# Output shape:
#   - If `keepdims`=False:
#     2D tensor with shape `(batch_size, features)`.
#   - If `keepdims`=True:
#     - If `data_format='channels_last'`:
#       3D tensor with shape `(batch_size, 1, features)`
#     - If `data_format='channels_first'`:
#       3D tensor with shape `(batch_size, features, 1)`
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.optimizer_v2.nadam.Nadam</u></summary>
# <blockquote>
# <code>
# Optimizer that implements the NAdam algorithm.
# Much like Adam is essentially RMSprop with momentum, Nadam is Adam with
# Nesterov momentum.
#
# Args:
#   learning_rate: A Tensor or a floating point value.  The learning rate.
#   beta_1: A float value or a constant float tensor. The exponential decay
#     rate for the 1st moment estimates.
#   beta_2: A float value or a constant float tensor. The exponential decay
#     rate for the exponentially weighted infinity norm.
#   epsilon: A small constant for numerical stability.
#   name: Optional name for the operations created when applying gradients.
#     Defaults to `"Nadam"`.
#   **kwargs: Keyword arguments. Allowed to be one of
#     `"clipnorm"` or `"clipvalue"`.
#     `"clipnorm"` (float) clips gradients by norm; `"clipvalue"` (float) clips
#     gradients by value.
#
# Usage Example:
#   >>> opt = tf.keras.optimizers.Nadam(learning_rate=0.2)
#   >>> var1 = tf.Variable(10.0)
#   >>> loss = lambda: (var1 ** 2) / 2.0
#   >>> step_count = opt.minimize(loss, [var1]).numpy()
#   >>> "{:.1f}".format(var1.numpy())
#   9.8
#
# Reference:
#   - [Dozat, 2015](http://cs229.stanford.edu/proj2015/054_report.pdf).
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>matplotlib</b>
# <ul>
# <li>
# <details><summary><u>matplotlib.pyplot</u></summary>
# <blockquote>
# <code>
# `matplotlib.pyplot` is a state-based interface to matplotlib. It provides
# an implicit,  MATLAB-like, way of plotting.  It also opens figures on your
# screen, and acts as the figure GUI manager.
#
# pyplot is mainly intended for interactive plots and simple cases of
# programmatic plot generation::
#
#     import numpy as np
#     import matplotlib.pyplot as plt
#
#     x = np.arange(0, 5, 0.1)
#     y = np.sin(x)
#     plt.plot(x, y)
#
# The explicit (object-oriented) API is recommended for complex plots, though
# pyplot is still usually used to create the figure and often the axes in the
# figure. See `.pyplot.figure`, `.pyplot.subplots`, and
# `.pyplot.subplot_mosaic` to create figures, and
# :doc:`Axes API <../axes_api>` for the plotting methods on an axes::
#
#     import numpy as np
#     import matplotlib.pyplot as plt
#
#     x = np.arange(0, 5, 0.1)
#     y = np.sin(x)
#     fig, ax = plt.subplots()
#     ax.plot(x, y)
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>matplotlib.pyplot.figure</u></summary>
# <blockquote>
# <code>
# Create a new figure, or activate an existing figure.
#
# Parameters
# ----------
# num : int or str or `.Figure`, optional
#     A unique identifier for the figure.
#
#     If a figure with that identifier already exists, this figure is made
#     active and returned. An integer refers to the ``Figure.number``
#     attribute, a string refers to the figure label.
#
#     If there is no figure with the identifier or *num* is not given, a new
#     figure is created, made active and returned.  If *num* is an int, it
#     will be used for the ``Figure.number`` attribute, otherwise, an
#     auto-generated integer value is used (starting at 1 and incremented
#     for each new figure). If *num* is a string, the figure label and the
#     window title is set to this value.
#
# figsize : (float, float), default: :rc:`figure.figsize`
#     Width, height in inches.
#
# dpi : float, default: :rc:`figure.dpi`
#     The resolution of the figure in dots-per-inch.
#
# facecolor : color, default: :rc:`figure.facecolor`
#     The background color.
#
# edgecolor : color, default: :rc:`figure.edgecolor`
#     The border color.
#
# frameon : bool, default: True
#     If False, suppress drawing the figure frame.
#
# FigureClass : subclass of `~matplotlib.figure.Figure`
#     Optionally use a custom `.Figure` instance.
#
# clear : bool, default: False
#     If True and the figure already exists, then it is cleared.
#
# tight_layout : bool or dict, default: :rc:`figure.autolayout`
#     If ``False`` use *subplotpars*. If ``True`` adjust subplot
#     parameters using `.tight_layout` with default padding.
#     When providing a dict containing the keys ``pad``, ``w_pad``,
#     ``h_pad``, and ``rect``, the default `.tight_layout` paddings
#     will be overridden.
#
# constrained_layout : bool, default: :rc:`figure.constrained_layout.use`
#     If ``True`` use constrained layout to adjust positioning of plot
#     elements.  Like ``tight_layout``, but designed to be more
#     flexible.  See
#     :doc:`/tutorials/intermediate/constrainedlayout_guide`
#     for examples.  (Note: does not work with `add_subplot` or
#     `~.pyplot.subplot2grid`.)
#
#
# **kwargs : optional
#     See `~.matplotlib.figure.Figure` for other possible arguments.
#
# Returns
# -------
# `~matplotlib.figure.Figure`
#     The `.Figure` instance returned will also be passed to
#     new_figure_manager in the backends, which allows to hook custom
#     `.Figure` classes into the pyplot interface. Additional kwargs will be
#     passed to the `.Figure` init function.
#
# Notes
# -----
# If you are creating many figures, make sure you explicitly call
# `.pyplot.close` on the figures you are not using, because this will
# enable pyplot to properly clean up the memory.
#
# `~matplotlib.rcParams` defines the default values, which can be modified
# in the matplotlibrc file.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>matplotlib.pyplot.scatter</u></summary>
# <blockquote>
# <code>
# A scatter plot of *y* vs. *x* with varying marker size and/or color.
#
# Parameters
# ----------
# x, y : float or array-like, shape (n, )
#     The data positions.
#
# s : float or array-like, shape (n, ), optional
#     The marker size in points**2.
#     Default is ``rcParams['lines.markersize'] ** 2``.
#
# c : array-like or list of colors or color, optional
#     The marker colors. Possible values:
#
#     - A scalar or sequence of n numbers to be mapped to colors using
#       *cmap* and *norm*.
#     - A 2D array in which the rows are RGB or RGBA.
#     - A sequence of colors of length n.
#     - A single color format string.
#
#     Note that *c* should not be a single numeric RGB or RGBA sequence
#     because that is indistinguishable from an array of values to be
#     colormapped. If you want to specify the same RGB or RGBA value for
#     all points, use a 2D array with a single row.  Otherwise, value-
#     matching will have precedence in case of a size matching with *x*
#     and *y*.
#
#     If you wish to specify a single color for all points
#     prefer the *color* keyword argument.
#
#     Defaults to `None`. In that case the marker color is determined
#     by the value of *color*, *facecolor* or *facecolors*. In case
#     those are not specified or `None`, the marker color is determined
#     by the next color of the ``Axes``' current "shape and fill" color
#     cycle. This cycle defaults to :rc:`axes.prop_cycle`.
#
# marker : `~.markers.MarkerStyle`, default: :rc:`scatter.marker`
#     The marker style. *marker* can be either an instance of the class
#     or the text shorthand for a particular marker.
#     See :mod:`matplotlib.markers` for more information about marker
#     styles.
#
# cmap : str or `~matplotlib.colors.Colormap`, default: :rc:`image.cmap`
#     A `.Colormap` instance or registered colormap name. *cmap* is only
#     used if *c* is an array of floats.
#
# norm : `~matplotlib.colors.Normalize`, default: None
#     If *c* is an array of floats, *norm* is used to scale the color
#     data, *c*, in the range 0 to 1, in order to map into the colormap
#     *cmap*.
#     If *None*, use the default `.colors.Normalize`.
#
# vmin, vmax : float, default: None
#     *vmin* and *vmax* are used in conjunction with the default norm to
#     map the color array *c* to the colormap *cmap*. If None, the
#     respective min and max of the color array is used.
#     It is an error to use *vmin*/*vmax* when *norm* is given.
#
# alpha : float, default: None
#     The alpha blending value, between 0 (transparent) and 1 (opaque).
#
# linewidths : float or array-like, default: :rc:`lines.linewidth`
#     The linewidth of the marker edges. Note: The default *edgecolors*
#     is 'face'. You may want to change this as well.
#
# edgecolors : {'face', 'none', *None*} or color or sequence of color, default: :rc:`scatter.edgecolors`
#     The edge color of the marker. Possible values:
#
#     - 'face': The edge color will always be the same as the face color.
#     - 'none': No patch boundary will be drawn.
#     - A color or sequence of colors.
#
#     For non-filled markers, *edgecolors* is ignored. Instead, the color
#     is determined like with 'face', i.e. from *c*, *colors*, or
#     *facecolors*.
#
# plotnonfinite : bool, default: False
#     Whether to plot points with nonfinite *c* (i.e. ``inf``, ``-inf``
#     or ``nan``). If ``True`` the points are drawn with the *bad*
#     colormap color (see `.Colormap.set_bad`).
#
# Returns
# -------
# `~matplotlib.collections.PathCollection`
#
# Other Parameters
# ----------------
# data : indexable object, optional
#     If given, the following parameters also accept a string ``s``, which is
#     interpreted as ``data[s]`` (unless this raises an exception):
#
#     *x*, *y*, *s*, *linewidths*, *edgecolors*, *c*, *facecolor*, *facecolors*, *color*
# **kwargs : `~matplotlib.collections.Collection` properties
#
# See Also
# --------
# plot : To plot scatter plots when markers are identical in size and
#     color.
#
# Notes
# -----
# * The `.plot` function will be faster for scatterplots where markers
#   don't vary in size or color.
#
# * Any or all of *x*, *y*, *s*, and *c* may be masked arrays, in which
#   case all masks will be combined and only unmasked points will be
#   plotted.
#
# * Fundamentally, scatter works with 1D arrays; *x*, *y*, *s*, and *c*
#   may be input as N-D arrays, but within scatter they will be
#   flattened. The exception is *c*, which will be flattened only if its
#   size matches the size of *x* and *y*.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>numpy</b>
# <ul>
# <li>
# <details><summary><u>numpy</u></summary>
# <blockquote>
# <code>
# NumPy
# =====
#
# Provides
#   1. An array object of arbitrary homogeneous items
#   2. Fast mathematical operations over arrays
#   3. Linear Algebra, Fourier Transforms, Random Number Generation
#
# How to use the documentation
# ----------------------------
# Documentation is available in two forms: docstrings provided
# with the code, and a loose standing reference guide, available from
# `the NumPy homepage <https://www.scipy.org>`_.
#
# We recommend exploring the docstrings using
# `IPython <https://ipython.org>`_, an advanced Python shell with
# TAB-completion and introspection capabilities.  See below for further
# instructions.
#
# The docstring examples assume that `numpy` has been imported as `np`::
#
#   >>> import numpy as np
#
# Code snippets are indicated by three greater-than signs::
#
#   >>> x = 42
#   >>> x = x + 1
#
# Use the built-in ``help`` function to view a function's docstring::
#
#   >>> help(np.sort)
#   ... # doctest: +SKIP
#
# For some objects, ``np.info(obj)`` may provide additional help.  This is
# particularly true if you see the line "Help on ufunc object:" at the top
# of the help() page.  Ufuncs are implemented in C, not Python, for speed.
# The native Python help() does not know how to view their help, but our
# np.info() function does.
#
# To search for documents containing a keyword, do::
#
#   >>> np.lookfor('keyword')
#   ... # doctest: +SKIP
#
# General-purpose documents like a glossary and help on the basic concepts
# of numpy are available under the ``doc`` sub-module::
#
#   >>> from numpy import doc
#   >>> help(doc)
#   ... # doctest: +SKIP
#
# Available subpackages
# ---------------------
# doc
#     Topical documentation on broadcasting, indexing, etc.
# lib
#     Basic functions used by several sub-packages.
# random
#     Core Random Tools
# linalg
#     Core Linear Algebra Tools
# fft
#     Core FFT routines
# polynomial
#     Polynomial tools
# testing
#     NumPy testing tools
# f2py
#     Fortran to Python Interface Generator.
# distutils
#     Enhancements to distutils with support for
#     Fortran compilers support and more.
#
# Utilities
# ---------
# test
#     Run numpy unittests
# show_config
#     Show numpy build configuration
# dual
#     Overwrite certain functions with high-performance SciPy tools.
#     Note: `numpy.dual` is deprecated.  Use the functions from NumPy or Scipy
#     directly instead of importing them from `numpy.dual`.
# matlib
#     Make everything matrices.
# __version__
#     NumPy version string
#
# Viewing documentation using IPython
# -----------------------------------
# Start IPython with the NumPy profile (``ipython -p numpy``), which will
# import `numpy` under the alias `np`.  Then, use the ``cpaste`` command to
# paste examples into the shell.  To see which functions are available in
# `numpy`, type ``np.<TAB>`` (where ``<TAB>`` refers to the TAB key), or use
# ``np.*cos*?<ENTER>`` (where ``<ENTER>`` refers to the ENTER key) to narrow
# down the list.  To view the docstring for a function, use
# ``np.cos?<ENTER>`` (to view the docstring) and ``np.cos??<ENTER>`` (to view
# the source code).
#
# Copies vs. in-place operation
# -----------------------------
# Most of the functions in `numpy` return a copy of the array argument
# (e.g., `np.sort`).  In-place versions of these functions are often
# available as array methods, i.e. ``x = np.array([1,2,3]); x.sort()``.
# Exceptions to this rule are documented.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.arange</u></summary>
# <blockquote>
# <code>
# arange([start,] stop[, step,], dtype=None, *, like=None)
#
# Return evenly spaced values within a given interval.
#
# Values are generated within the half-open interval ``[start, stop)``
# (in other words, the interval including `start` but excluding `stop`).
# For integer arguments the function is equivalent to the Python built-in
# `range` function, but returns an ndarray rather than a list.
#
# When using a non-integer step, such as 0.1, it is often better to use
# `numpy.linspace`. See the warnings section below for more information.
#
# Parameters
# ----------
# start : integer or real, optional
#     Start of interval.  The interval includes this value.  The default
#     start value is 0.
# stop : integer or real
#     End of interval.  The interval does not include this value, except
#     in some cases where `step` is not an integer and floating point
#     round-off affects the length of `out`.
# step : integer or real, optional
#     Spacing between values.  For any output `out`, this is the distance
#     between two adjacent values, ``out[i+1] - out[i]``.  The default
#     step size is 1.  If `step` is specified as a position argument,
#     `start` must also be given.
# dtype : dtype
#     The type of the output array.  If `dtype` is not given, infer the data
#     type from the other input arguments.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# arange : ndarray
#     Array of evenly spaced values.
#
#     For floating point arguments, the length of the result is
#     ``ceil((stop - start)/step)``.  Because of floating point overflow,
#     this rule may result in the last element of `out` being greater
#     than `stop`.
#
# Warnings
# --------
# The length of the output might not be numerically stable.
#
# Another stability issue is due to the internal implementation of
# `numpy.arange`.
# The actual step value used to populate the array is
# ``dtype(start + step) - dtype(start)`` and not `step`. Precision loss
# can occur here, due to casting or due to using floating points when
# `start` is much larger than `step`. This can lead to unexpected
# behaviour. For example::
#
#   >>> np.arange(0, 5, 0.5, dtype=int)
#   array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
#   >>> np.arange(-3, 3, 0.5, dtype=int)
#   array([-3, -2, -1,  0,  1,  2,  3,  4,  5,  6,  7,  8])
#
# In such cases, the use of `numpy.linspace` should be preferred.
#
# See Also
# --------
# numpy.linspace : Evenly spaced numbers with careful handling of endpoints.
# numpy.ogrid: Arrays of evenly spaced numbers in N-dimensions.
# numpy.mgrid: Grid-shaped arrays of evenly spaced numbers in N-dimensions.
#
# Examples
# --------
# >>> np.arange(3)
# array([0, 1, 2])
# >>> np.arange(3.0)
# array([ 0.,  1.,  2.])
# >>> np.arange(3,7)
# array([3, 4, 5, 6])
# >>> np.arange(3,7,2)
# array([3, 5])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.array</u></summary>
# <blockquote>
# <code>
# array(object, dtype=None, *, copy=True, order='K', subok=False, ndmin=0,
#       like=None)
#
# Create an array.
#
# Parameters
# ----------
# object : array_like
#     An array, any object exposing the array interface, an object whose
#     __array__ method returns an array, or any (nested) sequence.
#     If object is a scalar, a 0-dimensional array containing object is
#     returned.
# dtype : data-type, optional
#     The desired data-type for the array.  If not given, then the type will
#     be determined as the minimum type required to hold the objects in the
#     sequence.
# copy : bool, optional
#     If true (default), then the object is copied.  Otherwise, a copy will
#     only be made if __array__ returns a copy, if obj is a nested sequence,
#     or if a copy is needed to satisfy any of the other requirements
#     (`dtype`, `order`, etc.).
# order : {'K', 'A', 'C', 'F'}, optional
#     Specify the memory layout of the array. If object is not an array, the
#     newly created array will be in C order (row major) unless 'F' is
#     specified, in which case it will be in Fortran order (column major).
#     If object is an array the following holds.
#
#     ===== ========= ===================================================
#     order  no copy                     copy=True
#     ===== ========= ===================================================
#     'K'   unchanged F & C order preserved, otherwise most similar order
#     'A'   unchanged F order if input is F and not C, otherwise C order
#     'C'   C order   C order
#     'F'   F order   F order
#     ===== ========= ===================================================
#
#     When ``copy=False`` and a copy is made for other reasons, the result is
#     the same as if ``copy=True``, with some exceptions for 'A', see the
#     Notes section. The default order is 'K'.
# subok : bool, optional
#     If True, then sub-classes will be passed-through, otherwise
#     the returned array will be forced to be a base-class array (default).
# ndmin : int, optional
#     Specifies the minimum number of dimensions that the resulting
#     array should have.  Ones will be pre-pended to the shape as
#     needed to meet this requirement.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     An array object satisfying the specified requirements.
#
# See Also
# --------
# empty_like : Return an empty array with shape and type of input.
# ones_like : Return an array of ones with shape and type of input.
# zeros_like : Return an array of zeros with shape and type of input.
# full_like : Return a new array with shape of input filled with value.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# zeros : Return a new array setting values to zero.
# full : Return a new array of given shape filled with value.
#
#
# Notes
# -----
# When order is 'A' and `object` is an array in neither 'C' nor 'F' order,
# and a copy is forced by a change in dtype, then the order of the result is
# not necessarily 'C' as expected. This is likely a bug.
#
# Examples
# --------
# >>> np.array([1, 2, 3])
# array([1, 2, 3])
#
# Upcasting:
#
# >>> np.array([1, 2, 3.0])
# array([ 1.,  2.,  3.])
#
# More than one dimension:
#
# >>> np.array([[1, 2], [3, 4]])
# array([[1, 2],
#        [3, 4]])
#
# Minimum dimensions 2:
#
# >>> np.array([1, 2, 3], ndmin=2)
# array([[1, 2, 3]])
#
# Type provided:
#
# >>> np.array([1, 2, 3], dtype=complex)
# array([ 1.+0.j,  2.+0.j,  3.+0.j])
#
# Data-type consisting of more than one element:
#
# >>> x = np.array([(1,2),(3,4)],dtype=[('a','<i4'),('b','<i4')])
# >>> x['a']
# array([1, 3])
#
# Creating an array from sub-classes:
#
# >>> np.array(np.mat('1 2; 3 4'))
# array([[1, 2],
#        [3, 4]])
#
# >>> np.array(np.mat('1 2; 3 4'), subok=True)
# matrix([[1, 2],
#         [3, 4]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.core.fromnumeric.mean</u></summary>
# <blockquote>
# <code>
# Compute the arithmetic mean along the specified axis.
#
# Returns the average of the array elements.  The average is taken over
# the flattened array by default, otherwise over the specified axis.
# `float64` intermediate and return values are used for integer inputs.
#
# Parameters
# ----------
# a : array_like
#     Array containing numbers whose mean is desired. If `a` is not an
#     array, a conversion is attempted.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the means are computed. The default is to
#     compute the mean of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a mean is performed over multiple axes,
#     instead of a single axis or all the axes as before.
# dtype : data-type, optional
#     Type to use in computing the mean.  For integer inputs, the default
#     is `float64`; for floating point inputs, it is the same as the
#     input dtype.
# out : ndarray, optional
#     Alternate output array in which to place the result.  The default
#     is ``None``; if provided, it must have the same shape as the
#     expected output, but the type will be cast if necessary.
#     See :ref:`ufuncs-output-type` for more details.
#
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `mean` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the mean. See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# m : ndarray, see dtype parameter above
#     If `out=None`, returns a new array containing the mean values,
#     otherwise a reference to the output array is returned.
#
# See Also
# --------
# average : Weighted average
# std, var, nanmean, nanstd, nanvar
#
# Notes
# -----
# The arithmetic mean is the sum of the elements along the axis divided
# by the number of elements.
#
# Note that for floating-point input, the mean is computed using the
# same precision the input has.  Depending on the input data, this can
# cause the results to be inaccurate, especially for `float32` (see
# example below).  Specifying a higher-precision accumulator using the
# `dtype` keyword can alleviate this issue.
#
# By default, `float16` results are computed using `float32` intermediates
# for extra precision.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.mean(a)
# 2.5
# >>> np.mean(a, axis=0)
# array([2., 3.])
# >>> np.mean(a, axis=1)
# array([1.5, 3.5])
#
# In single precision, `mean` can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.mean(a)
# 0.54999924
#
# Computing the mean in float64 is more accurate:
#
# >>> np.mean(a, dtype=np.float64)
# 0.55000000074505806 # may vary
#
# Specifying a where argument:
# >>> a = np.array([[5, 9, 13], [14, 10, 12], [11, 15, 19]])
# >>> np.mean(a)
# 12.0
# >>> np.mean(a, where=[[True], [False], [False]])
# 9.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.core.fromnumeric.std</u></summary>
# <blockquote>
# <code>
# Compute the standard deviation along the specified axis.
#
# Returns the standard deviation, a measure of the spread of a distribution,
# of the array elements. The standard deviation is computed for the
# flattened array by default, otherwise over the specified axis.
#
# Parameters
# ----------
# a : array_like
#     Calculate the standard deviation of these values.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the standard deviation is computed. The
#     default is to compute the standard deviation of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a standard deviation is performed over
#     multiple axes, instead of a single axis or all the axes as before.
# dtype : dtype, optional
#     Type to use in computing the standard deviation. For arrays of
#     integer type the default is float64, for arrays of float types it is
#     the same as the array type.
# out : ndarray, optional
#     Alternative output array in which to place the result. It must have
#     the same shape as the expected output but the type (of the calculated
#     values) will be cast if necessary.
# ddof : int, optional
#     Means Delta Degrees of Freedom.  The divisor used in calculations
#     is ``N - ddof``, where ``N`` represents the number of elements.
#     By default `ddof` is zero.
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `std` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the standard deviation.
#     See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# standard_deviation : ndarray, see dtype parameter above.
#     If `out` is None, return a new array containing the standard deviation,
#     otherwise return a reference to the output array.
#
# See Also
# --------
# var, mean, nanmean, nanstd, nanvar
# :ref:`ufuncs-output-type`
#
# Notes
# -----
# The standard deviation is the square root of the average of the squared
# deviations from the mean, i.e., ``std = sqrt(mean(x))``, where
# ``x = abs(a - a.mean())**2``.
#
# The average squared deviation is typically calculated as ``x.sum() / N``,
# where ``N = len(x)``. If, however, `ddof` is specified, the divisor
# ``N - ddof`` is used instead. In standard statistical practice, ``ddof=1``
# provides an unbiased estimator of the variance of the infinite population.
# ``ddof=0`` provides a maximum likelihood estimate of the variance for
# normally distributed variables. The standard deviation computed in this
# function is the square root of the estimated variance, so even with
# ``ddof=1``, it will not be an unbiased estimate of the standard deviation
# per se.
#
# Note that, for complex numbers, `std` takes the absolute
# value before squaring, so that the result is always real and nonnegative.
#
# For floating-point input, the *std* is computed using the same
# precision the input has. Depending on the input data, this can cause
# the results to be inaccurate, especially for float32 (see example below).
# Specifying a higher-accuracy accumulator using the `dtype` keyword can
# alleviate this issue.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.std(a)
# 1.1180339887498949 # may vary
# >>> np.std(a, axis=0)
# array([1.,  1.])
# >>> np.std(a, axis=1)
# array([0.5,  0.5])
#
# In single precision, std() can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.std(a)
# 0.45000005
#
# Computing the standard deviation in float64 is more accurate:
#
# >>> np.std(a, dtype=np.float64)
# 0.44999999925494177 # may vary
#
# Specifying a where argument:
#
# >>> a = np.array([[14, 8, 11, 10], [7, 9, 10, 11], [10, 15, 5, 10]])
# >>> np.std(a)
# 2.614064523559687 # may vary
# >>> np.std(a, where=[[True], [True], [False]])
# 2.0
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.lib.npyio.savez</u></summary>
# <blockquote>
# <code>
# Save several arrays into a single file in uncompressed ``.npz`` format.
#
# Provide arrays as keyword arguments to store them under the
# corresponding name in the output file: ``savez(fn, x=x, y=y)``.
#
# If arrays are specified as positional arguments, i.e., ``savez(fn,
# x, y)``, their names will be `arr_0`, `arr_1`, etc.
#
# Parameters
# ----------
# file : str or file
#     Either the filename (string) or an open file (file-like object)
#     where the data will be saved. If file is a string or a Path, the
#     ``.npz`` extension will be appended to the filename if it is not
#     already there.
# args : Arguments, optional
#     Arrays to save to the file. Please use keyword arguments (see
#     `kwds` below) to assign names to arrays.  Arrays specified as
#     args will be named "arr_0", "arr_1", and so on.
# kwds : Keyword arguments, optional
#     Arrays to save to the file. Each array will be saved to the
#     output file with its corresponding keyword name.
#
# Returns
# -------
# None
#
# See Also
# --------
# save : Save a single array to a binary file in NumPy format.
# savetxt : Save an array to a file as plain text.
# savez_compressed : Save several arrays into a compressed ``.npz`` archive
#
# Notes
# -----
# The ``.npz`` file format is a zipped archive of files named after the
# variables they contain.  The archive is not compressed and each file
# in the archive contains one variable in ``.npy`` format. For a
# description of the ``.npy`` format, see :py:mod:`numpy.lib.format`.
#
# When opening the saved ``.npz`` file with `load` a `NpzFile` object is
# returned. This is a dictionary-like object which can be queried for
# its list of arrays (with the ``.files`` attribute), and for the arrays
# themselves.
#
# Keys passed in `kwds` are used as filenames inside the ZIP archive.
# Therefore, keys should be valid filenames; e.g., avoid keys that begin with
# ``/`` or contain ``.``.
#
# When naming variables with keyword arguments, it is not possible to name a
# variable ``file``, as this would cause the ``file`` argument to be defined
# twice in the call to ``savez``.
#
# Examples
# --------
# >>> from tempfile import TemporaryFile
# >>> outfile = TemporaryFile()
# >>> x = np.arange(10)
# >>> y = np.sin(x)
#
# Using `savez` with \*args, the arrays are saved with default names.
#
# >>> np.savez(outfile, x, y)
# >>> _ = outfile.seek(0) # Only needed here to simulate closing & reopening file
# >>> npzfile = np.load(outfile)
# >>> npzfile.files
# ['arr_0', 'arr_1']
# >>> npzfile['arr_0']
# array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#
# Using `savez` with \**kwds, the arrays are saved with the keyword names.
#
# >>> outfile = TemporaryFile()
# >>> np.savez(outfile, x=x, y=y)
# >>> _ = outfile.seek(0)
# >>> npzfile = np.load(outfile)
# >>> sorted(npzfile.files)
# ['x', 'y']
# >>> npzfile['x']
# array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u></summary>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.ndarray</u></summary>
# <blockquote>
# <code>
# ndarray(shape, dtype=float, buffer=None, offset=0,
#         strides=None, order=None)
#
# An array object represents a multidimensional, homogeneous array
# of fixed-size items.  An associated data-type object describes the
# format of each element in the array (its byte-order, how many bytes it
# occupies in memory, whether it is an integer, a floating point number,
# or something else, etc.)
#
# Arrays should be constructed using `array`, `zeros` or `empty` (refer
# to the See Also section below).  The parameters given here refer to
# a low-level method (`ndarray(...)`) for instantiating an array.
#
# For more information, refer to the `numpy` module and examine the
# methods and attributes of an array.
#
# Parameters
# ----------
# (for the __new__ method; see Notes below)
#
# shape : tuple of ints
#     Shape of created array.
# dtype : data-type, optional
#     Any object that can be interpreted as a numpy data type.
# buffer : object exposing buffer interface, optional
#     Used to fill the array with data.
# offset : int, optional
#     Offset of array data in buffer.
# strides : tuple of ints, optional
#     Strides of data in memory.
# order : {'C', 'F'}, optional
#     Row-major (C-style) or column-major (Fortran-style) order.
#
# Attributes
# ----------
# T : ndarray
#     Transpose of the array.
# data : buffer
#     The array's elements, in memory.
# dtype : dtype object
#     Describes the format of the elements in the array.
# flags : dict
#     Dictionary containing information related to memory use, e.g.,
#     'C_CONTIGUOUS', 'OWNDATA', 'WRITEABLE', etc.
# flat : numpy.flatiter object
#     Flattened version of the array as an iterator.  The iterator
#     allows assignments, e.g., ``x.flat = 3`` (See `ndarray.flat` for
#     assignment examples; TODO).
# imag : ndarray
#     Imaginary part of the array.
# real : ndarray
#     Real part of the array.
# size : int
#     Number of elements in the array.
# itemsize : int
#     The memory use of each array element in bytes.
# nbytes : int
#     The total number of bytes required to store the array data,
#     i.e., ``itemsize * size``.
# ndim : int
#     The array's number of dimensions.
# shape : tuple of ints
#     Shape of the array.
# strides : tuple of ints
#     The step-size required to move from one element to the next in
#     memory. For example, a contiguous ``(3, 4)`` array of type
#     ``int16`` in C-order has strides ``(8, 2)``.  This implies that
#     to move from element to element in memory requires jumps of 2 bytes.
#     To move from row-to-row, one needs to jump 8 bytes at a time
#     (``2 * 4``).
# ctypes : ctypes object
#     Class containing properties of the array needed for interaction
#     with ctypes.
# base : ndarray
#     If the array is a view into another array, that array is its `base`
#     (unless that array is also a view).  The `base` array is where the
#     array data is actually stored.
#
# See Also
# --------
# array : Construct an array.
# zeros : Create an array, each element of which is zero.
# empty : Create an array, but leave its allocated memory unchanged (i.e.,
#         it contains "garbage").
# dtype : Create a data-type.
# numpy.typing.NDArray : An ndarray alias :term:`generic <generic type>`
#                        w.r.t. its `dtype.type <numpy.dtype.type>`.
#
# Notes
# -----
# There are two modes of creating an array using ``__new__``:
#
# 1. If `buffer` is None, then only `shape`, `dtype`, and `order`
#    are used.
# 2. If `buffer` is an object exposing the buffer interface, then
#    all keywords are interpreted.
#
# No ``__init__`` method is needed because the array is fully initialized
# after the ``__new__`` method.
#
# Examples
# --------
# These examples illustrate the low-level `ndarray` constructor.  Refer
# to the `See Also` section above for easier ways of constructing an
# ndarray.
#
# First mode, `buffer` is None:
#
# >>> np.ndarray(shape=(2,2), dtype=float, order='F')
# array([[0.0e+000, 0.0e+000], # random
#        [     nan, 2.5e-323]])
#
# Second mode:
#
# >>> np.ndarray((2,), buffer=np.array([1,2,3]),
# ...            offset=np.int_().itemsize,
# ...            dtype=int) # offset = 1*itemsize, i.e. skip first element
# array([2, 3])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.random</u></summary>
# <blockquote>
# <code>
# ========================
# Random Number Generation
# ========================
#
# Use ``default_rng()`` to create a `Generator` and call its methods.
#
# =============== =========================================================
# Generator
# --------------- ---------------------------------------------------------
# Generator       Class implementing all of the random number distributions
# default_rng     Default constructor for ``Generator``
# =============== =========================================================
#
# ============================================= ===
# BitGenerator Streams that work with Generator
# --------------------------------------------- ---
# MT19937
# PCG64
# PCG64DXSM
# Philox
# SFC64
# ============================================= ===
#
# ============================================= ===
# Getting entropy to initialize a BitGenerator
# --------------------------------------------- ---
# SeedSequence
# ============================================= ===
#
#
# Legacy
# ------
#
# For backwards compatibility with previous versions of numpy before 1.17, the
# various aliases to the global `RandomState` methods are left alone and do not
# use the new `Generator` API.
#
# ==================== =========================================================
# Utility functions
# -------------------- ---------------------------------------------------------
# random               Uniformly distributed floats over ``[0, 1)``
# bytes                Uniformly distributed random bytes.
# permutation          Randomly permute a sequence / generate a random sequence.
# shuffle              Randomly permute a sequence in place.
# choice               Random sample from 1-D array.
# ==================== =========================================================
#
# ==================== =========================================================
# Compatibility
# functions - removed
# in the new API
# -------------------- ---------------------------------------------------------
# rand                 Uniformly distributed values.
# randn                Normally distributed values.
# ranf                 Uniformly distributed floating point numbers.
# random_integers      Uniformly distributed integers in a given range.
#                      (deprecated, use ``integers(..., closed=True)`` instead)
# random_sample        Alias for `random_sample`
# randint              Uniformly distributed integers in a given range
# seed                 Seed the legacy random number generator.
# ==================== =========================================================
#
# ==================== =========================================================
# Univariate
# distributions
# -------------------- ---------------------------------------------------------
# beta                 Beta distribution over ``[0, 1]``.
# binomial             Binomial distribution.
# chisquare            :math:`\chi^2` distribution.
# exponential          Exponential distribution.
# f                    F (Fisher-Snedecor) distribution.
# gamma                Gamma distribution.
# geometric            Geometric distribution.
# gumbel               Gumbel distribution.
# hypergeometric       Hypergeometric distribution.
# laplace              Laplace distribution.
# logistic             Logistic distribution.
# lognormal            Log-normal distribution.
# logseries            Logarithmic series distribution.
# negative_binomial    Negative binomial distribution.
# noncentral_chisquare Non-central chi-square distribution.
# noncentral_f         Non-central F distribution.
# normal               Normal / Gaussian distribution.
# pareto               Pareto distribution.
# poisson              Poisson distribution.
# power                Power distribution.
# rayleigh             Rayleigh distribution.
# triangular           Triangular distribution.
# uniform              Uniform distribution.
# vonmises             Von Mises circular distribution.
# wald                 Wald (inverse Gaussian) distribution.
# weibull              Weibull distribution.
# zipf                 Zipf's distribution over ranked data.
# ==================== =========================================================
#
# ==================== ==========================================================
# Multivariate
# distributions
# -------------------- ----------------------------------------------------------
# dirichlet            Multivariate generalization of Beta distribution.
# multinomial          Multivariate generalization of the binomial distribution.
# multivariate_normal  Multivariate generalization of the normal distribution.
# ==================== ==========================================================
#
# ==================== =========================================================
# Standard
# distributions
# -------------------- ---------------------------------------------------------
# standard_cauchy      Standard Cauchy-Lorentz distribution.
# standard_exponential Standard exponential distribution.
# standard_gamma       Standard Gamma distribution.
# standard_normal      Standard normal distribution.
# standard_t           Standard Student's t-distribution.
# ==================== =========================================================
#
# ==================== =========================================================
# Internal functions
# -------------------- ---------------------------------------------------------
# get_state            Get tuple representing internal state of generator.
# set_state            Set state of generator.
# ==================== =========================================================
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u></summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.zeros</u></summary>
# <blockquote>
# <code>
# zeros(shape, dtype=float, order='C', *, like=None)
#
# Return a new array of given shape and type, filled with zeros.
#
# Parameters
# ----------
# shape : int or tuple of ints
#     Shape of the new array, e.g., ``(2, 3)`` or ``2``.
# dtype : data-type, optional
#     The desired data-type for the array, e.g., `numpy.int8`.  Default is
#     `numpy.float64`.
# order : {'C', 'F'}, optional, default: 'C'
#     Whether to store multi-dimensional data in row-major
#     (C-style) or column-major (Fortran-style) order in
#     memory.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     Array of zeros with the given shape, dtype, and order.
#
# See Also
# --------
# zeros_like : Return an array of zeros with shape and type of input.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# full : Return a new array of given shape filled with value.
#
# Examples
# --------
# >>> np.zeros(5)
# array([ 0.,  0.,  0.,  0.,  0.])
#
# >>> np.zeros((5,), dtype=int)
# array([0, 0, 0, 0, 0])
#
# >>> np.zeros((2, 1))
# array([[ 0.],
#        [ 0.]])
#
# >>> s = (2,2)
# >>> np.zeros(s)
# array([[ 0.,  0.],
#        [ 0.,  0.]])
#
# >>> np.zeros((2,), dtype=[('x', 'i4'), ('y', 'i4')]) # custom dtype
# array([(0, 0), (0, 0)],
#       dtype=[('x', '<i4'), ('y', '<i4')])
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>pandas</b>
# <ul>
# <li>
# <details><summary><u>pandas</u></summary>
# <blockquote>
# <code>
# pandas - a powerful data analysis and manipulation library for Python
# =====================================================================
#
# **pandas** is a Python package providing fast, flexible, and expressive data
# structures designed to make working with "relational" or "labeled" data both
# easy and intuitive. It aims to be the fundamental high-level building block for
# doing practical, **real world** data analysis in Python. Additionally, it has
# the broader goal of becoming **the most powerful and flexible open source data
# analysis / manipulation tool available in any language**. It is already well on
# its way toward this goal.
#
# Main Features
# -------------
# Here are just a few of the things that pandas does well:
#
#   - Easy handling of missing data in floating point as well as non-floating
#     point data.
#   - Size mutability: columns can be inserted and deleted from DataFrame and
#     higher dimensional objects
#   - Automatic and explicit data alignment: objects can be explicitly aligned
#     to a set of labels, or the user can simply ignore the labels and let
#     `Series`, `DataFrame`, etc. automatically align the data for you in
#     computations.
#   - Powerful, flexible group by functionality to perform split-apply-combine
#     operations on data sets, for both aggregating and transforming data.
#   - Make it easy to convert ragged, differently-indexed data in other Python
#     and NumPy data structures into DataFrame objects.
#   - Intelligent label-based slicing, fancy indexing, and subsetting of large
#     data sets.
#   - Intuitive merging and joining data sets.
#   - Flexible reshaping and pivoting of data sets.
#   - Hierarchical labeling of axes (possible to have multiple labels per tick).
#   - Robust IO tools for loading data from flat files (CSV and delimited),
#     Excel files, databases, and saving/loading data from the ultrafast HDF5
#     format.
#   - Time series-specific functionality: date range generation and frequency
#     conversion, moving window statistics, date shifting and lagging.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>pandas.core.frame.DataFrame</u></summary>
# <blockquote>
# <code>
# Two-dimensional, size-mutable, potentially heterogeneous tabular data.
#
# Data structure also contains labeled axes (rows and columns).
# Arithmetic operations align on both row and column labels. Can be
# thought of as a dict-like container for Series objects. The primary
# pandas data structure.
#
# Parameters
# ----------
# data : ndarray (structured or homogeneous), Iterable, dict, or DataFrame
#     Dict can contain Series, arrays, constants, dataclass or list-like objects. If
#     data is a dict, column order follows insertion-order. If a dict contains Series
#     which have an index defined, it is aligned by its index.
#
#     .. versionchanged:: 0.25.0
#        If data is a list of dicts, column order follows insertion-order.
#
# index : Index or array-like
#     Index to use for resulting frame. Will default to RangeIndex if
#     no indexing information part of input data and no index provided.
# columns : Index or array-like
#     Column labels to use for resulting frame when data does not have them,
#     defaulting to RangeIndex(0, 1, 2, ..., n). If data contains column labels,
#     will perform column selection instead.
# dtype : dtype, default None
#     Data type to force. Only a single dtype is allowed. If None, infer.
# copy : bool or None, default None
#     Copy data from inputs.
#     For dict data, the default of None behaves like ``copy=True``.  For DataFrame
#     or 2d ndarray input, the default of None behaves like ``copy=False``.
#
#     .. versionchanged:: 1.3.0
#
# See Also
# --------
# DataFrame.from_records : Constructor from tuples, also record arrays.
# DataFrame.from_dict : From dicts of Series, arrays, or dicts.
# read_csv : Read a comma-separated values (csv) file into DataFrame.
# read_table : Read general delimited file into DataFrame.
# read_clipboard : Read text from clipboard into DataFrame.
#
# Examples
# --------
# Constructing DataFrame from a dictionary.
#
# >>> d = {'col1': [1, 2], 'col2': [3, 4]}
# >>> df = pd.DataFrame(data=d)
# >>> df
#    col1  col2
# 0     1     3
# 1     2     4
#
# Notice that the inferred dtype is int64.
#
# >>> df.dtypes
# col1    int64
# col2    int64
# dtype: object
#
# To enforce a single dtype:
#
# >>> df = pd.DataFrame(data=d, dtype=np.int8)
# >>> df.dtypes
# col1    int8
# col2    int8
# dtype: object
#
# Constructing DataFrame from a dictionary including Series:
#
# >>> d = {'col1': [0, 1, 2, 3], 'col2': pd.Series([2, 3], index=[2, 3])}
# >>> pd.DataFrame(data=d, index=[0, 1, 2, 3])
#    col1  col2
# 0     0   NaN
# 1     1   NaN
# 2     2   2.0
# 3     3   3.0
#
# Constructing DataFrame from numpy ndarray:
#
# >>> df2 = pd.DataFrame(np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]),
# ...                    columns=['a', 'b', 'c'])
# >>> df2
#    a  b  c
# 0  1  2  3
# 1  4  5  6
# 2  7  8  9
#
# Constructing DataFrame from a numpy ndarray that has labeled columns:
#
# >>> data = np.array([(1, 2, 3), (4, 5, 6), (7, 8, 9)],
# ...                 dtype=[("a", "i4"), ("b", "i4"), ("c", "i4")])
# >>> df3 = pd.DataFrame(data, columns=['c', 'a'])
# ...
# >>> df3
#    c  a
# 0  3  1
# 1  6  4
# 2  9  7
#
# Constructing DataFrame from dataclass:
#
# >>> from dataclasses import make_dataclass
# >>> Point = make_dataclass("Point", [("x", int), ("y", int)])
# >>> pd.DataFrame([Point(0, 0), Point(0, 3), Point(2, 3)])
#    x  y
# 0  0  0
# 1  0  3
# 2  2  3
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>pandas.io.parsers.readers.read_csv</u></summary>
# <blockquote>
# <code>
# Read a comma-separated values (csv) file into DataFrame.
#
# Also supports optionally iterating or breaking of the file
# into chunks.
#
# Additional help can be found in the online docs for
# `IO Tools <https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html>`_.
#
# Parameters
# ----------
# filepath_or_buffer : str, path object or file-like object
#     Any valid string path is acceptable. The string could be a URL. Valid
#     URL schemes include http, ftp, s3, gs, and file. For file URLs, a host is
#     expected. A local file could be: file://localhost/path/to/table.csv.
#
#     If you want to pass in a path object, pandas accepts any ``os.PathLike``.
#
#     By file-like object, we refer to objects with a ``read()`` method, such as
#     a file handle (e.g. via builtin ``open`` function) or ``StringIO``.
# sep : str, default ','
#     Delimiter to use. If sep is None, the C engine cannot automatically detect
#     the separator, but the Python parsing engine can, meaning the latter will
#     be used and automatically detect the separator by Python's builtin sniffer
#     tool, ``csv.Sniffer``. In addition, separators longer than 1 character and
#     different from ``'\s+'`` will be interpreted as regular expressions and
#     will also force the use of the Python parsing engine. Note that regex
#     delimiters are prone to ignoring quoted data. Regex example: ``'\r\t'``.
# delimiter : str, default ``None``
#     Alias for sep.
# header : int, list of int, None, default 'infer'
#     Row number(s) to use as the column names, and the start of the
#     data.  Default behavior is to infer the column names: if no names
#     are passed the behavior is identical to ``header=0`` and column
#     names are inferred from the first line of the file, if column
#     names are passed explicitly then the behavior is identical to
#     ``header=None``. Explicitly pass ``header=0`` to be able to
#     replace existing names. The header can be a list of integers that
#     specify row locations for a multi-index on the columns
#     e.g. [0,1,3]. Intervening rows that are not specified will be
#     skipped (e.g. 2 in this example is skipped). Note that this
#     parameter ignores commented lines and empty lines if
#     ``skip_blank_lines=True``, so ``header=0`` denotes the first line of
#     data rather than the first line of the file.
# names : array-like, optional
#     List of column names to use. If the file contains a header row,
#     then you should explicitly pass ``header=0`` to override the column names.
#     Duplicates in this list are not allowed.
# index_col : int, str, sequence of int / str, or False, optional, default ``None``
#   Column(s) to use as the row labels of the ``DataFrame``, either given as
#   string name or column index. If a sequence of int / str is given, a
#   MultiIndex is used.
#
#   Note: ``index_col=False`` can be used to force pandas to *not* use the first
#   column as the index, e.g. when you have a malformed file with delimiters at
#   the end of each line.
# usecols : list-like or callable, optional
#     Return a subset of the columns. If list-like, all elements must either
#     be positional (i.e. integer indices into the document columns) or strings
#     that correspond to column names provided either by the user in `names` or
#     inferred from the document header row(s). If ``names`` are given, the document
#     header row(s) are not taken into account. For example, a valid list-like
#     `usecols` parameter would be ``[0, 1, 2]`` or ``['foo', 'bar', 'baz']``.
#     Element order is ignored, so ``usecols=[0, 1]`` is the same as ``[1, 0]``.
#     To instantiate a DataFrame from ``data`` with element order preserved use
#     ``pd.read_csv(data, usecols=['foo', 'bar'])[['foo', 'bar']]`` for columns
#     in ``['foo', 'bar']`` order or
#     ``pd.read_csv(data, usecols=['foo', 'bar'])[['bar', 'foo']]``
#     for ``['bar', 'foo']`` order.
#
#     If callable, the callable function will be evaluated against the column
#     names, returning names where the callable function evaluates to True. An
#     example of a valid callable argument would be ``lambda x: x.upper() in
#     ['AAA', 'BBB', 'DDD']``. Using this parameter results in much faster
#     parsing time and lower memory usage.
# squeeze : bool, default False
#     If the parsed data only contains one column then return a Series.
#
#     .. deprecated:: 1.4.0
#         Append ``.squeeze("columns")`` to the call to ``read_csv`` to squeeze
#         the data.
# prefix : str, optional
#     Prefix to add to column numbers when no header, e.g. 'X' for X0, X1, ...
#
#     .. deprecated:: 1.4.0
#        Use a list comprehension on the DataFrame's columns after calling ``read_csv``.
# mangle_dupe_cols : bool, default True
#     Duplicate columns will be specified as 'X', 'X.1', ...'X.N', rather than
#     'X'...'X'. Passing in False will cause data to be overwritten if there
#     are duplicate names in the columns.
# dtype : Type name or dict of column -> type, optional
#     Data type for data or columns. E.g. {'a': np.float64, 'b': np.int32,
#     'c': 'Int64'}
#     Use `str` or `object` together with suitable `na_values` settings
#     to preserve and not interpret dtype.
#     If converters are specified, they will be applied INSTEAD
#     of dtype conversion.
# engine : {'c', 'python', 'pyarrow'}, optional
#     Parser engine to use. The C and pyarrow engines are faster, while the python engine
#     is currently more feature-complete. Multithreading is currently only supported by
#     the pyarrow engine.
#
#     .. versionadded:: 1.4.0
#
#         The "pyarrow" engine was added as an *experimental* engine, and some features
#         are unsupported, or may not work correctly, with this engine.
# converters : dict, optional
#     Dict of functions for converting values in certain columns. Keys can either
#     be integers or column labels.
# true_values : list, optional
#     Values to consider as True.
# false_values : list, optional
#     Values to consider as False.
# skipinitialspace : bool, default False
#     Skip spaces after delimiter.
# skiprows : list-like, int or callable, optional
#     Line numbers to skip (0-indexed) or number of lines to skip (int)
#     at the start of the file.
#
#     If callable, the callable function will be evaluated against the row
#     indices, returning True if the row should be skipped and False otherwise.
#     An example of a valid callable argument would be ``lambda x: x in [0, 2]``.
# skipfooter : int, default 0
#     Number of lines at bottom of file to skip (Unsupported with engine='c').
# nrows : int, optional
#     Number of rows of file to read. Useful for reading pieces of large files.
# na_values : scalar, str, list-like, or dict, optional
#     Additional strings to recognize as NA/NaN. If dict passed, specific
#     per-column NA values.  By default the following values are interpreted as
#     NaN: '', '#N/A', '#N/A N/A', '#NA', '-1.#IND', '-1.#QNAN', '-NaN', '-nan',
#     '1.#IND', '1.#QNAN', '<NA>', 'N/A', 'NA', 'NULL', 'NaN', 'n/a',
#     'nan', 'null'.
# keep_default_na : bool, default True
#     Whether or not to include the default NaN values when parsing the data.
#     Depending on whether `na_values` is passed in, the behavior is as follows:
#
#     * If `keep_default_na` is True, and `na_values` are specified, `na_values`
#       is appended to the default NaN values used for parsing.
#     * If `keep_default_na` is True, and `na_values` are not specified, only
#       the default NaN values are used for parsing.
#     * If `keep_default_na` is False, and `na_values` are specified, only
#       the NaN values specified `na_values` are used for parsing.
#     * If `keep_default_na` is False, and `na_values` are not specified, no
#       strings will be parsed as NaN.
#
#     Note that if `na_filter` is passed in as False, the `keep_default_na` and
#     `na_values` parameters will be ignored.
# na_filter : bool, default True
#     Detect missing value markers (empty strings and the value of na_values). In
#     data without any NAs, passing na_filter=False can improve the performance
#     of reading a large file.
# verbose : bool, default False
#     Indicate number of NA values placed in non-numeric columns.
# skip_blank_lines : bool, default True
#     If True, skip over blank lines rather than interpreting as NaN values.
# parse_dates : bool or list of int or names or list of lists or dict, default False
#     The behavior is as follows:
#
#     * boolean. If True -> try parsing the index.
#     * list of int or names. e.g. If [1, 2, 3] -> try parsing columns 1, 2, 3
#       each as a separate date column.
#     * list of lists. e.g.  If [[1, 3]] -> combine columns 1 and 3 and parse as
#       a single date column.
#     * dict, e.g. {'foo' : [1, 3]} -> parse columns 1, 3 as date and call
#       result 'foo'
#
#     If a column or index cannot be represented as an array of datetimes,
#     say because of an unparsable value or a mixture of timezones, the column
#     or index will be returned unaltered as an object data type. For
#     non-standard datetime parsing, use ``pd.to_datetime`` after
#     ``pd.read_csv``. To parse an index or column with a mixture of timezones,
#     specify ``date_parser`` to be a partially-applied
#     :func:`pandas.to_datetime` with ``utc=True``. See
#     :ref:`io.csv.mixed_timezones` for more.
#
#     Note: A fast-path exists for iso8601-formatted dates.
# infer_datetime_format : bool, default False
#     If True and `parse_dates` is enabled, pandas will attempt to infer the
#     format of the datetime strings in the columns, and if it can be inferred,
#     switch to a faster method of parsing them. In some cases this can increase
#     the parsing speed by 5-10x.
# keep_date_col : bool, default False
#     If True and `parse_dates` specifies combining multiple columns then
#     keep the original columns.
# date_parser : function, optional
#     Function to use for converting a sequence of string columns to an array of
#     datetime instances. The default uses ``dateutil.parser.parser`` to do the
#     conversion. Pandas will try to call `date_parser` in three different ways,
#     advancing to the next if an exception occurs: 1) Pass one or more arrays
#     (as defined by `parse_dates`) as arguments; 2) concatenate (row-wise) the
#     string values from the columns defined by `parse_dates` into a single array
#     and pass that; and 3) call `date_parser` once for each row using one or
#     more strings (corresponding to the columns defined by `parse_dates`) as
#     arguments.
# dayfirst : bool, default False
#     DD/MM format dates, international and European format.
# cache_dates : bool, default True
#     If True, use a cache of unique, converted dates to apply the datetime
#     conversion. May produce significant speed-up when parsing duplicate
#     date strings, especially ones with timezone offsets.
#
#     .. versionadded:: 0.25.0
# iterator : bool, default False
#     Return TextFileReader object for iteration or getting chunks with
#     ``get_chunk()``.
#
#     .. versionchanged:: 1.2
#
#        ``TextFileReader`` is a context manager.
# chunksize : int, optional
#     Return TextFileReader object for iteration.
#     See the `IO Tools docs
#     <https://pandas.pydata.org/pandas-docs/stable/io.html#io-chunking>`_
#     for more information on ``iterator`` and ``chunksize``.
#
#     .. versionchanged:: 1.2
#
#        ``TextFileReader`` is a context manager.
# compression : str or dict, default 'infer'
#     For on-the-fly decompression of on-disk data. If 'infer' and '%s' is
#     path-like, then detect compression from the following extensions: '.gz',
#     '.bz2', '.zip', '.xz', or '.zst' (otherwise no compression). If using
#     'zip', the ZIP file must contain only one data file to be read in. Set to
#     ``None`` for no decompression. Can also be a dict with key ``'method'`` set
#     to one of {``'zip'``, ``'gzip'``, ``'bz2'``, ``'zstd'``} and other
#     key-value pairs are forwarded to ``zipfile.ZipFile``, ``gzip.GzipFile``,
#     ``bz2.BZ2File``, or ``zstandard.ZstdDecompressor``, respectively. As an
#     example, the following could be passed for Zstandard decompression using a
#     custom compression dictionary:
#     ``compression={'method': 'zstd', 'dict_data': my_compression_dict}``.
#
#     .. versionchanged:: 1.4.0 Zstandard support.
#
# thousands : str, optional
#     Thousands separator.
# decimal : str, default '.'
#     Character to recognize as decimal point (e.g. use ',' for European data).
# lineterminator : str (length 1), optional
#     Character to break file into lines. Only valid with C parser.
# quotechar : str (length 1), optional
#     The character used to denote the start and end of a quoted item. Quoted
#     items can include the delimiter and it will be ignored.
# quoting : int or csv.QUOTE_* instance, default 0
#     Control field quoting behavior per ``csv.QUOTE_*`` constants. Use one of
#     QUOTE_MINIMAL (0), QUOTE_ALL (1), QUOTE_NONNUMERIC (2) or QUOTE_NONE (3).
# doublequote : bool, default ``True``
#    When quotechar is specified and quoting is not ``QUOTE_NONE``, indicate
#    whether or not to interpret two consecutive quotechar elements INSIDE a
#    field as a single ``quotechar`` element.
# escapechar : str (length 1), optional
#     One-character string used to escape other characters.
# comment : str, optional
#     Indicates remainder of line should not be parsed. If found at the beginning
#     of a line, the line will be ignored altogether. This parameter must be a
#     single character. Like empty lines (as long as ``skip_blank_lines=True``),
#     fully commented lines are ignored by the parameter `header` but not by
#     `skiprows`. For example, if ``comment='#'``, parsing
#     ``#empty\na,b,c\n1,2,3`` with ``header=0`` will result in 'a,b,c' being
#     treated as the header.
# encoding : str, optional
#     Encoding to use for UTF when reading/writing (ex. 'utf-8'). `List of Python
#     standard encodings
#     <https://docs.python.org/3/library/codecs.html#standard-encodings>`_ .
#
#     .. versionchanged:: 1.2
#
#        When ``encoding`` is ``None``, ``errors="replace"`` is passed to
#        ``open()``. Otherwise, ``errors="strict"`` is passed to ``open()``.
#        This behavior was previously only the case for ``engine="python"``.
#
#     .. versionchanged:: 1.3.0
#
#        ``encoding_errors`` is a new argument. ``encoding`` has no longer an
#        influence on how encoding errors are handled.
#
# encoding_errors : str, optional, default "strict"
#     How encoding errors are treated. `List of possible values
#     <https://docs.python.org/3/library/codecs.html#error-handlers>`_ .
#
#     .. versionadded:: 1.3.0
#
# dialect : str or csv.Dialect, optional
#     If provided, this parameter will override values (default or not) for the
#     following parameters: `delimiter`, `doublequote`, `escapechar`,
#     `skipinitialspace`, `quotechar`, and `quoting`. If it is necessary to
#     override values, a ParserWarning will be issued. See csv.Dialect
#     documentation for more details.
# error_bad_lines : bool, optional, default ``None``
#     Lines with too many fields (e.g. a csv line with too many commas) will by
#     default cause an exception to be raised, and no DataFrame will be returned.
#     If False, then these "bad lines" will be dropped from the DataFrame that is
#     returned.
#
#     .. deprecated:: 1.3.0
#        The ``on_bad_lines`` parameter should be used instead to specify behavior upon
#        encountering a bad line instead.
# warn_bad_lines : bool, optional, default ``None``
#     If error_bad_lines is False, and warn_bad_lines is True, a warning for each
#     "bad line" will be output.
#
#     .. deprecated:: 1.3.0
#        The ``on_bad_lines`` parameter should be used instead to specify behavior upon
#        encountering a bad line instead.
# on_bad_lines : {'error', 'warn', 'skip'} or callable, default 'error'
#     Specifies what to do upon encountering a bad line (a line with too many fields).
#     Allowed values are :
#
#         - 'error', raise an Exception when a bad line is encountered.
#         - 'warn', raise a warning when a bad line is encountered and skip that line.
#         - 'skip', skip bad lines without raising or warning when they are encountered.
#
#     .. versionadded:: 1.3.0
#
#         - callable, function with signature
#           ``(bad_line: list[str]) -> list[str] | None`` that will process a single
#           bad line. ``bad_line`` is a list of strings split by the ``sep``.
#           If the function returns ``None``, the bad line will be ignored.
#           If the function returns a new list of strings with more elements than
#           expected, a ``ParserWarning`` will be emitted while dropping extra elements.
#           Only supported when ``engine="python"``
#
#     .. versionadded:: 1.4.0
#
# delim_whitespace : bool, default False
#     Specifies whether or not whitespace (e.g. ``' '`` or ``'    '``) will be
#     used as the sep. Equivalent to setting ``sep='\s+'``. If this option
#     is set to True, nothing should be passed in for the ``delimiter``
#     parameter.
# low_memory : bool, default True
#     Internally process the file in chunks, resulting in lower memory use
#     while parsing, but possibly mixed type inference.  To ensure no mixed
#     types either set False, or specify the type with the `dtype` parameter.
#     Note that the entire file is read into a single DataFrame regardless,
#     use the `chunksize` or `iterator` parameter to return the data in chunks.
#     (Only valid with C parser).
# memory_map : bool, default False
#     If a filepath is provided for `filepath_or_buffer`, map the file object
#     directly onto memory and access the data directly from there. Using this
#     option can improve performance because there is no longer any I/O overhead.
# float_precision : str, optional
#     Specifies which converter the C engine should use for floating-point
#     values. The options are ``None`` or 'high' for the ordinary converter,
#     'legacy' for the original lower precision pandas converter, and
#     'round_trip' for the round-trip converter.
#
#     .. versionchanged:: 1.2
#
# storage_options : dict, optional
#     Extra options that make sense for a particular storage connection, e.g.
#     host, port, username, password, etc. For HTTP(S) URLs the key-value pairs
#     are forwarded to ``urllib`` as header options. For other URLs (e.g.
#     starting with "s3://", and "gcs://") the key-value pairs are forwarded to
#     ``fsspec``. Please see ``fsspec`` and ``urllib`` for more details.
#
#     .. versionadded:: 1.2
#
# Returns
# -------
# DataFrame or TextParser
#     A comma-separated values (csv) file is returned as two-dimensional
#     data structure with labeled axes.
#
# See Also
# --------
# DataFrame.to_csv : Write DataFrame to a comma-separated values (csv) file.
# read_csv : Read a comma-separated values (csv) file into DataFrame.
# read_fwf : Read a table of fixed-width formatted lines into DataFrame.
#
# Examples
# --------
# >>> pd.read_csv('data.csv')  # doctest: +SKIP
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>random</b>
# <ul>
# <li>
# <details><summary><u>random.Random.choice</u></summary>
# <blockquote>
# <code>
# Choose a random element from a non-empty sequence.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>random.Random.uniform</u></summary>
# <blockquote>
# <code>
# Get a random number in the range [a, b) or [a, b] depending on rounding.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>sklearn</b>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA</u></summary>
# <blockquote>
# <code>
# Principal component analysis (PCA).
#
# Linear dimensionality reduction using Singular Value Decomposition of the
# data to project it to a lower dimensional space. The input data is centered
# but not scaled for each feature before applying the SVD.
#
# It uses the LAPACK implementation of the full SVD or a randomized truncated
# SVD by the method of Halko et al. 2009, depending on the shape of the input
# data and the number of components to extract.
#
# It can also use the scipy.sparse.linalg ARPACK implementation of the
# truncated SVD.
#
# Notice that this class does not support sparse input. See
# :class:`TruncatedSVD` for an alternative with sparse data.
#
# Read more in the :ref:`User Guide <PCA>`.
#
# Parameters
# ----------
# n_components : int, float or 'mle', default=None
#     Number of components to keep.
#     if n_components is not set all components are kept::
#
#         n_components == min(n_samples, n_features)
#
#     If ``n_components == 'mle'`` and ``svd_solver == 'full'``, Minka's
#     MLE is used to guess the dimension. Use of ``n_components == 'mle'``
#     will interpret ``svd_solver == 'auto'`` as ``svd_solver == 'full'``.
#
#     If ``0 < n_components < 1`` and ``svd_solver == 'full'``, select the
#     number of components such that the amount of variance that needs to be
#     explained is greater than the percentage specified by n_components.
#
#     If ``svd_solver == 'arpack'``, the number of components must be
#     strictly less than the minimum of n_features and n_samples.
#
#     Hence, the None case results in::
#
#         n_components == min(n_samples, n_features) - 1
#
# copy : bool, default=True
#     If False, data passed to fit are overwritten and running
#     fit(X).transform(X) will not yield the expected results,
#     use fit_transform(X) instead.
#
# whiten : bool, default=False
#     When True (False by default) the `components_` vectors are multiplied
#     by the square root of n_samples and then divided by the singular values
#     to ensure uncorrelated outputs with unit component-wise variances.
#
#     Whitening will remove some information from the transformed signal
#     (the relative variance scales of the components) but can sometime
#     improve the predictive accuracy of the downstream estimators by
#     making their data respect some hard-wired assumptions.
#
# svd_solver : {'auto', 'full', 'arpack', 'randomized'}, default='auto'
#     If auto :
#         The solver is selected by a default policy based on `X.shape` and
#         `n_components`: if the input data is larger than 500x500 and the
#         number of components to extract is lower than 80% of the smallest
#         dimension of the data, then the more efficient 'randomized'
#         method is enabled. Otherwise the exact full SVD is computed and
#         optionally truncated afterwards.
#     If full :
#         run exact full SVD calling the standard LAPACK solver via
#         `scipy.linalg.svd` and select the components by postprocessing
#     If arpack :
#         run SVD truncated to n_components calling ARPACK solver via
#         `scipy.sparse.linalg.svds`. It requires strictly
#         0 < n_components < min(X.shape)
#     If randomized :
#         run randomized SVD by the method of Halko et al.
#
#     .. versionadded:: 0.18.0
#
# tol : float, default=0.0
#     Tolerance for singular values computed by svd_solver == 'arpack'.
#     Must be of range [0.0, infinity).
#
#     .. versionadded:: 0.18.0
#
# iterated_power : int or 'auto', default='auto'
#     Number of iterations for the power method computed by
#     svd_solver == 'randomized'.
#     Must be of range [0, infinity).
#
#     .. versionadded:: 0.18.0
#
# random_state : int, RandomState instance or None, default=None
#     Used when the 'arpack' or 'randomized' solvers are used. Pass an int
#     for reproducible results across multiple function calls.
#     See :term:`Glossary <random_state>`.
#
#     .. versionadded:: 0.18.0
#
# Attributes
# ----------
# components_ : ndarray of shape (n_components, n_features)
#     Principal axes in feature space, representing the directions of
#     maximum variance in the data. Equivalently, the right singular
#     vectors of the centered input data, parallel to its eigenvectors.
#     The components are sorted by ``explained_variance_``.
#
# explained_variance_ : ndarray of shape (n_components,)
#     The amount of variance explained by each of the selected components.
#     The variance estimation uses `n_samples - 1` degrees of freedom.
#
#     Equal to n_components largest eigenvalues
#     of the covariance matrix of X.
#
#     .. versionadded:: 0.18
#
# explained_variance_ratio_ : ndarray of shape (n_components,)
#     Percentage of variance explained by each of the selected components.
#
#     If ``n_components`` is not set then all components are stored and the
#     sum of the ratios is equal to 1.0.
#
# singular_values_ : ndarray of shape (n_components,)
#     The singular values corresponding to each of the selected components.
#     The singular values are equal to the 2-norms of the ``n_components``
#     variables in the lower-dimensional space.
#
#     .. versionadded:: 0.19
#
# mean_ : ndarray of shape (n_features,)
#     Per-feature empirical mean, estimated from the training set.
#
#     Equal to `X.mean(axis=0)`.
#
# n_components_ : int
#     The estimated number of components. When n_components is set
#     to 'mle' or a number between 0 and 1 (with svd_solver == 'full') this
#     number is estimated from input data. Otherwise it equals the parameter
#     n_components, or the lesser value of n_features and n_samples
#     if n_components is None.
#
# n_features_ : int
#     Number of features in the training data.
#
# n_samples_ : int
#     Number of samples in the training data.
#
# noise_variance_ : float
#     The estimated noise covariance following the Probabilistic PCA model
#     from Tipping and Bishop 1999. See "Pattern Recognition and
#     Machine Learning" by C. Bishop, 12.2.1 p. 574 or
#     http://www.miketipping.com/papers/met-mppca.pdf. It is required to
#     compute the estimated data covariance and score samples.
#
#     Equal to the average of (min(n_features, n_samples) - n_components)
#     smallest eigenvalues of the covariance matrix of X.
#
# n_features_in_ : int
#     Number of features seen during :term:`fit`.
#
#     .. versionadded:: 0.24
#
# feature_names_in_ : ndarray of shape (`n_features_in_`,)
#     Names of features seen during :term:`fit`. Defined only when `X`
#     has feature names that are all strings.
#
#     .. versionadded:: 1.0
#
# See Also
# --------
# KernelPCA : Kernel Principal Component Analysis.
# SparsePCA : Sparse Principal Component Analysis.
# TruncatedSVD : Dimensionality reduction using truncated SVD.
# IncrementalPCA : Incremental Principal Component Analysis.
#
# References
# ----------
# For n_components == 'mle', this class uses the method from:
# `Minka, T. P.. "Automatic choice of dimensionality for PCA".
# In NIPS, pp. 598-604 <https://tminka.github.io/papers/pca/minka-pca.pdf>`_
#
# Implements the probabilistic PCA model from:
# `Tipping, M. E., and Bishop, C. M. (1999). "Probabilistic principal
# component analysis". Journal of the Royal Statistical Society:
# Series B (Statistical Methodology), 61(3), 611-622.
# <http://www.miketipping.com/papers/met-mppca.pdf>`_
# via the score and score_samples methods.
#
# For svd_solver == 'arpack', refer to `scipy.sparse.linalg.svds`.
#
# For svd_solver == 'randomized', see:
# `Halko, N., Martinsson, P. G., and Tropp, J. A. (2011).
# "Finding structure with randomness: Probabilistic algorithms for
# constructing approximate matrix decompositions".
# SIAM review, 53(2), 217-288.
# <https://doi.org/10.1137/090771806>`_
# and also
# `Martinsson, P. G., Rokhlin, V., and Tygert, M. (2011).
# "A randomized algorithm for the decomposition of matrices".
# Applied and Computational Harmonic Analysis, 30(1), 47-68
# <https://doi.org/10.1016/j.acha.2010.02.003>`_.
#
# Examples
# --------
# >>> import numpy as np
# >>> from sklearn.decomposition import PCA
# >>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
# >>> pca = PCA(n_components=2)
# >>> pca.fit(X)
# PCA(n_components=2)
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.0075...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=2, svd_solver='full')
# >>> pca.fit(X)
# PCA(n_components=2, svd_solver='full')
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.00755...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=1, svd_solver='arpack')
# >>> pca.fit(X)
# PCA(n_components=1, svd_solver='arpack')
# >>> print(pca.explained_variance_ratio_)
# [0.99244...]
# >>> print(pca.singular_values_)
# [6.30061...]
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u></summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <b>tensorflow</b>
# <ul>
# <li>
# <details><summary><u>tensorflow._api.v2.compat.v2</u></summary>
# <blockquote>
# <code>
# Bring in all of the public TensorFlow interface into this module.
#
# </code>
# <a href='#top_phases'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>1. Library Loading</h1>  <a id='1'></a><small><a href='#top_phases'>back to top</a></small>

# %% _uuid="8f2839f25d086af736a60e9eeb907d3b93b6e0e5" _cell_guid="b1076dfc-b9ad-4769-8c92-a6c4dae69d19"
import os
import numpy as np
import pandas as pd


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>2. Data Preparation</h1>  <a id='2'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>pandas</h2>
# <ul>
# <li>
# <details><summary><u>pandas.io.parsers.readers.read_csv</u></summary>
# <blockquote>
# <code>
# Read a comma-separated values (csv) file into DataFrame.
#
# Also supports optionally iterating or breaking of the file
# into chunks.
#
# Additional help can be found in the online docs for
# `IO Tools <https://pandas.pydata.org/pandas-docs/stable/user_guide/io.html>`_.
#
# Parameters
# ----------
# filepath_or_buffer : str, path object or file-like object
#     Any valid string path is acceptable. The string could be a URL. Valid
#     URL schemes include http, ftp, s3, gs, and file. For file URLs, a host is
#     expected. A local file could be: file://localhost/path/to/table.csv.
#
#     If you want to pass in a path object, pandas accepts any ``os.PathLike``.
#
#     By file-like object, we refer to objects with a ``read()`` method, such as
#     a file handle (e.g. via builtin ``open`` function) or ``StringIO``.
# sep : str, default ','
#     Delimiter to use. If sep is None, the C engine cannot automatically detect
#     the separator, but the Python parsing engine can, meaning the latter will
#     be used and automatically detect the separator by Python's builtin sniffer
#     tool, ``csv.Sniffer``. In addition, separators longer than 1 character and
#     different from ``'\s+'`` will be interpreted as regular expressions and
#     will also force the use of the Python parsing engine. Note that regex
#     delimiters are prone to ignoring quoted data. Regex example: ``'\r\t'``.
# delimiter : str, default ``None``
#     Alias for sep.
# header : int, list of int, None, default 'infer'
#     Row number(s) to use as the column names, and the start of the
#     data.  Default behavior is to infer the column names: if no names
#     are passed the behavior is identical to ``header=0`` and column
#     names are inferred from the first line of the file, if column
#     names are passed explicitly then the behavior is identical to
#     ``header=None``. Explicitly pass ``header=0`` to be able to
#     replace existing names. The header can be a list of integers that
#     specify row locations for a multi-index on the columns
#     e.g. [0,1,3]. Intervening rows that are not specified will be
#     skipped (e.g. 2 in this example is skipped). Note that this
#     parameter ignores commented lines and empty lines if
#     ``skip_blank_lines=True``, so ``header=0`` denotes the first line of
#     data rather than the first line of the file.
# names : array-like, optional
#     List of column names to use. If the file contains a header row,
#     then you should explicitly pass ``header=0`` to override the column names.
#     Duplicates in this list are not allowed.
# index_col : int, str, sequence of int / str, or False, optional, default ``None``
#   Column(s) to use as the row labels of the ``DataFrame``, either given as
#   string name or column index. If a sequence of int / str is given, a
#   MultiIndex is used.
#
#   Note: ``index_col=False`` can be used to force pandas to *not* use the first
#   column as the index, e.g. when you have a malformed file with delimiters at
#   the end of each line.
# usecols : list-like or callable, optional
#     Return a subset of the columns. If list-like, all elements must either
#     be positional (i.e. integer indices into the document columns) or strings
#     that correspond to column names provided either by the user in `names` or
#     inferred from the document header row(s). If ``names`` are given, the document
#     header row(s) are not taken into account. For example, a valid list-like
#     `usecols` parameter would be ``[0, 1, 2]`` or ``['foo', 'bar', 'baz']``.
#     Element order is ignored, so ``usecols=[0, 1]`` is the same as ``[1, 0]``.
#     To instantiate a DataFrame from ``data`` with element order preserved use
#     ``pd.read_csv(data, usecols=['foo', 'bar'])[['foo', 'bar']]`` for columns
#     in ``['foo', 'bar']`` order or
#     ``pd.read_csv(data, usecols=['foo', 'bar'])[['bar', 'foo']]``
#     for ``['bar', 'foo']`` order.
#
#     If callable, the callable function will be evaluated against the column
#     names, returning names where the callable function evaluates to True. An
#     example of a valid callable argument would be ``lambda x: x.upper() in
#     ['AAA', 'BBB', 'DDD']``. Using this parameter results in much faster
#     parsing time and lower memory usage.
# squeeze : bool, default False
#     If the parsed data only contains one column then return a Series.
#
#     .. deprecated:: 1.4.0
#         Append ``.squeeze("columns")`` to the call to ``read_csv`` to squeeze
#         the data.
# prefix : str, optional
#     Prefix to add to column numbers when no header, e.g. 'X' for X0, X1, ...
#
#     .. deprecated:: 1.4.0
#        Use a list comprehension on the DataFrame's columns after calling ``read_csv``.
# mangle_dupe_cols : bool, default True
#     Duplicate columns will be specified as 'X', 'X.1', ...'X.N', rather than
#     'X'...'X'. Passing in False will cause data to be overwritten if there
#     are duplicate names in the columns.
# dtype : Type name or dict of column -> type, optional
#     Data type for data or columns. E.g. {'a': np.float64, 'b': np.int32,
#     'c': 'Int64'}
#     Use `str` or `object` together with suitable `na_values` settings
#     to preserve and not interpret dtype.
#     If converters are specified, they will be applied INSTEAD
#     of dtype conversion.
# engine : {'c', 'python', 'pyarrow'}, optional
#     Parser engine to use. The C and pyarrow engines are faster, while the python engine
#     is currently more feature-complete. Multithreading is currently only supported by
#     the pyarrow engine.
#
#     .. versionadded:: 1.4.0
#
#         The "pyarrow" engine was added as an *experimental* engine, and some features
#         are unsupported, or may not work correctly, with this engine.
# converters : dict, optional
#     Dict of functions for converting values in certain columns. Keys can either
#     be integers or column labels.
# true_values : list, optional
#     Values to consider as True.
# false_values : list, optional
#     Values to consider as False.
# skipinitialspace : bool, default False
#     Skip spaces after delimiter.
# skiprows : list-like, int or callable, optional
#     Line numbers to skip (0-indexed) or number of lines to skip (int)
#     at the start of the file.
#
#     If callable, the callable function will be evaluated against the row
#     indices, returning True if the row should be skipped and False otherwise.
#     An example of a valid callable argument would be ``lambda x: x in [0, 2]``.
# skipfooter : int, default 0
#     Number of lines at bottom of file to skip (Unsupported with engine='c').
# nrows : int, optional
#     Number of rows of file to read. Useful for reading pieces of large files.
# na_values : scalar, str, list-like, or dict, optional
#     Additional strings to recognize as NA/NaN. If dict passed, specific
#     per-column NA values.  By default the following values are interpreted as
#     NaN: '', '#N/A', '#N/A N/A', '#NA', '-1.#IND', '-1.#QNAN', '-NaN', '-nan',
#     '1.#IND', '1.#QNAN', '<NA>', 'N/A', 'NA', 'NULL', 'NaN', 'n/a',
#     'nan', 'null'.
# keep_default_na : bool, default True
#     Whether or not to include the default NaN values when parsing the data.
#     Depending on whether `na_values` is passed in, the behavior is as follows:
#
#     * If `keep_default_na` is True, and `na_values` are specified, `na_values`
#       is appended to the default NaN values used for parsing.
#     * If `keep_default_na` is True, and `na_values` are not specified, only
#       the default NaN values are used for parsing.
#     * If `keep_default_na` is False, and `na_values` are specified, only
#       the NaN values specified `na_values` are used for parsing.
#     * If `keep_default_na` is False, and `na_values` are not specified, no
#       strings will be parsed as NaN.
#
#     Note that if `na_filter` is passed in as False, the `keep_default_na` and
#     `na_values` parameters will be ignored.
# na_filter : bool, default True
#     Detect missing value markers (empty strings and the value of na_values). In
#     data without any NAs, passing na_filter=False can improve the performance
#     of reading a large file.
# verbose : bool, default False
#     Indicate number of NA values placed in non-numeric columns.
# skip_blank_lines : bool, default True
#     If True, skip over blank lines rather than interpreting as NaN values.
# parse_dates : bool or list of int or names or list of lists or dict, default False
#     The behavior is as follows:
#
#     * boolean. If True -> try parsing the index.
#     * list of int or names. e.g. If [1, 2, 3] -> try parsing columns 1, 2, 3
#       each as a separate date column.
#     * list of lists. e.g.  If [[1, 3]] -> combine columns 1 and 3 and parse as
#       a single date column.
#     * dict, e.g. {'foo' : [1, 3]} -> parse columns 1, 3 as date and call
#       result 'foo'
#
#     If a column or index cannot be represented as an array of datetimes,
#     say because of an unparsable value or a mixture of timezones, the column
#     or index will be returned unaltered as an object data type. For
#     non-standard datetime parsing, use ``pd.to_datetime`` after
#     ``pd.read_csv``. To parse an index or column with a mixture of timezones,
#     specify ``date_parser`` to be a partially-applied
#     :func:`pandas.to_datetime` with ``utc=True``. See
#     :ref:`io.csv.mixed_timezones` for more.
#
#     Note: A fast-path exists for iso8601-formatted dates.
# infer_datetime_format : bool, default False
#     If True and `parse_dates` is enabled, pandas will attempt to infer the
#     format of the datetime strings in the columns, and if it can be inferred,
#     switch to a faster method of parsing them. In some cases this can increase
#     the parsing speed by 5-10x.
# keep_date_col : bool, default False
#     If True and `parse_dates` specifies combining multiple columns then
#     keep the original columns.
# date_parser : function, optional
#     Function to use for converting a sequence of string columns to an array of
#     datetime instances. The default uses ``dateutil.parser.parser`` to do the
#     conversion. Pandas will try to call `date_parser` in three different ways,
#     advancing to the next if an exception occurs: 1) Pass one or more arrays
#     (as defined by `parse_dates`) as arguments; 2) concatenate (row-wise) the
#     string values from the columns defined by `parse_dates` into a single array
#     and pass that; and 3) call `date_parser` once for each row using one or
#     more strings (corresponding to the columns defined by `parse_dates`) as
#     arguments.
# dayfirst : bool, default False
#     DD/MM format dates, international and European format.
# cache_dates : bool, default True
#     If True, use a cache of unique, converted dates to apply the datetime
#     conversion. May produce significant speed-up when parsing duplicate
#     date strings, especially ones with timezone offsets.
#
#     .. versionadded:: 0.25.0
# iterator : bool, default False
#     Return TextFileReader object for iteration or getting chunks with
#     ``get_chunk()``.
#
#     .. versionchanged:: 1.2
#
#        ``TextFileReader`` is a context manager.
# chunksize : int, optional
#     Return TextFileReader object for iteration.
#     See the `IO Tools docs
#     <https://pandas.pydata.org/pandas-docs/stable/io.html#io-chunking>`_
#     for more information on ``iterator`` and ``chunksize``.
#
#     .. versionchanged:: 1.2
#
#        ``TextFileReader`` is a context manager.
# compression : str or dict, default 'infer'
#     For on-the-fly decompression of on-disk data. If 'infer' and '%s' is
#     path-like, then detect compression from the following extensions: '.gz',
#     '.bz2', '.zip', '.xz', or '.zst' (otherwise no compression). If using
#     'zip', the ZIP file must contain only one data file to be read in. Set to
#     ``None`` for no decompression. Can also be a dict with key ``'method'`` set
#     to one of {``'zip'``, ``'gzip'``, ``'bz2'``, ``'zstd'``} and other
#     key-value pairs are forwarded to ``zipfile.ZipFile``, ``gzip.GzipFile``,
#     ``bz2.BZ2File``, or ``zstandard.ZstdDecompressor``, respectively. As an
#     example, the following could be passed for Zstandard decompression using a
#     custom compression dictionary:
#     ``compression={'method': 'zstd', 'dict_data': my_compression_dict}``.
#
#     .. versionchanged:: 1.4.0 Zstandard support.
#
# thousands : str, optional
#     Thousands separator.
# decimal : str, default '.'
#     Character to recognize as decimal point (e.g. use ',' for European data).
# lineterminator : str (length 1), optional
#     Character to break file into lines. Only valid with C parser.
# quotechar : str (length 1), optional
#     The character used to denote the start and end of a quoted item. Quoted
#     items can include the delimiter and it will be ignored.
# quoting : int or csv.QUOTE_* instance, default 0
#     Control field quoting behavior per ``csv.QUOTE_*`` constants. Use one of
#     QUOTE_MINIMAL (0), QUOTE_ALL (1), QUOTE_NONNUMERIC (2) or QUOTE_NONE (3).
# doublequote : bool, default ``True``
#    When quotechar is specified and quoting is not ``QUOTE_NONE``, indicate
#    whether or not to interpret two consecutive quotechar elements INSIDE a
#    field as a single ``quotechar`` element.
# escapechar : str (length 1), optional
#     One-character string used to escape other characters.
# comment : str, optional
#     Indicates remainder of line should not be parsed. If found at the beginning
#     of a line, the line will be ignored altogether. This parameter must be a
#     single character. Like empty lines (as long as ``skip_blank_lines=True``),
#     fully commented lines are ignored by the parameter `header` but not by
#     `skiprows`. For example, if ``comment='#'``, parsing
#     ``#empty\na,b,c\n1,2,3`` with ``header=0`` will result in 'a,b,c' being
#     treated as the header.
# encoding : str, optional
#     Encoding to use for UTF when reading/writing (ex. 'utf-8'). `List of Python
#     standard encodings
#     <https://docs.python.org/3/library/codecs.html#standard-encodings>`_ .
#
#     .. versionchanged:: 1.2
#
#        When ``encoding`` is ``None``, ``errors="replace"`` is passed to
#        ``open()``. Otherwise, ``errors="strict"`` is passed to ``open()``.
#        This behavior was previously only the case for ``engine="python"``.
#
#     .. versionchanged:: 1.3.0
#
#        ``encoding_errors`` is a new argument. ``encoding`` has no longer an
#        influence on how encoding errors are handled.
#
# encoding_errors : str, optional, default "strict"
#     How encoding errors are treated. `List of possible values
#     <https://docs.python.org/3/library/codecs.html#error-handlers>`_ .
#
#     .. versionadded:: 1.3.0
#
# dialect : str or csv.Dialect, optional
#     If provided, this parameter will override values (default or not) for the
#     following parameters: `delimiter`, `doublequote`, `escapechar`,
#     `skipinitialspace`, `quotechar`, and `quoting`. If it is necessary to
#     override values, a ParserWarning will be issued. See csv.Dialect
#     documentation for more details.
# error_bad_lines : bool, optional, default ``None``
#     Lines with too many fields (e.g. a csv line with too many commas) will by
#     default cause an exception to be raised, and no DataFrame will be returned.
#     If False, then these "bad lines" will be dropped from the DataFrame that is
#     returned.
#
#     .. deprecated:: 1.3.0
#        The ``on_bad_lines`` parameter should be used instead to specify behavior upon
#        encountering a bad line instead.
# warn_bad_lines : bool, optional, default ``None``
#     If error_bad_lines is False, and warn_bad_lines is True, a warning for each
#     "bad line" will be output.
#
#     .. deprecated:: 1.3.0
#        The ``on_bad_lines`` parameter should be used instead to specify behavior upon
#        encountering a bad line instead.
# on_bad_lines : {'error', 'warn', 'skip'} or callable, default 'error'
#     Specifies what to do upon encountering a bad line (a line with too many fields).
#     Allowed values are :
#
#         - 'error', raise an Exception when a bad line is encountered.
#         - 'warn', raise a warning when a bad line is encountered and skip that line.
#         - 'skip', skip bad lines without raising or warning when they are encountered.
#
#     .. versionadded:: 1.3.0
#
#         - callable, function with signature
#           ``(bad_line: list[str]) -> list[str] | None`` that will process a single
#           bad line. ``bad_line`` is a list of strings split by the ``sep``.
#           If the function returns ``None``, the bad line will be ignored.
#           If the function returns a new list of strings with more elements than
#           expected, a ``ParserWarning`` will be emitted while dropping extra elements.
#           Only supported when ``engine="python"``
#
#     .. versionadded:: 1.4.0
#
# delim_whitespace : bool, default False
#     Specifies whether or not whitespace (e.g. ``' '`` or ``'    '``) will be
#     used as the sep. Equivalent to setting ``sep='\s+'``. If this option
#     is set to True, nothing should be passed in for the ``delimiter``
#     parameter.
# low_memory : bool, default True
#     Internally process the file in chunks, resulting in lower memory use
#     while parsing, but possibly mixed type inference.  To ensure no mixed
#     types either set False, or specify the type with the `dtype` parameter.
#     Note that the entire file is read into a single DataFrame regardless,
#     use the `chunksize` or `iterator` parameter to return the data in chunks.
#     (Only valid with C parser).
# memory_map : bool, default False
#     If a filepath is provided for `filepath_or_buffer`, map the file object
#     directly onto memory and access the data directly from there. Using this
#     option can improve performance because there is no longer any I/O overhead.
# float_precision : str, optional
#     Specifies which converter the C engine should use for floating-point
#     values. The options are ``None`` or 'high' for the ordinary converter,
#     'legacy' for the original lower precision pandas converter, and
#     'round_trip' for the round-trip converter.
#
#     .. versionchanged:: 1.2
#
# storage_options : dict, optional
#     Extra options that make sense for a particular storage connection, e.g.
#     host, port, username, password, etc. For HTTP(S) URLs the key-value pairs
#     are forwarded to ``urllib`` as header options. For other URLs (e.g.
#     starting with "s3://", and "gcs://") the key-value pairs are forwarded to
#     ``fsspec``. Please see ``fsspec`` and ``urllib`` for more details.
#
#     .. versionadded:: 1.2
#
# Returns
# -------
# DataFrame or TextParser
#     A comma-separated values (csv) file is returned as two-dimensional
#     data structure with labeled axes.
#
# See Also
# --------
# DataFrame.to_csv : Write DataFrame to a comma-separated values (csv) file.
# read_csv : Read a comma-separated values (csv) file into DataFrame.
# read_fwf : Read a table of fixed-width formatted lines into DataFrame.
#
# Examples
# --------
# >>> pd.read_csv('data.csv')  # doctest: +SKIP
#
# </code>
# <a href='#2'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %% _cell_guid="79c7e3d0-c299-4dcb-8224-4455121ee9b0" _uuid="d629ff2d2480ee46fbb7e2d37f6b5fab8052498a"
train_df = pd.read_csv('../input/train.csv')
test_df = pd.read_csv('../input/test.csv')


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>3. Data Preparation</h1>  <a id='3'></a><small><a href='#top_phases'>back to top</a></small>

# %%
features = train_df.columns
features[2:]


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>4. Library Loading</h1>  <a id='4'></a><small><a href='#top_phases'>back to top</a></small>

# %%
from tqdm import tqdm_notebook as tqdm



# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>5. Data Preparation | Feature Engineering</h1>  <a id='5'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>numpy</h2>
# <ul>
# <li>
# <details><summary><u>numpy.core.fromnumeric.mean</u></summary>
# <blockquote>
# <code>
# Compute the arithmetic mean along the specified axis.
#
# Returns the average of the array elements.  The average is taken over
# the flattened array by default, otherwise over the specified axis.
# `float64` intermediate and return values are used for integer inputs.
#
# Parameters
# ----------
# a : array_like
#     Array containing numbers whose mean is desired. If `a` is not an
#     array, a conversion is attempted.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the means are computed. The default is to
#     compute the mean of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a mean is performed over multiple axes,
#     instead of a single axis or all the axes as before.
# dtype : data-type, optional
#     Type to use in computing the mean.  For integer inputs, the default
#     is `float64`; for floating point inputs, it is the same as the
#     input dtype.
# out : ndarray, optional
#     Alternate output array in which to place the result.  The default
#     is ``None``; if provided, it must have the same shape as the
#     expected output, but the type will be cast if necessary.
#     See :ref:`ufuncs-output-type` for more details.
#
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `mean` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the mean. See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# m : ndarray, see dtype parameter above
#     If `out=None`, returns a new array containing the mean values,
#     otherwise a reference to the output array is returned.
#
# See Also
# --------
# average : Weighted average
# std, var, nanmean, nanstd, nanvar
#
# Notes
# -----
# The arithmetic mean is the sum of the elements along the axis divided
# by the number of elements.
#
# Note that for floating-point input, the mean is computed using the
# same precision the input has.  Depending on the input data, this can
# cause the results to be inaccurate, especially for `float32` (see
# example below).  Specifying a higher-precision accumulator using the
# `dtype` keyword can alleviate this issue.
#
# By default, `float16` results are computed using `float32` intermediates
# for extra precision.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.mean(a)
# 2.5
# >>> np.mean(a, axis=0)
# array([2., 3.])
# >>> np.mean(a, axis=1)
# array([1.5, 3.5])
#
# In single precision, `mean` can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.mean(a)
# 0.54999924
#
# Computing the mean in float64 is more accurate:
#
# >>> np.mean(a, dtype=np.float64)
# 0.55000000074505806 # may vary
#
# Specifying a where argument:
# >>> a = np.array([[5, 9, 13], [14, 10, 12], [11, 15, 19]])
# >>> np.mean(a)
# 12.0
# >>> np.mean(a, where=[[True], [False], [False]])
# 9.0
#
# </code>
# <a href='#5'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.core.fromnumeric.std</u></summary>
# <blockquote>
# <code>
# Compute the standard deviation along the specified axis.
#
# Returns the standard deviation, a measure of the spread of a distribution,
# of the array elements. The standard deviation is computed for the
# flattened array by default, otherwise over the specified axis.
#
# Parameters
# ----------
# a : array_like
#     Calculate the standard deviation of these values.
# axis : None or int or tuple of ints, optional
#     Axis or axes along which the standard deviation is computed. The
#     default is to compute the standard deviation of the flattened array.
#
#     .. versionadded:: 1.7.0
#
#     If this is a tuple of ints, a standard deviation is performed over
#     multiple axes, instead of a single axis or all the axes as before.
# dtype : dtype, optional
#     Type to use in computing the standard deviation. For arrays of
#     integer type the default is float64, for arrays of float types it is
#     the same as the array type.
# out : ndarray, optional
#     Alternative output array in which to place the result. It must have
#     the same shape as the expected output but the type (of the calculated
#     values) will be cast if necessary.
# ddof : int, optional
#     Means Delta Degrees of Freedom.  The divisor used in calculations
#     is ``N - ddof``, where ``N`` represents the number of elements.
#     By default `ddof` is zero.
# keepdims : bool, optional
#     If this is set to True, the axes which are reduced are left
#     in the result as dimensions with size one. With this option,
#     the result will broadcast correctly against the input array.
#
#     If the default value is passed, then `keepdims` will not be
#     passed through to the `std` method of sub-classes of
#     `ndarray`, however any non-default value will be.  If the
#     sub-class' method does not implement `keepdims` any
#     exceptions will be raised.
#
# where : array_like of bool, optional
#     Elements to include in the standard deviation.
#     See `~numpy.ufunc.reduce` for details.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# standard_deviation : ndarray, see dtype parameter above.
#     If `out` is None, return a new array containing the standard deviation,
#     otherwise return a reference to the output array.
#
# See Also
# --------
# var, mean, nanmean, nanstd, nanvar
# :ref:`ufuncs-output-type`
#
# Notes
# -----
# The standard deviation is the square root of the average of the squared
# deviations from the mean, i.e., ``std = sqrt(mean(x))``, where
# ``x = abs(a - a.mean())**2``.
#
# The average squared deviation is typically calculated as ``x.sum() / N``,
# where ``N = len(x)``. If, however, `ddof` is specified, the divisor
# ``N - ddof`` is used instead. In standard statistical practice, ``ddof=1``
# provides an unbiased estimator of the variance of the infinite population.
# ``ddof=0`` provides a maximum likelihood estimate of the variance for
# normally distributed variables. The standard deviation computed in this
# function is the square root of the estimated variance, so even with
# ``ddof=1``, it will not be an unbiased estimate of the standard deviation
# per se.
#
# Note that, for complex numbers, `std` takes the absolute
# value before squaring, so that the result is always real and nonnegative.
#
# For floating-point input, the *std* is computed using the same
# precision the input has. Depending on the input data, this can cause
# the results to be inaccurate, especially for float32 (see example below).
# Specifying a higher-accuracy accumulator using the `dtype` keyword can
# alleviate this issue.
#
# Examples
# --------
# >>> a = np.array([[1, 2], [3, 4]])
# >>> np.std(a)
# 1.1180339887498949 # may vary
# >>> np.std(a, axis=0)
# array([1.,  1.])
# >>> np.std(a, axis=1)
# array([0.5,  0.5])
#
# In single precision, std() can be inaccurate:
#
# >>> a = np.zeros((2, 512*512), dtype=np.float32)
# >>> a[0, :] = 1.0
# >>> a[1, :] = 0.1
# >>> np.std(a)
# 0.45000005
#
# Computing the standard deviation in float64 is more accurate:
#
# >>> np.std(a, dtype=np.float64)
# 0.44999999925494177 # may vary
#
# Specifying a where argument:
#
# >>> a = np.array([[14, 8, 11, 10], [7, 9, 10, 11], [10, 15, 5, 10]])
# >>> np.std(a)
# 2.614064523559687 # may vary
# >>> np.std(a, where=[[True], [True], [False]])
# 2.0
#
# </code>
# <a href='#5'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.arange</u></summary>
# <blockquote>
# <code>
# arange([start,] stop[, step,], dtype=None, *, like=None)
#
# Return evenly spaced values within a given interval.
#
# Values are generated within the half-open interval ``[start, stop)``
# (in other words, the interval including `start` but excluding `stop`).
# For integer arguments the function is equivalent to the Python built-in
# `range` function, but returns an ndarray rather than a list.
#
# When using a non-integer step, such as 0.1, it is often better to use
# `numpy.linspace`. See the warnings section below for more information.
#
# Parameters
# ----------
# start : integer or real, optional
#     Start of interval.  The interval includes this value.  The default
#     start value is 0.
# stop : integer or real
#     End of interval.  The interval does not include this value, except
#     in some cases where `step` is not an integer and floating point
#     round-off affects the length of `out`.
# step : integer or real, optional
#     Spacing between values.  For any output `out`, this is the distance
#     between two adjacent values, ``out[i+1] - out[i]``.  The default
#     step size is 1.  If `step` is specified as a position argument,
#     `start` must also be given.
# dtype : dtype
#     The type of the output array.  If `dtype` is not given, infer the data
#     type from the other input arguments.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# arange : ndarray
#     Array of evenly spaced values.
#
#     For floating point arguments, the length of the result is
#     ``ceil((stop - start)/step)``.  Because of floating point overflow,
#     this rule may result in the last element of `out` being greater
#     than `stop`.
#
# Warnings
# --------
# The length of the output might not be numerically stable.
#
# Another stability issue is due to the internal implementation of
# `numpy.arange`.
# The actual step value used to populate the array is
# ``dtype(start + step) - dtype(start)`` and not `step`. Precision loss
# can occur here, due to casting or due to using floating points when
# `start` is much larger than `step`. This can lead to unexpected
# behaviour. For example::
#
#   >>> np.arange(0, 5, 0.5, dtype=int)
#   array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
#   >>> np.arange(-3, 3, 0.5, dtype=int)
#   array([-3, -2, -1,  0,  1,  2,  3,  4,  5,  6,  7,  8])
#
# In such cases, the use of `numpy.linspace` should be preferred.
#
# See Also
# --------
# numpy.linspace : Evenly spaced numbers with careful handling of endpoints.
# numpy.ogrid: Arrays of evenly spaced numbers in N-dimensions.
# numpy.mgrid: Grid-shaped arrays of evenly spaced numbers in N-dimensions.
#
# Examples
# --------
# >>> np.arange(3)
# array([0, 1, 2])
# >>> np.arange(3.0)
# array([ 0.,  1.,  2.])
# >>> np.arange(3,7)
# array([3, 4, 5, 6])
# >>> np.arange(3,7,2)
# array([3, 5])
#
# </code>
# <a href='#5'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.lib.shape_base.apply_along_axis</u></summary>
# <blockquote>
# <code>
# Apply a function to 1-D slices along the given axis.
#
# Execute `func1d(a, *args, **kwargs)` where `func1d` operates on 1-D arrays
# and `a` is a 1-D slice of `arr` along `axis`.
#
# This is equivalent to (but faster than) the following use of `ndindex` and
# `s_`, which sets each of ``ii``, ``jj``, and ``kk`` to a tuple of indices::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             f = func1d(arr[ii + s_[:,] + kk])
#             Nj = f.shape
#             for jj in ndindex(Nj):
#                 out[ii + jj + kk] = f[jj]
#
# Equivalently, eliminating the inner loop, this can be expressed as::
#
#     Ni, Nk = a.shape[:axis], a.shape[axis+1:]
#     for ii in ndindex(Ni):
#         for kk in ndindex(Nk):
#             out[ii + s_[...,] + kk] = func1d(arr[ii + s_[:,] + kk])
#
# Parameters
# ----------
# func1d : function (M,) -> (Nj...)
#     This function should accept 1-D arrays. It is applied to 1-D
#     slices of `arr` along the specified axis.
# axis : integer
#     Axis along which `arr` is sliced.
# arr : ndarray (Ni..., M, Nk...)
#     Input array.
# args : any
#     Additional arguments to `func1d`.
# kwargs : any
#     Additional named arguments to `func1d`.
#
#     .. versionadded:: 1.9.0
#
#
# Returns
# -------
# out : ndarray  (Ni..., Nj..., Nk...)
#     The output array. The shape of `out` is identical to the shape of
#     `arr`, except along the `axis` dimension. This axis is removed, and
#     replaced with new dimensions equal to the shape of the return value
#     of `func1d`. So if `func1d` returns a scalar `out` will have one
#     fewer dimensions than `arr`.
#
# See Also
# --------
# apply_over_axes : Apply a function repeatedly over multiple axes.
#
# Examples
# --------
# >>> def my_func(a):
# ...     """Average first and last element of a 1-D array"""
# ...     return (a[0] + a[-1]) * 0.5
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(my_func, 0, b)
# array([4., 5., 6.])
# >>> np.apply_along_axis(my_func, 1, b)
# array([2.,  5.,  8.])
#
# For a function that returns a 1D array, the number of dimensions in
# `outarr` is the same as `arr`.
#
# >>> b = np.array([[8,1,7], [4,3,9], [5,2,6]])
# >>> np.apply_along_axis(sorted, 1, b)
# array([[1, 7, 8],
#        [3, 4, 9],
#        [2, 5, 6]])
#
# For a function that returns a higher dimensional array, those dimensions
# are inserted in place of the `axis` dimension.
#
# >>> b = np.array([[1,2,3], [4,5,6], [7,8,9]])
# >>> np.apply_along_axis(np.diag, -1, b)
# array([[[1, 0, 0],
#         [0, 2, 0],
#         [0, 0, 3]],
#        [[4, 0, 0],
#         [0, 5, 0],
#         [0, 0, 6]],
#        [[7, 0, 0],
#         [0, 8, 0],
#         [0, 0, 9]]])
#
# </code>
# <a href='#5'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
# Code from: https://stackoverflow.com/questions/45028260/gaussian-to-uniform-distribution-conversion-has-errors-at-the-edges-of-uniform-d
def gaussian_estimation(vector):
    mu = np.mean(vector)
    sig = np.std(vector)
    return mu, sig

# Adjusts the data so it forms a gaussian with mean of 0 and std of 1
def gaussian_normalization(vector, char = None):
    if char is None:
        mu , sig = gaussian_estimation(vector)
    else:
        mu = char[0]
        sig = char[1]
    normalized = (vector-mu)/sig
    return normalized

# Taken from https://en.wikipedia.org/wiki/Normal_distribution#Cumulative_distribution_function
def CDF(x, max_i = 100):
    sum = x
    value = x
    for i in np.arange(max_i)+1:
        value = value*x*x/(2.0*i+1)
        sum = sum + value
    return 0.5 + (sum/np.sqrt(2*np.pi))*np.exp(-1*(x*x)/2)

def gaussian_to_uniform(vector, if_normal = False):
    if (if_normal == False):
        vector = gaussian_normalization(vector)
    uni = np.apply_along_axis(CDF, 0, vector)
    return uni



# %%
#for f in tqdm(features[2:]):
#     train_df.loc[:, f] = gaussian_to_uniform(train_df.loc[:, f].values)
#    
#     test_df.loc[:, f] = gaussian_to_uniform(test_df.loc[:, f].values)


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>7. Data Preparation | Feature Engineering | Library Loading</h1>  <a id='7'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>random</h2>
# <ul>
# <li>
# <details><summary><u>random.Random.uniform</u></summary>
# <blockquote>
# <code>
# Get a random number in the range [a, b) or [a, b] depending on rounding.
#
# </code>
# <a href='#7'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>random.Random.choice</u></summary>
# <blockquote>
# <code>
# Choose a random element from a non-empty sequence.
#
# </code>
# <a href='#7'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <h2 class='hglib'>numpy</h2>
# <ul>
# <li>
# <details><summary><u>numpy.random.mtrand.RandomState.shuffle</u></summary>
# <blockquote>
# <code>
# shuffle(x)
#
# Modify a sequence in-place by shuffling its contents.
#
# This function only shuffles the array along the first axis of a
# multi-dimensional array. The order of sub-arrays is changed but
# their contents remains the same.
#
# .. note::
#     New code should use the ``shuffle`` method of a ``default_rng()``
#     instance instead; please see the :ref:`random-quick-start`.
#
# Parameters
# ----------
# x : ndarray or MutableSequence
#     The array, list or mutable sequence to be shuffled.
#
# Returns
# -------
# None
#
# See Also
# --------
# Generator.shuffle: which should be used for new code.
#
# Examples
# --------
# >>> arr = np.arange(10)
# >>> np.random.shuffle(arr)
# >>> arr
# [1 7 5 2 9 4 3 6 0 8] # random
#
# Multi-dimensional arrays are only shuffled along the first axis:
#
# >>> arr = np.arange(9).reshape((3, 3))
# >>> np.random.shuffle(arr)
# >>> arr
# array([[3, 4, 5], # random
#        [6, 7, 8],
#        [0, 1, 2]])
#
# </code>
# <a href='#7'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.array</u></summary>
# <blockquote>
# <code>
# array(object, dtype=None, *, copy=True, order='K', subok=False, ndmin=0,
#       like=None)
#
# Create an array.
#
# Parameters
# ----------
# object : array_like
#     An array, any object exposing the array interface, an object whose
#     __array__ method returns an array, or any (nested) sequence.
#     If object is a scalar, a 0-dimensional array containing object is
#     returned.
# dtype : data-type, optional
#     The desired data-type for the array.  If not given, then the type will
#     be determined as the minimum type required to hold the objects in the
#     sequence.
# copy : bool, optional
#     If true (default), then the object is copied.  Otherwise, a copy will
#     only be made if __array__ returns a copy, if obj is a nested sequence,
#     or if a copy is needed to satisfy any of the other requirements
#     (`dtype`, `order`, etc.).
# order : {'K', 'A', 'C', 'F'}, optional
#     Specify the memory layout of the array. If object is not an array, the
#     newly created array will be in C order (row major) unless 'F' is
#     specified, in which case it will be in Fortran order (column major).
#     If object is an array the following holds.
#
#     ===== ========= ===================================================
#     order  no copy                     copy=True
#     ===== ========= ===================================================
#     'K'   unchanged F & C order preserved, otherwise most similar order
#     'A'   unchanged F order if input is F and not C, otherwise C order
#     'C'   C order   C order
#     'F'   F order   F order
#     ===== ========= ===================================================
#
#     When ``copy=False`` and a copy is made for other reasons, the result is
#     the same as if ``copy=True``, with some exceptions for 'A', see the
#     Notes section. The default order is 'K'.
# subok : bool, optional
#     If True, then sub-classes will be passed-through, otherwise
#     the returned array will be forced to be a base-class array (default).
# ndmin : int, optional
#     Specifies the minimum number of dimensions that the resulting
#     array should have.  Ones will be pre-pended to the shape as
#     needed to meet this requirement.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     An array object satisfying the specified requirements.
#
# See Also
# --------
# empty_like : Return an empty array with shape and type of input.
# ones_like : Return an array of ones with shape and type of input.
# zeros_like : Return an array of zeros with shape and type of input.
# full_like : Return a new array with shape of input filled with value.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# zeros : Return a new array setting values to zero.
# full : Return a new array of given shape filled with value.
#
#
# Notes
# -----
# When order is 'A' and `object` is an array in neither 'C' nor 'F' order,
# and a copy is forced by a change in dtype, then the order of the result is
# not necessarily 'C' as expected. This is likely a bug.
#
# Examples
# --------
# >>> np.array([1, 2, 3])
# array([1, 2, 3])
#
# Upcasting:
#
# >>> np.array([1, 2, 3.0])
# array([ 1.,  2.,  3.])
#
# More than one dimension:
#
# >>> np.array([[1, 2], [3, 4]])
# array([[1, 2],
#        [3, 4]])
#
# Minimum dimensions 2:
#
# >>> np.array([1, 2, 3], ndmin=2)
# array([[1, 2, 3]])
#
# Type provided:
#
# >>> np.array([1, 2, 3], dtype=complex)
# array([ 1.+0.j,  2.+0.j,  3.+0.j])
#
# Data-type consisting of more than one element:
#
# >>> x = np.array([(1,2),(3,4)],dtype=[('a','<i4'),('b','<i4')])
# >>> x['a']
# array([1, 3])
#
# Creating an array from sub-classes:
#
# >>> np.array(np.mat('1 2; 3 4'))
# array([[1, 2],
#        [3, 4]])
#
# >>> np.array(np.mat('1 2; 3 4'), subok=True)
# matrix([[1, 2],
#         [3, 4]])
#
# </code>
# <a href='#7'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>numpy.zeros</u></summary>
# <blockquote>
# <code>
# zeros(shape, dtype=float, order='C', *, like=None)
#
# Return a new array of given shape and type, filled with zeros.
#
# Parameters
# ----------
# shape : int or tuple of ints
#     Shape of the new array, e.g., ``(2, 3)`` or ``2``.
# dtype : data-type, optional
#     The desired data-type for the array, e.g., `numpy.int8`.  Default is
#     `numpy.float64`.
# order : {'C', 'F'}, optional, default: 'C'
#     Whether to store multi-dimensional data in row-major
#     (C-style) or column-major (Fortran-style) order in
#     memory.
# like : array_like
#     Reference object to allow the creation of arrays which are not
#     NumPy arrays. If an array-like passed in as ``like`` supports
#     the ``__array_function__`` protocol, the result will be defined
#     by it. In this case, it ensures the creation of an array object
#     compatible with that passed in via this argument.
#
#     .. versionadded:: 1.20.0
#
# Returns
# -------
# out : ndarray
#     Array of zeros with the given shape, dtype, and order.
#
# See Also
# --------
# zeros_like : Return an array of zeros with shape and type of input.
# empty : Return a new uninitialized array.
# ones : Return a new array setting values to one.
# full : Return a new array of given shape filled with value.
#
# Examples
# --------
# >>> np.zeros(5)
# array([ 0.,  0.,  0.,  0.,  0.])
#
# >>> np.zeros((5,), dtype=int)
# array([0, 0, 0, 0, 0])
#
# >>> np.zeros((2, 1))
# array([[ 0.],
#        [ 0.]])
#
# >>> s = (2,2)
# >>> np.zeros(s)
# array([[ 0.,  0.],
#        [ 0.,  0.]])
#
# >>> np.zeros((2,), dtype=[('x', 'i4'), ('y', 'i4')]) # custom dtype
# array([(0, 0), (0, 0)],
#       dtype=[('x', '<i4'), ('y', '<i4')])
#
# </code>
# <a href='#7'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
from keras.utils import Sequence  
from keras.callbacks import Callback
import random

class DataGenerator(Sequence):
    def __init__(self, x, y, batch_size=256):
        self.x = x
        self.y = y
        self.batch_size = batch_size
        
        self.pos_x = x[y==1]
        self.neg_x = x[y==0]
        
        self.pos_idx = list(range(len(self.pos_x)))
        self.neg_idx = list(range(len(self.neg_x)))
        
    def __len__(self):
        return int(len(self.y)/self.batch_size)
    
    def __getitem__(self, indx):
        poss_b, neg_b, anch_b = [], [], []
        
        for _ in range(self.batch_size):
            if random.uniform(0, 1) > 0.5:
                p_i = random.choice(self.pos_idx)
                n_i = random.choice(self.neg_idx)
                a_i = random.choice(self.pos_idx)
                    
                p_x = self.pos_x[p_i]
                n_x = self.neg_x[n_i]
                a_x = self.pos_x[a_i]
            else:
                p_i = random.choice(self.neg_idx)
                n_i = random.choice(self.pos_idx)
                a_i = random.choice(self.neg_idx)
                
                p_x = self.neg_x[p_i]
                n_x = self.pos_x[n_i]
                a_x = self.neg_x[a_i]
            # augmentation
            if random.uniform(0, 1) > 0.5:
                ids = [0, 1]
                np.random.shuffle(ids)
                _x = np.array([p_x, a_x])
                _x1 = np.array([p_x, a_x])
                for c in range(_x.shape[1]):
                    np.random.shuffle(ids)
                    _x1[:,c] = _x[ids][:,c]
                p_x, a_x = _x1[0], _x[1]    
            
            poss_b.append(p_x)
            neg_b.append(n_x)
            anch_b.append(a_x)
        return [np.array(poss_b), np.array(neg_b), np.array(anch_b)], np.zeros((self.batch_size, 2))



# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>8. Data Preparation | Model Building and Training</h1>  <a id='8'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.backend.set_value</u></summary>
# <blockquote>
# <code>
# Sets the value of a variable, from a Numpy array.
#
# `backend.set_value` is the complement of `backend.get_value`, and provides
# a generic interface for assigning to variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: Variable to set to a new value.
#     value: Value to set the tensor to, as a Numpy array
#         (of the same shape).
#
# </code>
# <a href='#8'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.backend.get_value</u></summary>
# <blockquote>
# <code>
# Returns the value of a variable.
#
# `backend.get_value` is the complement of `backend.set_value`, and provides
# a generic interface for reading from variables while abstracting away the
# differences between TensorFlow 1.x and 2.x semantics.
#
# >>> K = tf.keras.backend  # Common keras convention
# >>> v = K.variable(1.)
#
# >>> # reassign
# >>> K.set_value(v, 2.)
# >>> print(K.get_value(v))
# 2.0
#
# >>> # increment
# >>> K.set_value(v, K.get_value(v) + 1)
# >>> print(K.get_value(v))
# 3.0
#
# Variable semantics in TensorFlow 2 are eager execution friendly. The above
# code is roughly equivalent to:
#
# >>> v = tf.Variable(1.)
#
# >>> v.assign(2.)
# >>> print(v.numpy())
# 2.0
#
# >>> v.assign_add(1.)
# >>> print(v.numpy())
# 3.0
#
# Args:
#     x: input variable.
#
# Returns:
#     A Numpy array.
#
# </code>
# <a href='#8'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
class CyclicLR(Callback):
    """This callback implements a cyclical learning rate policy (CLR).
    The method cycles the learning rate between two boundaries with
    some constant frequency, as detailed in this paper (https://arxiv.org/abs/1506.01186).
    The amplitude of the cycle can be scaled on a per-iteration or 
    per-cycle basis.
    This class has three built-in policies, as put forth in the paper.
    "triangular":
        A basic triangular cycle w/ no amplitude scaling.
    "triangular2":
        A basic triangular cycle that scales initial amplitude by half each cycle.
    "exp_range":
        A cycle that scales initial amplitude by gamma**(cycle iterations) at each 
        cycle iteration.
    For more detail, please see paper.
    
    # Example
        ```python
            clr = CyclicLR(base_lr=0.001, max_lr=0.006,
                                step_size=2000., mode='triangular')
            model.fit(X_train, Y_train, callbacks=[clr])
        ```
    
    Class also supports custom scaling functions:
        ```python
            clr_fn = lambda x: 0.5*(1+np.sin(x*np.pi/2.))
            clr = CyclicLR(base_lr=0.001, max_lr=0.006,
                                step_size=2000., scale_fn=clr_fn,
                                scale_mode='cycle')
            model.fit(X_train, Y_train, callbacks=[clr])
        ```    
    # Arguments
        base_lr: initial learning rate which is the
            lower boundary in the cycle.
        max_lr: upper boundary in the cycle. Functionally,
            it defines the cycle amplitude (max_lr - base_lr).
            The lr at any cycle is the sum of base_lr
            and some scaling of the amplitude; therefore 
            max_lr may not actually be reached depending on
            scaling function.
        step_size: number of training iterations per
            half cycle. Authors suggest setting step_size
            2-8 x training iterations in epoch.
        mode: one of {triangular, triangular2, exp_range}.
            Default 'triangular'.
            Values correspond to policies detailed above.
            If scale_fn is not None, this argument is ignored.
        gamma: constant in 'exp_range' scaling function:
            gamma**(cycle iterations)
        scale_fn: Custom scaling policy defined by a single
            argument lambda function, where 
            0 <= scale_fn(x) <= 1 for all x >= 0.
            mode paramater is ignored 
        scale_mode: {'cycle', 'iterations'}.
            Defines whether scale_fn is evaluated on 
            cycle number or cycle iterations (training
            iterations since start of cycle). Default is 'cycle'.
    """

    def __init__(self, base_lr=0.001, max_lr=0.006, step_size=2000., mode='triangular',
                 gamma=1., scale_fn=None, scale_mode='cycle', decay=0.1):
        super(CyclicLR, self).__init__()

        self.base_lr = base_lr
        self.max_lr = max_lr
        self.step_size = step_size
        self.mode = mode
        self.gamma = gamma
        if scale_fn == None:
            if self.mode == 'triangular':
                self.scale_fn = lambda x: 1.
                self.scale_mode = 'cycle'
            elif self.mode == 'triangular2':
                self.scale_fn = lambda x: 1/(2.**(x-1))
                self.scale_mode = 'cycle'
            elif self.mode == 'exp_range':
                self.scale_fn = lambda x: gamma**(x)
                self.scale_mode = 'iterations'
        else:
            self.scale_fn = scale_fn
            self.scale_mode = scale_mode
        self.clr_iterations = 0.
        self.trn_iterations = 0.
        self.history = {}
        self.decay = decay

        self._reset()

    def _reset(self, new_base_lr=None, new_max_lr=None,
               new_step_size=None):
        """Resets cycle iterations.
        Optional boundary/step size adjustment.
        """
        if new_base_lr != None:
            self.base_lr = new_base_lr
        if new_max_lr != None:
            self.max_lr = new_max_lr
        if new_step_size != None:
            self.step_size = new_step_size
        self.clr_iterations = 0.
        
    def clr(self):
        cycle = np.floor(1+self.clr_iterations/(2*self.step_size))
        x = np.abs(self.clr_iterations/self.step_size - 2*cycle + 1)
        if self.scale_mode == 'cycle':
            return self.base_lr + (self.max_lr-self.base_lr)*np.maximum(0, (1-x))*self.scale_fn(cycle)
        else:
            return self.base_lr + (self.max_lr-self.base_lr)*np.maximum(0, (1-x))*self.scale_fn(self.clr_iterations)
        
    def on_train_begin(self, logs={}):
        logs = logs or {}

        if self.clr_iterations == 0:
            K.set_value(self.model.optimizer.lr, self.base_lr)
        else:
            K.set_value(self.model.optimizer.lr, self.clr())        
            
    def on_batch_end(self, epoch, logs=None):
        
        logs = logs or {}
        self.trn_iterations += 1
        self.clr_iterations += 1

        self.history.setdefault('lr', []).append(K.get_value(self.model.optimizer.lr))
        self.history.setdefault('iterations', []).append(self.trn_iterations)

        for k, v in logs.items():
            self.history.setdefault(k, []).append(v)
        
        K.set_value(self.model.optimizer.lr, self.clr())
        
        
    def on_epoch_end(self, epoch, logs=None):
        self.base_lr = self.base_lr*np.exp(-epoch*self.decay)
        self.max_lr = self.max_lr*np.exp(-epoch*self.decay)




# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>9. Library Loading</h1>  <a id='9'></a><small><a href='#top_phases'>back to top</a></small>

# %%
from keras import Model
from keras.layers import Dense, BatchNormalization, Activation, Dropout, Input, Add, AlphaDropout, GaussianNoise, GaussianDropout, Conv1D, GlobalMaxPool1D, Concatenate, LeakyReLU
from keras.optimizers import Nadam


# %%
OUTPUT_SIZE = 32


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>11. Library Loading | Model Building and Training</h1>  <a id='11'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.backend.sigmoid</u></summary>
# <blockquote>
# <code>
# Element-wise sigmoid.
#
# Args:
#     x: A tensor or variable.
#
# Returns:
#     A tensor.
#
# </code>
# <a href='#11'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
import keras.backend as K
beta=OUTPUT_SIZE
epsilon=1e-4
def triplet_loss_distance(y_true, y_pred):
    y_pred = K.sigmoid(y_pred)
    anchor = y_pred[..., :OUTPUT_SIZE]
    positive = y_pred[..., OUTPUT_SIZE:2*OUTPUT_SIZE]
    negative = y_pred[..., 2*OUTPUT_SIZE:]
    
    # distance between the anchor and the positive
    pos_dist = K.tf.reduce_sum(K.tf.square(K.tf.subtract(anchor,positive)),1)
    # distance between the anchor and the negative
    neg_dist = K.tf.reduce_sum(K.tf.square(K.tf.subtract(anchor,negative)),1)
    
    #Non Linear Values  
    
    # -ln(-x/N+1)
    pos_dist = -K.tf.log(-K.tf.divide((pos_dist),beta)+1+epsilon)
    neg_dist = -K.tf.log(-K.tf.divide((OUTPUT_SIZE-neg_dist),beta)+1+epsilon)
    
    return pos_dist + neg_dist



# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>12. Model Building and Training</h1>  <a id='12'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u></summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u></summary>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u></summary>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u></summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u></summary>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u></summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#12'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
def get_model(shape=(200,)):
    inp = Input(shape)
    
    x = GaussianNoise(0.01)(inp)
    x = Dense(128, kernel_initializer='glorot_normal')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    
    x = Dense(128, kernel_initializer='glorot_normal')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    
    x = Dense(64, kernel_initializer='glorot_normal')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    
    x = Dense(64, kernel_initializer='glorot_normal')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    
    x = Dense(32)(x)
    
    model = Model(inp, x)
    return model



# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>13. Model Building and Training</h1>  <a id='13'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.layers.core.dense.Dense</u></summary>
# <blockquote>
# <code>
# Just your regular densely-connected NN layer.
#
# `Dense` implements the operation:
# `output = activation(dot(input, kernel) + bias)`
# where `activation` is the element-wise activation function
# passed as the `activation` argument, `kernel` is a weights matrix
# created by the layer, and `bias` is a bias vector created by the layer
# (only applicable if `use_bias` is `True`). These are all attributes of
# `Dense`.
#
# Note: If the input to the layer has a rank greater than 2, then `Dense`
# computes the dot product between the `inputs` and the `kernel` along the
# last axis of the `inputs` and axis 0 of the `kernel` (using `tf.tensordot`).
# For example, if input has dimensions `(batch_size, d0, d1)`,
# then we create a `kernel` with shape `(d1, units)`, and the `kernel` operates
# along axis 2 of the `input`, on every sub-tensor of shape `(1, 1, d1)`
# (there are `batch_size * d0` such sub-tensors).
# The output in this case will have shape `(batch_size, d0, units)`.
#
# Besides, layer attributes cannot be modified after the layer has been called
# once (except the `trainable` attribute).
# When a popular kwarg `input_shape` is passed, then keras will create
# an input layer to insert before the current layer. This can be treated
# equivalent to explicitly defining an `InputLayer`.
#
# Example:
#
# >>> # Create a `Sequential` model and add a Dense layer as the first layer.
# >>> model = tf.keras.models.Sequential()
# >>> model.add(tf.keras.Input(shape=(16,)))
# >>> model.add(tf.keras.layers.Dense(32, activation='relu'))
# >>> # Now the model will take as input arrays of shape (None, 16)
# >>> # and output arrays of shape (None, 32).
# >>> # Note that after the first layer, you don't need to specify
# >>> # the size of the input anymore:
# >>> model.add(tf.keras.layers.Dense(32))
# >>> model.output_shape
# (None, 32)
#
# Args:
#   units: Positive integer, dimensionality of the output space.
#   activation: Activation function to use.
#     If you don't specify anything, no activation is applied
#     (ie. "linear" activation: `a(x) = x`).
#   use_bias: Boolean, whether the layer uses a bias vector.
#   kernel_initializer: Initializer for the `kernel` weights matrix.
#   bias_initializer: Initializer for the bias vector.
#   kernel_regularizer: Regularizer function applied to
#     the `kernel` weights matrix.
#   bias_regularizer: Regularizer function applied to the bias vector.
#   activity_regularizer: Regularizer function applied to
#     the output of the layer (its "activation").
#   kernel_constraint: Constraint function applied to
#     the `kernel` weights matrix.
#   bias_constraint: Constraint function applied to the bias vector.
#
# Input shape:
#   N-D tensor with shape: `(batch_size, ..., input_dim)`.
#   The most common situation would be
#   a 2D input with shape `(batch_size, input_dim)`.
#
# Output shape:
#   N-D tensor with shape: `(batch_size, ..., units)`.
#   For instance, for a 2D input with shape `(batch_size, input_dim)`,
#   the output would have shape `(batch_size, units)`.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.normalization.batch_normalization.BatchNormalization</u></summary>
# <blockquote>
# <code>
# Layer that normalizes its inputs.
#
# Batch normalization applies a transformation that maintains the mean output
# close to 0 and the output standard deviation close to 1.
#
# Importantly, batch normalization works differently during training and
# during inference.
#
# **During training** (i.e. when using `fit()` or when calling the layer/model
# with the argument `training=True`), the layer normalizes its output using
# the mean and standard deviation of the current batch of inputs. That is to
# say, for each channel being normalized, the layer returns
# `gamma * (batch - mean(batch)) / sqrt(var(batch) + epsilon) + beta`, where:
#
# - `epsilon` is small constant (configurable as part of the constructor
# arguments)
# - `gamma` is a learned scaling factor (initialized as 1), which
# can be disabled by passing `scale=False` to the constructor.
# - `beta` is a learned offset factor (initialized as 0), which
# can be disabled by passing `center=False` to the constructor.
#
# **During inference** (i.e. when using `evaluate()` or `predict()` or when
# calling the layer/model with the argument `training=False` (which is the
# default), the layer normalizes its output using a moving average of the
# mean and standard deviation of the batches it has seen during training. That
# is to say, it returns
# `gamma * (batch - self.moving_mean) / sqrt(self.moving_var + epsilon) + beta`.
#
# `self.moving_mean` and `self.moving_var` are non-trainable variables that
# are updated each time the layer in called in training mode, as such:
#
# - `moving_mean = moving_mean * momentum + mean(batch) * (1 - momentum)`
# - `moving_var = moving_var * momentum + var(batch) * (1 - momentum)`
#
# As such, the layer will only normalize its inputs during inference
# *after having been trained on data that has similar statistics as the
# inference data*.
#
# Args:
#   axis: Integer, the axis that should be normalized (typically the features
#     axis). For instance, after a `Conv2D` layer with
#     `data_format="channels_first"`, set `axis=1` in `BatchNormalization`.
#   momentum: Momentum for the moving average.
#   epsilon: Small float added to variance to avoid dividing by zero.
#   center: If True, add offset of `beta` to normalized tensor. If False, `beta`
#     is ignored.
#   scale: If True, multiply by `gamma`. If False, `gamma` is not used. When the
#     next layer is linear (also e.g. `nn.relu`), this can be disabled since the
#     scaling will be done by the next layer.
#   beta_initializer: Initializer for the beta weight.
#   gamma_initializer: Initializer for the gamma weight.
#   moving_mean_initializer: Initializer for the moving mean.
#   moving_variance_initializer: Initializer for the moving variance.
#   beta_regularizer: Optional regularizer for the beta weight.
#   gamma_regularizer: Optional regularizer for the gamma weight.
#   beta_constraint: Optional constraint for the beta weight.
#   gamma_constraint: Optional constraint for the gamma weight.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode or in inference mode.
#     - `training=True`: The layer will normalize its inputs using the mean and
#       variance of the current batch of inputs.
#     - `training=False`: The layer will normalize its inputs using the mean and
#       variance of its moving statistics, learned during training.
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape` (tuple of
#   integers, does not include the samples axis) when using this layer as the
#   first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# Reference:
#   - [Ioffe and Szegedy, 2015](https://arxiv.org/abs/1502.03167).
#
# **About setting `layer.trainable = False` on a `BatchNormalization` layer:**
#
# The meaning of setting `layer.trainable = False` is to freeze the layer,
# i.e. its internal state will not change during training:
# its trainable weights will not be updated
# during `fit()` or `train_on_batch()`, and its state updates will not be run.
#
# Usually, this does not necessarily mean that the layer is run in inference
# mode (which is normally controlled by the `training` argument that can
# be passed when calling a layer). "Frozen state" and "inference mode"
# are two separate concepts.
#
# However, in the case of the `BatchNormalization` layer, **setting
# `trainable = False` on the layer means that the layer will be
# subsequently run in inference mode** (meaning that it will use
# the moving mean and the moving variance to normalize the current batch,
# rather than using the mean and variance of the current batch).
#
# This behavior has been introduced in TensorFlow 2.0, in order
# to enable `layer.trainable = False` to produce the most commonly
# expected behavior in the convnet fine-tuning use case.
#
# Note that:
#   - Setting `trainable` on an model containing other layers will
#     recursively set the `trainable` value of all inner layers.
#   - If the value of the `trainable`
#     attribute is changed after calling `compile()` on a model,
#     the new value doesn't take effect for this model
#     until `compile()` is called again.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u></summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.core.activation.Activation</u></summary>
# <blockquote>
# <code>
# Applies an activation function to an output.
#
# Args:
#   activation: Activation function, such as `tf.nn.relu`, or string name of
#     built-in activation function, such as "relu".
#
# Usage:
#
# >>> layer = tf.keras.layers.Activation('relu')
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
# >>> layer = tf.keras.layers.Activation(tf.nn.relu)
# >>> output = layer([-3.0, -1.0, 0.0, 2.0])
# >>> list(output.numpy())
# [0.0, 0.0, 0.0, 2.0]
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the batch axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u></summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.noise.GaussianNoise</u></summary>
# <blockquote>
# <code>
# Apply additive zero-centered Gaussian noise.
#
# This is useful to mitigate overfitting
# (you could see it as a form of random data augmentation).
# Gaussian Noise (GS) is a natural choice as corruption process
# for real valued inputs.
#
# As it is a regularization layer, it is only active at training time.
#
# Args:
#   stddev: Float, standard deviation of the noise distribution.
#   seed: Integer, optional random seed to enable deterministic behavior.
#
# Call arguments:
#   inputs: Input tensor (of any rank).
#   training: Python boolean indicating whether the layer should behave in
#     training mode (adding noise) or in inference mode (doing nothing).
#
# Input shape:
#   Arbitrary. Use the keyword argument `input_shape`
#   (tuple of integers, does not include the samples axis)
#   when using this layer as the first layer in a model.
#
# Output shape:
#   Same shape as input.
#
# </code>
# <a href='#13'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
emb_model = get_model()
    


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>14. Model Building and Training</h1>  <a id='14'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.engine.input_layer.Input</u></summary>
# <blockquote>
# <code>
# `Input()` is used to instantiate a Keras tensor.
#
# A Keras tensor is a symbolic tensor-like object,
# which we augment with certain attributes that allow us to build a Keras model
# just by knowing the inputs and outputs of the model.
#
# For instance, if `a`, `b` and `c` are Keras tensors,
# it becomes possible to do:
# `model = Model(input=[a, b], output=c)`
#
# Args:
#     shape: A shape tuple (integers), not including the batch size.
#         For instance, `shape=(32,)` indicates that the expected input
#         will be batches of 32-dimensional vectors. Elements of this tuple
#         can be None; 'None' elements represent dimensions where the shape is
#         not known.
#     batch_size: optional static batch size (integer).
#     name: An optional name string for the layer.
#         Should be unique in a model (do not reuse the same name twice).
#         It will be autogenerated if it isn't provided.
#     dtype: The data type expected by the input, as a string
#         (`float32`, `float64`, `int32`...)
#     sparse: A boolean specifying whether the placeholder to be created is
#         sparse. Only one of 'ragged' and 'sparse' can be True. Note that,
#         if `sparse` is False, sparse tensors can still be passed into the
#         input - they will be densified with a default value of 0.
#     tensor: Optional existing tensor to wrap into the `Input` layer.
#         If set, the layer will use the `tf.TypeSpec` of this tensor rather
#         than creating a new placeholder tensor.
#     ragged: A boolean specifying whether the placeholder to be created is
#         ragged. Only one of 'ragged' and 'sparse' can be True. In this case,
#         values of 'None' in the 'shape' argument represent ragged dimensions.
#         For more information about RaggedTensors, see
#         [this guide](https://www.tensorflow.org/guide/ragged_tensors).
#     type_spec: A `tf.TypeSpec` object to create the input placeholder from.
#         When provided, all other args except name must be None.
#     **kwargs: deprecated arguments support. Supports `batch_shape` and
#         `batch_input_shape`.
#
# Returns:
#   A `tensor`.
#
# Example:
#
# ```python
# this is a logistic regression in Keras
# x = Input(shape=(32,))
# y = Dense(16, activation='softmax')(x)
# model = Model(x, y)
# ```
#
# Note that even if eager execution is enabled,
# `Input` produces a symbolic tensor-like object (i.e. a placeholder).
# This symbolic tensor-like object can be used with lower-level
# TensorFlow ops that take tensors as inputs, as such:
#
# ```python
# x = Input(shape=(32,))
# y = tf.square(x)  # This op will be treated like a layer
# model = Model(x, y)
# ```
#
# (This behavior does not work for higher-order TensorFlow APIs such as
# control flow and being directly watched by a `tf.GradientTape`).
#
# However, the resulting model will not track any variables that were
# used as inputs to TensorFlow ops. All variable usages must happen within
# Keras layers to make sure they will be tracked by the model's weights.
#
# The Keras Input can also create a placeholder from an arbitrary `tf.TypeSpec`,
# e.g:
#
# ```python
# x = Input(type_spec=tf.RaggedTensorSpec(shape=[None, None],
#                                         dtype=tf.float32, ragged_rank=1))
# y = x.values
# model = Model(x, y)
# ```
# When passing an arbitrary `tf.TypeSpec`, it must represent the signature of an
# entire batch instead of just one example.
#
# Raises:
#   ValueError: If both `sparse` and `ragged` are provided.
#   ValueError: If both `shape` and (`batch_input_shape` or `batch_shape`) are
#     provided.
#   ValueError: If `shape`, `tensor` and `type_spec` are None.
#   ValueError: If arguments besides `type_spec` are non-None while `type_spec`
#               is passed.
#   ValueError: if any unrecognized parameters are provided.
#
# </code>
# <a href='#14'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model</u></summary>
# <blockquote>
# <code>
# `Model` groups layers into an object with training and inference features.
#
# Args:
#     inputs: The input(s) of the model: a `keras.Input` object or list of
#         `keras.Input` objects.
#     outputs: The output(s) of the model. See Functional API example below.
#     name: String, the name of the model.
#
# There are two ways to instantiate a `Model`:
#
# 1 - With the "Functional API", where you start from `Input`,
# you chain layer calls to specify the model's forward pass,
# and finally you create your model from inputs and outputs:
#
# ```python
# import tensorflow as tf
#
# inputs = tf.keras.Input(shape=(3,))
# x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
# outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
# model = tf.keras.Model(inputs=inputs, outputs=outputs)
# ```
#
# Note: Only dicts, lists, and tuples of input tensors are supported. Nested
# inputs are not supported (e.g. lists of list or dicts of dict).
#
# A new Functional API model can also be created by using the
# intermediate tensors. This enables you to quickly extract sub-components
# of the model.
#
# Example:
#
# ```python
# inputs = keras.Input(shape=(None, None, 3))
# processed = keras.layers.RandomCrop(width=32, height=32)(inputs)
# conv = keras.layers.Conv2D(filters=2, kernel_size=3)(processed)
# pooling = keras.layers.GlobalAveragePooling2D()(conv)
# feature = keras.layers.Dense(10)(pooling)
#
# full_model = keras.Model(inputs, feature)
# backbone = keras.Model(processed, conv)
# activations = keras.Model(conv, feature)
# ```
#
# Note that the `backbone` and `activations` models are not
# created with `keras.Input` objects, but with the tensors that are originated
# from `keras.Inputs` objects. Under the hood, the layers and weights will
# be shared across these models, so that user can train the `full_model`, and
# use `backbone` or `activations` to do feature extraction.
# The inputs and outputs of the model can be nested structures of tensors as
# well, and the created models are standard Functional API models that support
# all the existing APIs.
#
# 2 - By subclassing the `Model` class: in that case, you should define your
# layers in `__init__()` and you should implement the model's forward pass
# in `call()`.
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#
#   def call(self, inputs):
#     x = self.dense1(inputs)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# If you subclass `Model`, you can optionally have
# a `training` argument (boolean) in `call()`, which you can use to specify
# a different behavior in training and inference:
#
# ```python
# import tensorflow as tf
#
# class MyModel(tf.keras.Model):
#
#   def __init__(self):
#     super().__init__()
#     self.dense1 = tf.keras.layers.Dense(4, activation=tf.nn.relu)
#     self.dense2 = tf.keras.layers.Dense(5, activation=tf.nn.softmax)
#     self.dropout = tf.keras.layers.Dropout(0.5)
#
#   def call(self, inputs, training=False):
#     x = self.dense1(inputs)
#     if training:
#       x = self.dropout(x, training=training)
#     return self.dense2(x)
#
# model = MyModel()
# ```
#
# Once the model is created, you can config the model with losses and metrics
# with `model.compile()`, train the model with `model.fit()`, or use the model
# to do prediction with `model.predict()`.
#
# </code>
# <a href='#14'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.layers.merge.Concatenate</u></summary>
# <blockquote>
# <code>
# Layer that concatenates a list of inputs.
#
# It takes as input a list of tensors, all of the same shape except
# for the concatenation axis, and returns a single tensor that is the
# concatenation of all inputs.
#
# >>> x = np.arange(20).reshape(2, 2, 5)
# >>> print(x)
# [[[ 0  1  2  3  4]
#   [ 5  6  7  8  9]]
#  [[10 11 12 13 14]
#   [15 16 17 18 19]]]
# >>> y = np.arange(20, 30).reshape(2, 1, 5)
# >>> print(y)
# [[[20 21 22 23 24]]
#  [[25 26 27 28 29]]]
# >>> tf.keras.layers.Concatenate(axis=1)([x, y])
# <tf.Tensor: shape=(2, 3, 5), dtype=int64, numpy=
# array([[[ 0,  1,  2,  3,  4],
#         [ 5,  6,  7,  8,  9],
#         [20, 21, 22, 23, 24]],
#        [[10, 11, 12, 13, 14],
#         [15, 16, 17, 18, 19],
#         [25, 26, 27, 28, 29]]])>
#
# >>> x1 = tf.keras.layers.Dense(8)(np.arange(10).reshape(5, 2))
# >>> x2 = tf.keras.layers.Dense(8)(np.arange(10, 20).reshape(5, 2))
# >>> concatted = tf.keras.layers.Concatenate()([x1, x2])
# >>> concatted.shape
# TensorShape([5, 16])
#
# </code>
# <a href='#14'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.optimizer_v2.nadam.Nadam</u></summary>
# <blockquote>
# <code>
# Optimizer that implements the NAdam algorithm.
# Much like Adam is essentially RMSprop with momentum, Nadam is Adam with
# Nesterov momentum.
#
# Args:
#   learning_rate: A Tensor or a floating point value.  The learning rate.
#   beta_1: A float value or a constant float tensor. The exponential decay
#     rate for the 1st moment estimates.
#   beta_2: A float value or a constant float tensor. The exponential decay
#     rate for the exponentially weighted infinity norm.
#   epsilon: A small constant for numerical stability.
#   name: Optional name for the operations created when applying gradients.
#     Defaults to `"Nadam"`.
#   **kwargs: Keyword arguments. Allowed to be one of
#     `"clipnorm"` or `"clipvalue"`.
#     `"clipnorm"` (float) clips gradients by norm; `"clipvalue"` (float) clips
#     gradients by value.
#
# Usage Example:
#   >>> opt = tf.keras.optimizers.Nadam(learning_rate=0.2)
#   >>> var1 = tf.Variable(10.0)
#   >>> loss = lambda: (var1 ** 2) / 2.0
#   >>> step_count = opt.minimize(loss, [var1]).numpy()
#   >>> "{:.1f}".format(var1.numpy())
#   9.8
#
# Reference:
#   - [Dozat, 2015](http://cs229.stanford.edu/proj2015/054_report.pdf).
#
# </code>
# <a href='#14'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>keras.engine.training.Model.compile</u></summary>
# <blockquote>
# <code>
# Configures the model for training.
#
# Example:
#
# ```python
# model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
#               loss=tf.keras.losses.BinaryCrossentropy(),
#               metrics=[tf.keras.metrics.BinaryAccuracy(),
#                        tf.keras.metrics.FalseNegatives()])
# ```
#
# Args:
#     optimizer: String (name of optimizer) or optimizer instance. See
#       `tf.keras.optimizers`.
#     loss: Loss function. Maybe be a string (name of loss function), or
#       a `tf.keras.losses.Loss` instance. See `tf.keras.losses`. A loss
#       function is any callable with the signature `loss = fn(y_true,
#       y_pred)`, where `y_true` are the ground truth values, and
#       `y_pred` are the model's predictions.
#       `y_true` should have shape
#       `(batch_size, d0, .. dN)` (except in the case of
#       sparse loss functions such as
#       sparse categorical crossentropy which expects integer arrays of shape
#       `(batch_size, d0, .. dN-1)`).
#       `y_pred` should have shape `(batch_size, d0, .. dN)`.
#       The loss function should return a float tensor.
#       If a custom `Loss` instance is
#       used and reduction is set to `None`, return value has shape
#       `(batch_size, d0, .. dN-1)` i.e. per-sample or per-timestep loss
#       values; otherwise, it is a scalar. If the model has multiple outputs,
#       you can use a different loss on each output by passing a dictionary
#       or a list of losses. The loss value that will be minimized by the
#       model will then be the sum of all individual losses, unless
#       `loss_weights` is specified.
#     metrics: List of metrics to be evaluated by the model during training
#       and testing. Each of this can be a string (name of a built-in
#       function), function or a `tf.keras.metrics.Metric` instance. See
#       `tf.keras.metrics`. Typically you will use `metrics=['accuracy']`. A
#       function is any callable with the signature `result = fn(y_true,
#       y_pred)`. To specify different metrics for different outputs of a
#       multi-output model, you could also pass a dictionary, such as
#       `metrics={'output_a': 'accuracy', 'output_b': ['accuracy', 'mse']}`.
#       You can also pass a list to specify a metric or a list of metrics
#       for each output, such as `metrics=[['accuracy'], ['accuracy', 'mse']]`
#       or `metrics=['accuracy', ['accuracy', 'mse']]`. When you pass the
#       strings 'accuracy' or 'acc', we convert this to one of
#       `tf.keras.metrics.BinaryAccuracy`,
#       `tf.keras.metrics.CategoricalAccuracy`,
#       `tf.keras.metrics.SparseCategoricalAccuracy` based on the loss
#       function used and the model output shape. We do a similar
#       conversion for the strings 'crossentropy' and 'ce' as well.
#     loss_weights: Optional list or dictionary specifying scalar coefficients
#       (Python floats) to weight the loss contributions of different model
#       outputs. The loss value that will be minimized by the model will then
#       be the *weighted sum* of all individual losses, weighted by the
#       `loss_weights` coefficients.
#         If a list, it is expected to have a 1:1 mapping to the model's
#           outputs. If a dict, it is expected to map output names (strings)
#           to scalar coefficients.
#     weighted_metrics: List of metrics to be evaluated and weighted by
#       `sample_weight` or `class_weight` during training and testing.
#     run_eagerly: Bool. Defaults to `False`. If `True`, this `Model`'s
#       logic will not be wrapped in a `tf.function`. Recommended to leave
#       this as `None` unless your `Model` cannot be run inside a
#       `tf.function`. `run_eagerly=True` is not supported when using
#       `tf.distribute.experimental.ParameterServerStrategy`.
#     steps_per_execution: Int. Defaults to 1. The number of batches to run
#       during each `tf.function` call. Running multiple batches inside a
#       single `tf.function` call can greatly improve performance on TPUs or
#       small models with a large Python overhead. At most, one full epoch
#       will be run each execution. If a number larger than the size of the
#       epoch is passed, the execution will be truncated to the size of the
#       epoch. Note that if `steps_per_execution` is set to `N`,
#       `Callback.on_batch_begin` and `Callback.on_batch_end` methods will
#       only be called every `N` batches (i.e. before/after each `tf.function`
#       execution).
#     jit_compile: If `True`, compile the model training step with XLA.
#       [XLA](https://www.tensorflow.org/xla) is an optimizing compiler for
#       machine learning.
#       `jit_compile` is not enabled for by default.
#       This option cannot be enabled with `run_eagerly=True`.
#       Note that `jit_compile=True` is
#       may not necessarily work for all models.
#       For more information on supported operations please refer to the
#       [XLA documentation](https://www.tensorflow.org/xla).
#       Also refer to
#       [known XLA issues](https://www.tensorflow.org/xla/known_issues) for
#       more details.
#     **kwargs: Arguments supported for backwards compatibility only.
#
# </code>
# <a href='#14'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
p_inp, n_inp, a_inp = Input((200,)), Input((200,)), Input((200,))

po, no, ao = emb_model(p_inp), emb_model(n_inp), emb_model(a_inp)
out = Concatenate()([ao, po, no])

model = Model(inputs=[p_inp, n_inp, a_inp], outputs=out)
model.compile(optimizer=Nadam(1e-3), loss=triplet_loss_distance)



# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>15. Data Preparation | Feature Engineering</h1>  <a id='15'></a><small><a href='#top_phases'>back to top</a></small>

# %%
x_train = train_df.iloc[:, 2:].values
y = train_df.loc[:, 'target'].values


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>16. Feature Engineering | Model Building and Training</h1>  <a id='16'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.fit_generator</u></summary>
# <blockquote>
# <code>
# Fits the model on data yielded batch-by-batch by a Python generator.
#
# DEPRECATED:
#   `Model.fit` now supports generators, so there is no longer any need to use
#   this endpoint.
#
# </code>
# <a href='#16'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
model.fit_generator(DataGenerator(x_train, y, batch_size=1024), 
                    steps_per_epoch=1000,
                    epochs=15,
                    callbacks=[CyclicLR(base_lr=1*1e-3, max_lr=7*1e-3, step_size=500)])


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>17. Data Preparation | Feature Engineering | Model Building and Training</h1>  <a id='17'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>keras</h2>
# <ul>
# <li>
# <details><summary><u>keras.engine.training.Model.predict</u></summary>
# <blockquote>
# <code>
# Generates output predictions for the input samples.
#
# Computation is done in batches. This method is designed for batch processing
# of large numbers of inputs. It is not intended for use inside of loops
# that iterate over your data and process small numbers of inputs at a time.
#
# For small numbers of inputs that fit in one batch,
# directly use `__call__()` for faster execution, e.g.,
# `model(x)`, or `model(x, training=False)` if you have layers such as
# `tf.keras.layers.BatchNormalization` that behave differently during
# inference. You may pair the individual model call with a `tf.function`
# for additional performance inside your inner loop.
# If you need access to numpy array values instead of tensors after your
# model call, you can use `tensor.numpy()` to get the numpy array value of
# an eager tensor.
#
# Also, note the fact that test loss is not affected by
# regularization layers like noise and dropout.
#
# Note: See [this FAQ entry](
# https://keras.io/getting_started/faq/#whats-the-difference-between-model-methods-predict-and-call)
# for more details about the difference between `Model` methods `predict()`
# and `__call__()`.
#
# Args:
#     x: Input samples. It could be:
#       - A Numpy array (or array-like), or a list of arrays
#         (in case the model has multiple inputs).
#       - A TensorFlow tensor, or a list of tensors
#         (in case the model has multiple inputs).
#       - A `tf.data` dataset.
#       - A generator or `keras.utils.Sequence` instance.
#       A more detailed description of unpacking behavior for iterator types
#       (Dataset, generator, Sequence) is given in the `Unpacking behavior
#       for iterator-like inputs` section of `Model.fit`.
#     batch_size: Integer or `None`.
#         Number of samples per batch.
#         If unspecified, `batch_size` will default to 32.
#         Do not specify the `batch_size` if your data is in the
#         form of dataset, generators, or `keras.utils.Sequence` instances
#         (since they generate batches).
#     verbose: Verbosity mode, 0 or 1.
#     steps: Total number of steps (batches of samples)
#         before declaring the prediction round finished.
#         Ignored with the default value of `None`. If x is a `tf.data`
#         dataset and `steps` is None, `predict()` will
#         run until the input dataset is exhausted.
#     callbacks: List of `keras.callbacks.Callback` instances.
#         List of callbacks to apply during prediction.
#         See [callbacks](/api_docs/python/tf/keras/callbacks).
#     max_queue_size: Integer. Used for generator or `keras.utils.Sequence`
#         input only. Maximum size for the generator queue.
#         If unspecified, `max_queue_size` will default to 10.
#     workers: Integer. Used for generator or `keras.utils.Sequence` input
#         only. Maximum number of processes to spin up when using
#         process-based threading. If unspecified, `workers` will default
#         to 1.
#     use_multiprocessing: Boolean. Used for generator or
#         `keras.utils.Sequence` input only. If `True`, use process-based
#         threading. If unspecified, `use_multiprocessing` will default to
#         `False`. Note that because this implementation relies on
#         multiprocessing, you should not pass non-picklable arguments to
#         the generator as they can't be passed easily to children processes.
#
# See the discussion of `Unpacking behavior for iterator-like inputs` for
# `Model.fit`. Note that Model.predict uses the same interpretation rules as
# `Model.fit` and `Model.evaluate`, so inputs must be unambiguous for all
# three methods.
#
# Returns:
#     Numpy array(s) of predictions.
#
# Raises:
#     RuntimeError: If `model.predict` is wrapped in a `tf.function`.
#     ValueError: In case of mismatch between the provided
#         input data and the model's expectations,
#         or in case a stateful model receives a number of samples
#         that is not a multiple of the batch size.
#
# </code>
# <a href='#17'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
# <li> <h2 class='hglib'>numpy</h2>
# <ul>
# <li>
# <details><summary><u>numpy.lib.npyio.savez</u></summary>
# <blockquote>
# <code>
# Save several arrays into a single file in uncompressed ``.npz`` format.
#
# Provide arrays as keyword arguments to store them under the
# corresponding name in the output file: ``savez(fn, x=x, y=y)``.
#
# If arrays are specified as positional arguments, i.e., ``savez(fn,
# x, y)``, their names will be `arr_0`, `arr_1`, etc.
#
# Parameters
# ----------
# file : str or file
#     Either the filename (string) or an open file (file-like object)
#     where the data will be saved. If file is a string or a Path, the
#     ``.npz`` extension will be appended to the filename if it is not
#     already there.
# args : Arguments, optional
#     Arrays to save to the file. Please use keyword arguments (see
#     `kwds` below) to assign names to arrays.  Arrays specified as
#     args will be named "arr_0", "arr_1", and so on.
# kwds : Keyword arguments, optional
#     Arrays to save to the file. Each array will be saved to the
#     output file with its corresponding keyword name.
#
# Returns
# -------
# None
#
# See Also
# --------
# save : Save a single array to a binary file in NumPy format.
# savetxt : Save an array to a file as plain text.
# savez_compressed : Save several arrays into a compressed ``.npz`` archive
#
# Notes
# -----
# The ``.npz`` file format is a zipped archive of files named after the
# variables they contain.  The archive is not compressed and each file
# in the archive contains one variable in ``.npy`` format. For a
# description of the ``.npy`` format, see :py:mod:`numpy.lib.format`.
#
# When opening the saved ``.npz`` file with `load` a `NpzFile` object is
# returned. This is a dictionary-like object which can be queried for
# its list of arrays (with the ``.files`` attribute), and for the arrays
# themselves.
#
# Keys passed in `kwds` are used as filenames inside the ZIP archive.
# Therefore, keys should be valid filenames; e.g., avoid keys that begin with
# ``/`` or contain ``.``.
#
# When naming variables with keyword arguments, it is not possible to name a
# variable ``file``, as this would cause the ``file`` argument to be defined
# twice in the call to ``savez``.
#
# Examples
# --------
# >>> from tempfile import TemporaryFile
# >>> outfile = TemporaryFile()
# >>> x = np.arange(10)
# >>> y = np.sin(x)
#
# Using `savez` with \*args, the arrays are saved with default names.
#
# >>> np.savez(outfile, x, y)
# >>> _ = outfile.seek(0) # Only needed here to simulate closing & reopening file
# >>> npzfile = np.load(outfile)
# >>> npzfile.files
# ['arr_0', 'arr_1']
# >>> npzfile['arr_0']
# array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#
# Using `savez` with \**kwds, the arrays are saved with the keyword names.
#
# >>> outfile = TemporaryFile()
# >>> np.savez(outfile, x=x, y=y)
# >>> _ = outfile.seek(0)
# >>> npzfile = np.load(outfile)
# >>> sorted(npzfile.files)
# ['x', 'y']
# >>> npzfile['x']
# array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#
# </code>
# <a href='#17'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
x_emb = emb_model.predict(x_train, verbose=1)
x_emb_t = emb_model.predict(test_df.iloc[:, 1:].values, verbose=1)

np.savez('emb.npz', x=x_emb, xt=x_emb_t)


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>18. Library Loading</h1>  <a id='18'></a><small><a href='#top_phases'>back to top</a></small>

# %%
import matplotlib.pyplot as plt


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>19. Library Loading</h1>  <a id='19'></a><small><a href='#top_phases'>back to top</a></small>

# %%
from sklearn.decomposition import PCA


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>20. Data Preparation | Feature Engineering</h1>  <a id='20'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>sklearn</h2>
# <ul>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA</u></summary>
# <blockquote>
# <code>
# Principal component analysis (PCA).
#
# Linear dimensionality reduction using Singular Value Decomposition of the
# data to project it to a lower dimensional space. The input data is centered
# but not scaled for each feature before applying the SVD.
#
# It uses the LAPACK implementation of the full SVD or a randomized truncated
# SVD by the method of Halko et al. 2009, depending on the shape of the input
# data and the number of components to extract.
#
# It can also use the scipy.sparse.linalg ARPACK implementation of the
# truncated SVD.
#
# Notice that this class does not support sparse input. See
# :class:`TruncatedSVD` for an alternative with sparse data.
#
# Read more in the :ref:`User Guide <PCA>`.
#
# Parameters
# ----------
# n_components : int, float or 'mle', default=None
#     Number of components to keep.
#     if n_components is not set all components are kept::
#
#         n_components == min(n_samples, n_features)
#
#     If ``n_components == 'mle'`` and ``svd_solver == 'full'``, Minka's
#     MLE is used to guess the dimension. Use of ``n_components == 'mle'``
#     will interpret ``svd_solver == 'auto'`` as ``svd_solver == 'full'``.
#
#     If ``0 < n_components < 1`` and ``svd_solver == 'full'``, select the
#     number of components such that the amount of variance that needs to be
#     explained is greater than the percentage specified by n_components.
#
#     If ``svd_solver == 'arpack'``, the number of components must be
#     strictly less than the minimum of n_features and n_samples.
#
#     Hence, the None case results in::
#
#         n_components == min(n_samples, n_features) - 1
#
# copy : bool, default=True
#     If False, data passed to fit are overwritten and running
#     fit(X).transform(X) will not yield the expected results,
#     use fit_transform(X) instead.
#
# whiten : bool, default=False
#     When True (False by default) the `components_` vectors are multiplied
#     by the square root of n_samples and then divided by the singular values
#     to ensure uncorrelated outputs with unit component-wise variances.
#
#     Whitening will remove some information from the transformed signal
#     (the relative variance scales of the components) but can sometime
#     improve the predictive accuracy of the downstream estimators by
#     making their data respect some hard-wired assumptions.
#
# svd_solver : {'auto', 'full', 'arpack', 'randomized'}, default='auto'
#     If auto :
#         The solver is selected by a default policy based on `X.shape` and
#         `n_components`: if the input data is larger than 500x500 and the
#         number of components to extract is lower than 80% of the smallest
#         dimension of the data, then the more efficient 'randomized'
#         method is enabled. Otherwise the exact full SVD is computed and
#         optionally truncated afterwards.
#     If full :
#         run exact full SVD calling the standard LAPACK solver via
#         `scipy.linalg.svd` and select the components by postprocessing
#     If arpack :
#         run SVD truncated to n_components calling ARPACK solver via
#         `scipy.sparse.linalg.svds`. It requires strictly
#         0 < n_components < min(X.shape)
#     If randomized :
#         run randomized SVD by the method of Halko et al.
#
#     .. versionadded:: 0.18.0
#
# tol : float, default=0.0
#     Tolerance for singular values computed by svd_solver == 'arpack'.
#     Must be of range [0.0, infinity).
#
#     .. versionadded:: 0.18.0
#
# iterated_power : int or 'auto', default='auto'
#     Number of iterations for the power method computed by
#     svd_solver == 'randomized'.
#     Must be of range [0, infinity).
#
#     .. versionadded:: 0.18.0
#
# random_state : int, RandomState instance or None, default=None
#     Used when the 'arpack' or 'randomized' solvers are used. Pass an int
#     for reproducible results across multiple function calls.
#     See :term:`Glossary <random_state>`.
#
#     .. versionadded:: 0.18.0
#
# Attributes
# ----------
# components_ : ndarray of shape (n_components, n_features)
#     Principal axes in feature space, representing the directions of
#     maximum variance in the data. Equivalently, the right singular
#     vectors of the centered input data, parallel to its eigenvectors.
#     The components are sorted by ``explained_variance_``.
#
# explained_variance_ : ndarray of shape (n_components,)
#     The amount of variance explained by each of the selected components.
#     The variance estimation uses `n_samples - 1` degrees of freedom.
#
#     Equal to n_components largest eigenvalues
#     of the covariance matrix of X.
#
#     .. versionadded:: 0.18
#
# explained_variance_ratio_ : ndarray of shape (n_components,)
#     Percentage of variance explained by each of the selected components.
#
#     If ``n_components`` is not set then all components are stored and the
#     sum of the ratios is equal to 1.0.
#
# singular_values_ : ndarray of shape (n_components,)
#     The singular values corresponding to each of the selected components.
#     The singular values are equal to the 2-norms of the ``n_components``
#     variables in the lower-dimensional space.
#
#     .. versionadded:: 0.19
#
# mean_ : ndarray of shape (n_features,)
#     Per-feature empirical mean, estimated from the training set.
#
#     Equal to `X.mean(axis=0)`.
#
# n_components_ : int
#     The estimated number of components. When n_components is set
#     to 'mle' or a number between 0 and 1 (with svd_solver == 'full') this
#     number is estimated from input data. Otherwise it equals the parameter
#     n_components, or the lesser value of n_features and n_samples
#     if n_components is None.
#
# n_features_ : int
#     Number of features in the training data.
#
# n_samples_ : int
#     Number of samples in the training data.
#
# noise_variance_ : float
#     The estimated noise covariance following the Probabilistic PCA model
#     from Tipping and Bishop 1999. See "Pattern Recognition and
#     Machine Learning" by C. Bishop, 12.2.1 p. 574 or
#     http://www.miketipping.com/papers/met-mppca.pdf. It is required to
#     compute the estimated data covariance and score samples.
#
#     Equal to the average of (min(n_features, n_samples) - n_components)
#     smallest eigenvalues of the covariance matrix of X.
#
# n_features_in_ : int
#     Number of features seen during :term:`fit`.
#
#     .. versionadded:: 0.24
#
# feature_names_in_ : ndarray of shape (`n_features_in_`,)
#     Names of features seen during :term:`fit`. Defined only when `X`
#     has feature names that are all strings.
#
#     .. versionadded:: 1.0
#
# See Also
# --------
# KernelPCA : Kernel Principal Component Analysis.
# SparsePCA : Sparse Principal Component Analysis.
# TruncatedSVD : Dimensionality reduction using truncated SVD.
# IncrementalPCA : Incremental Principal Component Analysis.
#
# References
# ----------
# For n_components == 'mle', this class uses the method from:
# `Minka, T. P.. "Automatic choice of dimensionality for PCA".
# In NIPS, pp. 598-604 <https://tminka.github.io/papers/pca/minka-pca.pdf>`_
#
# Implements the probabilistic PCA model from:
# `Tipping, M. E., and Bishop, C. M. (1999). "Probabilistic principal
# component analysis". Journal of the Royal Statistical Society:
# Series B (Statistical Methodology), 61(3), 611-622.
# <http://www.miketipping.com/papers/met-mppca.pdf>`_
# via the score and score_samples methods.
#
# For svd_solver == 'arpack', refer to `scipy.sparse.linalg.svds`.
#
# For svd_solver == 'randomized', see:
# `Halko, N., Martinsson, P. G., and Tropp, J. A. (2011).
# "Finding structure with randomness: Probabilistic algorithms for
# constructing approximate matrix decompositions".
# SIAM review, 53(2), 217-288.
# <https://doi.org/10.1137/090771806>`_
# and also
# `Martinsson, P. G., Rokhlin, V., and Tygert, M. (2011).
# "A randomized algorithm for the decomposition of matrices".
# Applied and Computational Harmonic Analysis, 30(1), 47-68
# <https://doi.org/10.1016/j.acha.2010.02.003>`_.
#
# Examples
# --------
# >>> import numpy as np
# >>> from sklearn.decomposition import PCA
# >>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
# >>> pca = PCA(n_components=2)
# >>> pca.fit(X)
# PCA(n_components=2)
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.0075...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=2, svd_solver='full')
# >>> pca.fit(X)
# PCA(n_components=2, svd_solver='full')
# >>> print(pca.explained_variance_ratio_)
# [0.9924... 0.00755...]
# >>> print(pca.singular_values_)
# [6.30061... 0.54980...]
#
# >>> pca = PCA(n_components=1, svd_solver='arpack')
# >>> pca.fit(X)
# PCA(n_components=1, svd_solver='arpack')
# >>> print(pca.explained_variance_ratio_)
# [0.99244...]
# >>> print(pca.singular_values_)
# [6.30061...]
#
# </code>
# <a href='#20'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>sklearn.decomposition._pca.PCA.fit_transform</u></summary>
# <blockquote>
# <code>
# Fit the model with X and apply the dimensionality reduction on X.
#
# Parameters
# ----------
# X : array-like of shape (n_samples, n_features)
#     Training data, where `n_samples` is the number of samples
#     and `n_features` is the number of features.
#
# y : Ignored
#     Ignored.
#
# Returns
# -------
# X_new : ndarray of shape (n_samples, n_components)
#     Transformed values.
#
# Notes
# -----
# This method returns a Fortran-ordered array. To convert it to a
# C-ordered array, use 'np.ascontiguousarray'.
#
# </code>
# <a href='#20'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
pca = PCA(n_components=2)
x_pca = pca.fit_transform(x_emb)

# %%
pca.explained_variance_ratio_


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>22. Data Preparation | Feature Engineering</h1>  <a id='22'></a><small><a href='#top_phases'>back to top</a></small>

# %%
xep = x_pca[y==1]
xen = x_pca[y==0]


# %% [markdown] deletable=false editable=false run_control={"frozen": true}
# <h1 class='hg'>23. Visualization</h1>  <a id='23'></a><small><a href='#top_phases'>back to top</a></small><details><summary><u>View function documentation</u></summary>
# <ul>
#
# <li> <h2 class='hglib'>matplotlib</h2>
# <ul>
# <li>
# <details><summary><u>matplotlib.pyplot.figure</u></summary>
# <blockquote>
# <code>
# Create a new figure, or activate an existing figure.
#
# Parameters
# ----------
# num : int or str or `.Figure`, optional
#     A unique identifier for the figure.
#
#     If a figure with that identifier already exists, this figure is made
#     active and returned. An integer refers to the ``Figure.number``
#     attribute, a string refers to the figure label.
#
#     If there is no figure with the identifier or *num* is not given, a new
#     figure is created, made active and returned.  If *num* is an int, it
#     will be used for the ``Figure.number`` attribute, otherwise, an
#     auto-generated integer value is used (starting at 1 and incremented
#     for each new figure). If *num* is a string, the figure label and the
#     window title is set to this value.
#
# figsize : (float, float), default: :rc:`figure.figsize`
#     Width, height in inches.
#
# dpi : float, default: :rc:`figure.dpi`
#     The resolution of the figure in dots-per-inch.
#
# facecolor : color, default: :rc:`figure.facecolor`
#     The background color.
#
# edgecolor : color, default: :rc:`figure.edgecolor`
#     The border color.
#
# frameon : bool, default: True
#     If False, suppress drawing the figure frame.
#
# FigureClass : subclass of `~matplotlib.figure.Figure`
#     Optionally use a custom `.Figure` instance.
#
# clear : bool, default: False
#     If True and the figure already exists, then it is cleared.
#
# tight_layout : bool or dict, default: :rc:`figure.autolayout`
#     If ``False`` use *subplotpars*. If ``True`` adjust subplot
#     parameters using `.tight_layout` with default padding.
#     When providing a dict containing the keys ``pad``, ``w_pad``,
#     ``h_pad``, and ``rect``, the default `.tight_layout` paddings
#     will be overridden.
#
# constrained_layout : bool, default: :rc:`figure.constrained_layout.use`
#     If ``True`` use constrained layout to adjust positioning of plot
#     elements.  Like ``tight_layout``, but designed to be more
#     flexible.  See
#     :doc:`/tutorials/intermediate/constrainedlayout_guide`
#     for examples.  (Note: does not work with `add_subplot` or
#     `~.pyplot.subplot2grid`.)
#
#
# **kwargs : optional
#     See `~.matplotlib.figure.Figure` for other possible arguments.
#
# Returns
# -------
# `~matplotlib.figure.Figure`
#     The `.Figure` instance returned will also be passed to
#     new_figure_manager in the backends, which allows to hook custom
#     `.Figure` classes into the pyplot interface. Additional kwargs will be
#     passed to the `.Figure` init function.
#
# Notes
# -----
# If you are creating many figures, make sure you explicitly call
# `.pyplot.close` on the figures you are not using, because this will
# enable pyplot to properly clean up the memory.
#
# `~matplotlib.rcParams` defines the default values, which can be modified
# in the matplotlibrc file.
#
# </code>
# <a href='#23'>back to header</a>
# </blockquote>
# </details>
# </li>
# <li>
# <details><summary><u>matplotlib.pyplot.scatter</u></summary>
# <blockquote>
# <code>
# A scatter plot of *y* vs. *x* with varying marker size and/or color.
#
# Parameters
# ----------
# x, y : float or array-like, shape (n, )
#     The data positions.
#
# s : float or array-like, shape (n, ), optional
#     The marker size in points**2.
#     Default is ``rcParams['lines.markersize'] ** 2``.
#
# c : array-like or list of colors or color, optional
#     The marker colors. Possible values:
#
#     - A scalar or sequence of n numbers to be mapped to colors using
#       *cmap* and *norm*.
#     - A 2D array in which the rows are RGB or RGBA.
#     - A sequence of colors of length n.
#     - A single color format string.
#
#     Note that *c* should not be a single numeric RGB or RGBA sequence
#     because that is indistinguishable from an array of values to be
#     colormapped. If you want to specify the same RGB or RGBA value for
#     all points, use a 2D array with a single row.  Otherwise, value-
#     matching will have precedence in case of a size matching with *x*
#     and *y*.
#
#     If you wish to specify a single color for all points
#     prefer the *color* keyword argument.
#
#     Defaults to `None`. In that case the marker color is determined
#     by the value of *color*, *facecolor* or *facecolors*. In case
#     those are not specified or `None`, the marker color is determined
#     by the next color of the ``Axes``' current "shape and fill" color
#     cycle. This cycle defaults to :rc:`axes.prop_cycle`.
#
# marker : `~.markers.MarkerStyle`, default: :rc:`scatter.marker`
#     The marker style. *marker* can be either an instance of the class
#     or the text shorthand for a particular marker.
#     See :mod:`matplotlib.markers` for more information about marker
#     styles.
#
# cmap : str or `~matplotlib.colors.Colormap`, default: :rc:`image.cmap`
#     A `.Colormap` instance or registered colormap name. *cmap* is only
#     used if *c* is an array of floats.
#
# norm : `~matplotlib.colors.Normalize`, default: None
#     If *c* is an array of floats, *norm* is used to scale the color
#     data, *c*, in the range 0 to 1, in order to map into the colormap
#     *cmap*.
#     If *None*, use the default `.colors.Normalize`.
#
# vmin, vmax : float, default: None
#     *vmin* and *vmax* are used in conjunction with the default norm to
#     map the color array *c* to the colormap *cmap*. If None, the
#     respective min and max of the color array is used.
#     It is an error to use *vmin*/*vmax* when *norm* is given.
#
# alpha : float, default: None
#     The alpha blending value, between 0 (transparent) and 1 (opaque).
#
# linewidths : float or array-like, default: :rc:`lines.linewidth`
#     The linewidth of the marker edges. Note: The default *edgecolors*
#     is 'face'. You may want to change this as well.
#
# edgecolors : {'face', 'none', *None*} or color or sequence of color, default: :rc:`scatter.edgecolors`
#     The edge color of the marker. Possible values:
#
#     - 'face': The edge color will always be the same as the face color.
#     - 'none': No patch boundary will be drawn.
#     - A color or sequence of colors.
#
#     For non-filled markers, *edgecolors* is ignored. Instead, the color
#     is determined like with 'face', i.e. from *c*, *colors*, or
#     *facecolors*.
#
# plotnonfinite : bool, default: False
#     Whether to plot points with nonfinite *c* (i.e. ``inf``, ``-inf``
#     or ``nan``). If ``True`` the points are drawn with the *bad*
#     colormap color (see `.Colormap.set_bad`).
#
# Returns
# -------
# `~matplotlib.collections.PathCollection`
#
# Other Parameters
# ----------------
# data : indexable object, optional
#     If given, the following parameters also accept a string ``s``, which is
#     interpreted as ``data[s]`` (unless this raises an exception):
#
#     *x*, *y*, *s*, *linewidths*, *edgecolors*, *c*, *facecolor*, *facecolors*, *color*
# **kwargs : `~matplotlib.collections.Collection` properties
#
# See Also
# --------
# plot : To plot scatter plots when markers are identical in size and
#     color.
#
# Notes
# -----
# * The `.plot` function will be faster for scatterplots where markers
#   don't vary in size or color.
#
# * Any or all of *x*, *y*, *s*, and *c* may be masked arrays, in which
#   case all masks will be combined and only unmasked points will be
#   plotted.
#
# * Fundamentally, scatter works with 1D arrays; *x*, *y*, *s*, and *c*
#   may be input as N-D arrays, but within scatter they will be
#   flattened. The exception is *c*, which will be flattened only if its
#   size matches the size of *x* and *y*.
#
# </code>
# <a href='#23'>back to header</a>
# </blockquote>
# </details>
# </li>
# </ul>
# </li>
#
# </ul>
# </details>

# %%
plt.figure(figsize=(10,10))

plt.scatter(xep[:, 0], xep[:, 1], alpha=0.9)
plt.scatter(xen[:, 0], xen[:, 1], alpha=0.3)

# %%

# %%
